DROP TABLE IF EXISTS adjusment;

CREATE TABLE `adjusment` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_adj` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_adj` date NOT NULL,
  `tgl_stock` date NOT NULL,
  `ket` varchar(255) collate latin1_general_ci NOT NULL,
  `userid` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO adjusment VALUES('0000000001', 'ADJ-2013000001', '2013-03-17', '2013-03-17', '54645', 'admin');



DROP TABLE IF EXISTS adjusment_detail;

CREATE TABLE `adjusment_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_adj` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_adj` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `cat` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO adjusment_detail VALUES('0000000001', '4', 'ADJ-2013000001', '2013-03-17', 'B00002', '1.00', '456');



DROP TABLE IF EXISTS bahanbaku_detail;

CREATE TABLE `bahanbaku_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_bpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_bpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO bahanbaku_detail VALUES('0000000004', '1', '345', '2013-03-15', 'B00002', '200.00');
INSERT INTO bahanbaku_detail VALUES('0000000005', '2', '324', '2013-03-15', 'B00002', '1000.00');
INSERT INTO bahanbaku_detail VALUES('0000000001', '3', 'LP-2013000001/PRODUKSI', '2013-03-17', 'B00002', '1.00');



DROP TABLE IF EXISTS barang;

CREATE TABLE `barang` (
  `id` int(8) NOT NULL auto_increment,
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `nm_barang` varchar(100) collate latin1_general_ci NOT NULL,
  `type` varchar(100) collate latin1_general_ci NOT NULL,
  `spec` varchar(100) collate latin1_general_ci NOT NULL,
  `stok` float(10,2) NOT NULL,
  `satuan` varchar(100) collate latin1_general_ci NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `kd_kategori` char(3) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO barang VALUES('46', 'B00008', 'Bangku', 'der', 'der', '0.00', 'KGM', 'baru', 'K04');
INSERT INTO barang VALUES('45', 'B00007', 'Kain', 'long', 'long', '0.00', 'KGM', 'baru', 'K03');
INSERT INTO barang VALUES('44', 'B00006', 'Jendela', 'besar', 'besar', '0.00', 'KGM', 'baru', 'K02');
INSERT INTO barang VALUES('43', 'B00005', 'Kursi', 'large', 'large', '0.00', 'KGM', 'baru', 'K01');
INSERT INTO barang VALUES('42', 'B00004', 'Batu', 'small', 'small', '0.00', 'KGM', 'baru', 'K04');
INSERT INTO barang VALUES('41', 'B00003', 'Kaos', 'large', 'large', '200.00', 'KGM', 'baru', 'K03');
INSERT INTO barang VALUES('40', 'B00002', 'Celana', 'smal', 'smal', '1.00', 'KGM', 'baru', 'K02');
INSERT INTO barang VALUES('39', 'B00001', 'Baju', 'kecil', 'kecil', '0.00', 'PCS', 'baru', 'K01');



DROP TABLE IF EXISTS brgjadi;

CREATE TABLE `brgjadi` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_bpb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_bpb` date NOT NULL,
  `project` varchar(100) collate latin1_general_ci NOT NULL,
  `dept` char(100) collate latin1_general_ci NOT NULL,
  `name_ppc` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO brgjadi VALUES('0000000001', 'LP-2013000001/PRODUKSI', '2013-03-17', '324234', 'Bagian Penyimpanan B', '234', '234', 'admin');



DROP TABLE IF EXISTS brgjadi_detail;

CREATE TABLE `brgjadi_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_bpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_bpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO brgjadi_detail VALUES('0000000001', '9', 'LP-2013000001/PRODUKSI', '2013-03-17', 'B00001', '1.00');



DROP TABLE IF EXISTS catatan;

CREATE TABLE `catatan` (
  `kd_catatan` char(8) collate latin1_general_ci NOT NULL,
  `nm_catatan` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO catatan VALUES('CAT-0001', 'Ditimbun');
INSERT INTO catatan VALUES('CAT-0002', 'Diproses');
INSERT INTO catatan VALUES('CAT-0003', 'Disubkontrakkan');
INSERT INTO catatan VALUES('CAT-0004', 'Dipinjamkan');
INSERT INTO catatan VALUES('CAT-0005', 'Diperbaiki');
INSERT INTO catatan VALUES('CAT-0006', 'Pengembalian Subkontrak');
INSERT INTO catatan VALUES('CAT-0007', 'Pengembalian Pinjaman');
INSERT INTO catatan VALUES('CAT-0008', 'Pemusnahan');



DROP TABLE IF EXISTS closing;

CREATE TABLE `closing` (
  `id` int(8) NOT NULL auto_increment,
  `tgl_closing` date NOT NULL,
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `stock` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS dept;

CREATE TABLE `dept` (
  `kd_dept` char(8) collate latin1_general_ci NOT NULL,
  `nm_dept` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO dept VALUES('DEP-0001', 'Bagian Penyimpanan Bahan Baku / Penolong');
INSERT INTO dept VALUES('DEP-0002', 'Bagian Alat Produksi');
INSERT INTO dept VALUES('DEP-0003', 'Bagian Pra Produksi');
INSERT INTO dept VALUES('DEP-0004', 'Bagian Produksi');
INSERT INTO dept VALUES('DEP-0005', 'Bagian Kontrol Kualitas');
INSERT INTO dept VALUES('DEP-0006', 'Bagian Pasca Produksi');
INSERT INTO dept VALUES('DEP-0007', 'Bagian Penyimpanan Barang Jadi');
INSERT INTO dept VALUES('DEP-0008', 'Bagian Penyimpanan Barang Sisa / Scrap');
INSERT INTO dept VALUES('DEP-0009', 'Bagian Penjualan');



DROP TABLE IF EXISTS incoming_outgoing;

CREATE TABLE `incoming_outgoing` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(100) collate latin1_general_ci NOT NULL,
  `name_ppc` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO incoming_outgoing VALUES('0000000001', 'SPB-2013000001/INCOMING', '2013-03-17', 'Bagian Penyimpanan B', 'wer', 'wer', 'admin');



DROP TABLE IF EXISTS incoming_outgoing_detail;

CREATE TABLE `incoming_outgoing_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO incoming_outgoing_detail VALUES('0000000001', '2', 'SPB-2013000001/INCOMING', '2013-03-17', 'B00002', '1.00', 'wer');



DROP TABLE IF EXISTS incoming_terima;

CREATE TABLE `incoming_terima` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(8) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(100) collate latin1_general_ci NOT NULL,
  `name_ppc` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `user_trt` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO incoming_terima VALUES('0000000001', 'LPB-2013000001/INCOMING', '2013-03-17', 'PRODUKSI', 'SPB-2013', '2013-03-17', 'Bagian Alat Produksi', '324', '234', 'admin', 'admin');



DROP TABLE IF EXISTS incoming_terima_detail;

CREATE TABLE `incoming_terima_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO incoming_terima_detail VALUES('0000000001', '7', 'PRODUKSI', 'LPB-2013000001/INCOMING', '2013-03-17', 'B00003', '1.00', '324');



DROP TABLE IF EXISTS infokb;

CREATE TABLE `infokb` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(8) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL,
  `alamat` varchar(200) collate latin1_general_ci NOT NULL,
  `prop` char(100) collate latin1_general_ci NOT NULL,
  `kota` varchar(100) collate latin1_general_ci NOT NULL,
  `npwp` varchar(20) collate latin1_general_ci NOT NULL,
  `telp` varchar(100) collate latin1_general_ci NOT NULL,
  `fax` varchar(100) collate latin1_general_ci NOT NULL,
  `skepkb` varchar(100) collate latin1_general_ci NOT NULL,
  `tglskep` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO infokb VALUES('id', 'DEMO', 'PT Demo Aplikasi Indonesia', 'EJIP Industrial Park Plot 4E, Cikarang', 'Jawa Barat', 'Bekasi', '01021221545555', '021-8970101', '021-8970101', '1206/KM.4/2012', '2013-01-22');



DROP TABLE IF EXISTS jenisbckeluar;

CREATE TABLE `jenisbckeluar` (
  `kode` char(6) collate latin1_general_ci NOT NULL,
  `jenis` varchar(100) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO jenisbckeluar VALUES('BCOUT1', 'BC 2.7', 'Pengeluaran barang ke Kawasan Berikat lainnya');
INSERT INTO jenisbckeluar VALUES('BCOUT2', 'BC 4.1', 'Pengeluaran barang ke TLDDP');



DROP TABLE IF EXISTS jenisbcmasuk;

CREATE TABLE `jenisbcmasuk` (
  `kode` char(6) collate latin1_general_ci NOT NULL,
  `jenis` varchar(100) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO jenisbcmasuk VALUES('BCIN01', 'BC 2.3', 'Pemasukan barang dari Luar Daerah Pabean/Luar Negeri');
INSERT INTO jenisbcmasuk VALUES('BCIN02', 'BC 2.7', 'Pemasukan barang dari Kawasan Berikat lain atau Gudang Berikat');



DROP TABLE IF EXISTS kategori;

CREATE TABLE `kategori` (
  `kd_kategori` char(3) collate latin1_general_ci NOT NULL,
  `nm_kategori` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO kategori VALUES('K01', 'Bahan Baku/Penolong');
INSERT INTO kategori VALUES('K02', 'Barang Jadi');
INSERT INTO kategori VALUES('K03', 'Barang Modal dan Peralatan Perkantoran');
INSERT INTO kategori VALUES('K04', 'Barang Sisa / Scrap');



DROP TABLE IF EXISTS kemasan;

CREATE TABLE `kemasan` (
  `id_kemasan` int(4) NOT NULL auto_increment,
  `kd_kemasan` varchar(4) collate latin1_general_ci NOT NULL,
  `uraian_kemasan` varchar(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_kemasan`)
) ENGINE=MyISAM AUTO_INCREMENT=137 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO kemasan VALUES('1', 'AE', 'AEROSOL');
INSERT INTO kemasan VALUES('2', 'AM', 'Ampoule, non protected');
INSERT INTO kemasan VALUES('3', 'AP', 'Ampoule, protected');
INSERT INTO kemasan VALUES('4', 'AT', 'Atomizer');
INSERT INTO kemasan VALUES('5', 'BA', 'Barrel');
INSERT INTO kemasan VALUES('6', 'BB', 'Bobbin');
INSERT INTO kemasan VALUES('7', 'BC', 'Bottlecrate, bottlerack');
INSERT INTO kemasan VALUES('8', 'BD', 'Board');
INSERT INTO kemasan VALUES('9', 'BE', 'Bundle');
INSERT INTO kemasan VALUES('10', 'BF', 'Balloon, non-protected');
INSERT INTO kemasan VALUES('11', 'BG', 'Bag');
INSERT INTO kemasan VALUES('12', 'BH', 'Bunch');
INSERT INTO kemasan VALUES('13', 'BI', 'Bin');
INSERT INTO kemasan VALUES('14', 'BJ', 'Bucket');
INSERT INTO kemasan VALUES('15', 'BK', 'Basket');
INSERT INTO kemasan VALUES('16', 'BL', 'Bale, compressed');
INSERT INTO kemasan VALUES('17', 'BN', 'Bale, non -compressed');
INSERT INTO kemasan VALUES('18', 'BO', 'Bottle, non-protected, cylindrical');
INSERT INTO kemasan VALUES('19', 'BP', 'Balloon, protected');
INSERT INTO kemasan VALUES('20', 'BQ', 'Bottle, protected cylindrical');
INSERT INTO kemasan VALUES('21', 'BR', 'Bar');
INSERT INTO kemasan VALUES('22', 'BS', 'Bottle, non-protected, bulbous');
INSERT INTO kemasan VALUES('23', 'BT', 'Bolt');
INSERT INTO kemasan VALUES('24', 'BU', 'Butt');
INSERT INTO kemasan VALUES('25', 'BV', 'Bottle, protected bulbous');
INSERT INTO kemasan VALUES('26', 'BX', 'Box');
INSERT INTO kemasan VALUES('27', 'BY', 'Board, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('28', 'BZ', 'Bars, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('29', 'CA', 'Can, rectangular');
INSERT INTO kemasan VALUES('30', 'CB', 'Beer crate');
INSERT INTO kemasan VALUES('31', 'CC', 'Churn');
INSERT INTO kemasan VALUES('32', 'CE', 'Creel');
INSERT INTO kemasan VALUES('33', 'CF', 'Coffer');
INSERT INTO kemasan VALUES('34', 'CG', 'Cage');
INSERT INTO kemasan VALUES('35', 'CH', 'Chest');
INSERT INTO kemasan VALUES('36', 'CI', 'Canister');
INSERT INTO kemasan VALUES('37', 'CJ', 'Coffin');
INSERT INTO kemasan VALUES('38', 'CK', 'Cask');
INSERT INTO kemasan VALUES('39', 'CL', 'Coil');
INSERT INTO kemasan VALUES('40', 'CO', 'Carboy, non-protected');
INSERT INTO kemasan VALUES('41', 'CP', 'Carboy, protected');
INSERT INTO kemasan VALUES('42', 'CR', 'Crate');
INSERT INTO kemasan VALUES('43', 'CS', 'Case');
INSERT INTO kemasan VALUES('44', 'CT', 'Carton');
INSERT INTO kemasan VALUES('45', 'CU', 'Cup');
INSERT INTO kemasan VALUES('46', 'CV', 'Cover');
INSERT INTO kemasan VALUES('47', 'CX', 'Can, cylindical');
INSERT INTO kemasan VALUES('48', 'CY', 'Cylinder');
INSERT INTO kemasan VALUES('49', 'CZ', 'Canvas');
INSERT INTO kemasan VALUES('50', 'DJ', 'Demijohn, non-protected');
INSERT INTO kemasan VALUES('51', 'DP', 'Demijohn, protected');
INSERT INTO kemasan VALUES('52', 'DR', 'Drum');
INSERT INTO kemasan VALUES('53', 'EN', 'Envelope');
INSERT INTO kemasan VALUES('54', 'FC', 'Fruit crate');
INSERT INTO kemasan VALUES('55', 'FD', 'Framed crate');
INSERT INTO kemasan VALUES('56', 'FI', 'Firkin');
INSERT INTO kemasan VALUES('57', 'FL', 'Flask');
INSERT INTO kemasan VALUES('58', 'FO', 'Footlocker');
INSERT INTO kemasan VALUES('59', 'FP', 'Filmpack');
INSERT INTO kemasan VALUES('60', 'FR', 'Frame');
INSERT INTO kemasan VALUES('61', 'GB', 'Gas bottle');
INSERT INTO kemasan VALUES('62', 'GI', 'Girder');
INSERT INTO kemasan VALUES('63', 'GZ', 'Girders, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('64', 'HG', 'Hogshead');
INSERT INTO kemasan VALUES('65', 'HR', 'Hamper');
INSERT INTO kemasan VALUES('66', 'IN', 'Ingot');
INSERT INTO kemasan VALUES('67', 'IZ', 'ingots, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('68', 'JC', 'Jerrican, rectangular');
INSERT INTO kemasan VALUES('69', 'JG', 'Jug');
INSERT INTO kemasan VALUES('70', 'JR', 'Jar');
INSERT INTO kemasan VALUES('71', 'JT', 'Jutebag');
INSERT INTO kemasan VALUES('72', 'JY', 'Jerrican, cylindrical');
INSERT INTO kemasan VALUES('73', 'KG', 'Keg');
INSERT INTO kemasan VALUES('74', 'LG', 'Log');
INSERT INTO kemasan VALUES('75', 'LZ', 'Logs, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('76', 'MB', 'Multiply bag');
INSERT INTO kemasan VALUES('77', 'MC', 'milk crate');
INSERT INTO kemasan VALUES('78', 'MS', 'Multiwall sack');
INSERT INTO kemasan VALUES('79', 'MT', 'Mat');
INSERT INTO kemasan VALUES('80', 'MX', 'Macth box');
INSERT INTO kemasan VALUES('81', 'NE', 'Unpacked or unpackaged');
INSERT INTO kemasan VALUES('82', 'NS', 'Nest');
INSERT INTO kemasan VALUES('83', 'NT', 'Net');
INSERT INTO kemasan VALUES('84', 'PA', 'Packet');
INSERT INTO kemasan VALUES('85', 'PC', 'Parcel');
INSERT INTO kemasan VALUES('86', 'PG', 'Plate');
INSERT INTO kemasan VALUES('87', 'PH', 'Pitcher');
INSERT INTO kemasan VALUES('88', 'PI', 'Pipe');
INSERT INTO kemasan VALUES('89', 'PK', 'Package');
INSERT INTO kemasan VALUES('90', 'PL', 'Pail');
INSERT INTO kemasan VALUES('91', 'PN', 'Plank');
INSERT INTO kemasan VALUES('92', 'PO', 'Pouch');
INSERT INTO kemasan VALUES('93', 'PT', 'Pot');
INSERT INTO kemasan VALUES('94', 'PU', 'Tray pack');
INSERT INTO kemasan VALUES('95', 'PY', 'Plates, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('96', 'PZ', 'Planks/Pipes, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('97', 'RD', 'Rod');
INSERT INTO kemasan VALUES('98', 'RG', 'Ring');
INSERT INTO kemasan VALUES('99', 'RL', 'Reel');
INSERT INTO kemasan VALUES('100', 'RO', 'Roll');
INSERT INTO kemasan VALUES('101', 'RT', 'Rednet');
INSERT INTO kemasan VALUES('102', 'RZ', 'Rods, in bundle/ bunch/truss');
INSERT INTO kemasan VALUES('103', 'SA', 'Sack');
INSERT INTO kemasan VALUES('104', 'SC', 'Shallow crate');
INSERT INTO kemasan VALUES('105', 'SD', 'Spindle');
INSERT INTO kemasan VALUES('106', 'SE', 'Sea-chest');
INSERT INTO kemasan VALUES('107', 'SH', 'Sachet');
INSERT INTO kemasan VALUES('108', 'SK', 'Skeleton case');
INSERT INTO kemasan VALUES('109', 'SL', 'Slipsheet');
INSERT INTO kemasan VALUES('110', 'SM', 'Sheetmetal');
INSERT INTO kemasan VALUES('111', 'ST', 'Sheet');
INSERT INTO kemasan VALUES('112', 'SU', 'Suitcase');
INSERT INTO kemasan VALUES('113', 'SW', 'Shrinkwrapped');
INSERT INTO kemasan VALUES('114', 'SZ', 'Sheets, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('115', 'TB', 'Tub');
INSERT INTO kemasan VALUES('116', 'TC', 'Tea-chest');
INSERT INTO kemasan VALUES('117', 'TD', 'Tube, collapsible');
INSERT INTO kemasan VALUES('118', 'TK', 'Tank, rectangular');
INSERT INTO kemasan VALUES('119', 'TN', 'Tin');
INSERT INTO kemasan VALUES('120', 'TO', 'Tun');
INSERT INTO kemasan VALUES('121', 'TP', 'Tray');
INSERT INTO kemasan VALUES('122', 'TR', 'Trunk');
INSERT INTO kemasan VALUES('123', 'TS', 'Truss');
INSERT INTO kemasan VALUES('124', 'TU', 'Tube');
INSERT INTO kemasan VALUES('125', 'TY', 'Tank, cylindrical');
INSERT INTO kemasan VALUES('126', 'TZ', 'Tubes, in bundle/bunch/truss');
INSERT INTO kemasan VALUES('127', 'VA', 'Vat');
INSERT INTO kemasan VALUES('128', 'VG', 'Bulk, gas ( at 1031 mbar and 15C )');
INSERT INTO kemasan VALUES('129', 'VI', 'Vial');
INSERT INTO kemasan VALUES('130', 'VL', 'Bulk, liquid');
INSERT INTO kemasan VALUES('131', 'VO', 'Bulk, solid, large particles ("nodules")');
INSERT INTO kemasan VALUES('132', 'VP', 'Vacuumpacked');
INSERT INTO kemasan VALUES('133', 'VQ', 'Bulk, liquefied gas (at abnormal temperature)');
INSERT INTO kemasan VALUES('134', 'VR', 'Bulk, solid, granular particles ("grains")');
INSERT INTO kemasan VALUES('135', 'VY', 'Bulk, solid, fine particles ("powders")');
INSERT INTO kemasan VALUES('136', 'WB', 'Wickerbottle');



DROP TABLE IF EXISTS konversi;

CREATE TABLE `konversi` (
  `id` int(6) NOT NULL,
  `kd_barang` varchar(100) collate latin1_general_ci NOT NULL,
  `type` varchar(100) collate latin1_general_ci NOT NULL,
  `spec` varchar(100) collate latin1_general_ci NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS konversi_detail;

CREATE TABLE `konversi_detail` (
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO konversi_detail VALUES('b00005', 'B00002', '1.00', '123');



DROP TABLE IF EXISTS kppbc;

CREATE TABLE `kppbc` (
  `id` int(4) NOT NULL auto_increment,
  `KdKpbc` varchar(100) collate latin1_general_ci NOT NULL,
  `UrKdKpbc` varchar(100) collate latin1_general_ci NOT NULL,
  `kota_kppbc` varchar(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=858 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO kppbc VALUES('1', '000000', 'KANTOR PUSAT', 'JAKARTA');
INSERT INTO kppbc VALUES('2', '010000', 'KANTOR WILAYAH I MEDAN', 'MEDAN');
INSERT INTO kppbc VALUES('3', '010201', 'BALAI PENGUJIAN DAN IDENTIFIKASI BARANG MEDAN', '');
INSERT INTO kppbc VALUES('4', '010700', 'KPBC BELAWAN', 'BELAWAN');
INSERT INTO kppbc VALUES('5', '010731', 'POS PERCUT', '');
INSERT INTO kppbc VALUES('6', '010732', 'POS PANTAI CERMIN', '');
INSERT INTO kppbc VALUES('7', '010733', 'POS PANTAI LABU', '');
INSERT INTO kppbc VALUES('8', '010734', 'POS LUBUK PAKAM', '');
INSERT INTO kppbc VALUES('9', '010735', 'POS BINJAI', '');
INSERT INTO kppbc VALUES('10', '010736', 'POS UJUNG BARU', '');
INSERT INTO kppbc VALUES('11', '010737', 'POS GUDANG MERAH', '');
INSERT INTO kppbc VALUES('12', '010738', 'POS GABION', '');
INSERT INTO kppbc VALUES('13', '010739', 'POS RANTAU PANJANG', '');
INSERT INTO kppbc VALUES('14', '010800', 'KPBC MEDAN', 'MEDAN');
INSERT INTO kppbc VALUES('15', '010838', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('16', '010839', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('17', '010840', 'POS BANDARA III', '');
INSERT INTO kppbc VALUES('18', '010900', 'KPBC PANGKALAN SUSU', 'PANGKALAN SUSU');
INSERT INTO kppbc VALUES('19', '010911', 'KANTOR BANTU PANGKALAN BRANDAN', 'PANGKALAN BRANDAN');
INSERT INTO kppbc VALUES('20', '010931', 'POS TANJUNG PURA', '');
INSERT INTO kppbc VALUES('21', '010933', 'POS PANGKALAN SUSU', '');
INSERT INTO kppbc VALUES('22', '011000', 'KPBC PEMATANG SIANTAR', 'PEMATANG SIANTAR');
INSERT INTO kppbc VALUES('23', '011031', 'POS PORSEA', '');
INSERT INTO kppbc VALUES('24', '011032', 'POS KABANJAHE', '');
INSERT INTO kppbc VALUES('25', '011033', 'POS SIDIKALANG', '');
INSERT INTO kppbc VALUES('26', '011100', 'KPBC TELUK NIBUNG', 'TELUK NIBUNG');
INSERT INTO kppbc VALUES('27', '011131', 'POS TANJUNG TIRAM', '');
INSERT INTO kppbc VALUES('28', '011134', 'POS LEIDONG', '');
INSERT INTO kppbc VALUES('29', '011135', 'POS LABUHAN BILIK', '');
INSERT INTO kppbc VALUES('30', '011137', 'POS RANTAU PRAPAT', '');
INSERT INTO kppbc VALUES('31', '011138', 'POS TELUK NIBUNG', '');
INSERT INTO kppbc VALUES('32', '011200', 'KPBC KUALA TANJUNG', 'KUALA TANJUNG');
INSERT INTO kppbc VALUES('33', '011211', 'KANTOR BANTU TEBING TINGGI', 'TEBING TINGGI');
INSERT INTO kppbc VALUES('34', '011231', 'POS BANDAR KHALIPAH', '');
INSERT INTO kppbc VALUES('35', '011232', 'POS TELUK MENGKUDU', '');
INSERT INTO kppbc VALUES('36', '011233', 'POS TANJUNG BERINGIN', '');
INSERT INTO kppbc VALUES('37', '011234', 'POS PANGKALAN DODEK', '');
INSERT INTO kppbc VALUES('38', '011235', 'POS KUALA TANJUNG', '');
INSERT INTO kppbc VALUES('39', '011300', 'KPBC SIBOLGA', 'SIBOLGA');
INSERT INTO kppbc VALUES('40', '011311', 'KANTOR BANTU GUNUNG SITOLI', '');
INSERT INTO kppbc VALUES('41', '011331', 'POS BARUS', '');
INSERT INTO kppbc VALUES('42', '011332', 'POS NATAL', '');
INSERT INTO kppbc VALUES('43', '011334', 'POS TELUK DALAM', '');
INSERT INTO kppbc VALUES('44', '011336', 'POS PULAU TELLO', '');
INSERT INTO kppbc VALUES('45', '011340', 'POS SIBOLGA', '');
INSERT INTO kppbc VALUES('46', '011500', 'KPBC TELUK BAYUR', 'TELUK BAYUR');
INSERT INTO kppbc VALUES('47', '011511', 'KANTOR BANTU SIKAKAP', '');
INSERT INTO kppbc VALUES('48', '011514', 'KANTOR BANTU TUA PEJAT', '');
INSERT INTO kppbc VALUES('49', '011531', 'POS MUARA PADANG', '');
INSERT INTO kppbc VALUES('50', '011534', 'POS SIBERUT MENTAWAI', '');
INSERT INTO kppbc VALUES('51', '011537', 'POS PARIAMAN', '');
INSERT INTO kppbc VALUES('52', '011539', 'POS PAINAN', '');
INSERT INTO kppbc VALUES('53', '011540', 'POS MUARO', '');
INSERT INTO kppbc VALUES('54', '011543', 'POS TELUK BAYUR', '');
INSERT INTO kppbc VALUES('55', '011544', 'POS CUBADAK', '');
INSERT INTO kppbc VALUES('56', '011545', 'POS AIR BANGIS', '');
INSERT INTO kppbc VALUES('57', '011546', 'POS BUNGUS', '');
INSERT INTO kppbc VALUES('58', '011547', 'POS BANDARA TABING', '');
INSERT INTO kppbc VALUES('59', '020000', 'KANTOR WILAYAH II TANJUNG BALAI KARIMUN', 'TG. BALAI KARIMUN');
INSERT INTO kppbc VALUES('60', '020100', 'KPBC TANJUNG BALAI KARIMUN', 'TG. BALAI KARIMUN');
INSERT INTO kppbc VALUES('61', '020101', 'PANGKALAN SARANA OPERASI TANJUNG BALAI KARIMUN', '');
INSERT INTO kppbc VALUES('62', '020112', 'KANTOR BANTU TELUK PAKU', '');
INSERT INTO kppbc VALUES('63', '020131', 'KANTOR BANTU MORO SULIT', '');
INSERT INTO kppbc VALUES('64', '020132', 'KANTOR BANTU TANJUNG BATU', '');
INSERT INTO kppbc VALUES('65', '020133', 'POS SAWANG', '');
INSERT INTO kppbc VALUES('66', '020134', 'POS URUNG', '');
INSERT INTO kppbc VALUES('67', '020136', 'POS TANJUNG BALAI KARIMUN', '');
INSERT INTO kppbc VALUES('68', '020137', 'POS PASIR PANJANG', '');
INSERT INTO kppbc VALUES('69', '020200', 'KPBC SAMBU BELAKANG PADANG', 'SAMBU BLK. PADANG');
INSERT INTO kppbc VALUES('70', '020231', 'POS PULAU LAYANG', '');
INSERT INTO kppbc VALUES('71', '020232', 'POS PULAU PELAMPUNG', '');
INSERT INTO kppbc VALUES('72', '020233', 'POS SUMBU BELAKANG PADANG', '');
INSERT INTO kppbc VALUES('73', '020300', 'KPBC SELAT PANJANG', 'SELAT PANJANG');
INSERT INTO kppbc VALUES('74', '020331', 'POS TANJUNG SAMAK', '');
INSERT INTO kppbc VALUES('75', '020332', 'POS TELUK BELITUNG', '');
INSERT INTO kppbc VALUES('76', '020333', 'POS TERUS', '');
INSERT INTO kppbc VALUES('77', '020336', 'POS TANJUNG KEDABU', '');
INSERT INTO kppbc VALUES('78', '020337', 'POS PENYALAI', '');
INSERT INTO kppbc VALUES('79', '020338', 'POS SELAT PANJANG', '');
INSERT INTO kppbc VALUES('80', '020339', 'POS TANJUNG MOTONG', '');
INSERT INTO kppbc VALUES('81', '020340', 'POS SERAPUNG', '');
INSERT INTO kppbc VALUES('82', '020400', 'KPBC BATAM', 'BATAM');
INSERT INTO kppbc VALUES('83', '020411', 'KANTOR BANTU PULAU REMPANG', '');
INSERT INTO kppbc VALUES('84', '020412', 'KANTOR BANTU PULAU GALANG', '');
INSERT INTO kppbc VALUES('85', '020431', 'POS PULAU BULUH', '');
INSERT INTO kppbc VALUES('86', '020432', 'POS TANJUNG RIAU', '');
INSERT INTO kppbc VALUES('87', '020433', 'POS TANJUNG UNCANG', '');
INSERT INTO kppbc VALUES('88', '020434', 'POS TANJUNG PIAYU', '');
INSERT INTO kppbc VALUES('89', '020435', 'POS BATU BESAR PANTAI', '');
INSERT INTO kppbc VALUES('90', '020436', 'POS SEI JODOH', '');
INSERT INTO kppbc VALUES('91', '020437', 'POS MOMOI', '');
INSERT INTO kppbc VALUES('92', '020438', 'POS TANJUNG SAU', '');
INSERT INTO kppbc VALUES('93', '020439', 'POS PULAU NGENANG', '');
INSERT INTO kppbc VALUES('94', '020440', 'POS JANDA BERHIAS', '');
INSERT INTO kppbc VALUES('95', '020441', 'POS TANJUNG KASEM', '');
INSERT INTO kppbc VALUES('96', '020442', 'POS TELAGA PUNGGUR', '');
INSERT INTO kppbc VALUES('97', '020443', 'POS NONGSA', '');
INSERT INTO kppbc VALUES('98', '020444', 'POS SAGULUNG', '');
INSERT INTO kppbc VALUES('99', '020445', 'POS BATU AMPAR  I', '');
INSERT INTO kppbc VALUES('100', '020446', 'POS BATU AMPAR  II', '');
INSERT INTO kppbc VALUES('101', '020447', 'POS BANDARA  I', '');
INSERT INTO kppbc VALUES('102', '020448', 'POS BANDARA  II', '');
INSERT INTO kppbc VALUES('103', '020449', 'POS MACOBAR', '');
INSERT INTO kppbc VALUES('104', '020450', 'POS KABIL', '');
INSERT INTO kppbc VALUES('105', '020453', 'POS SEKUPANG', '');
INSERT INTO kppbc VALUES('106', '020455', 'POS TANJUNG REMPANG', '');
INSERT INTO kppbc VALUES('107', '020456', 'POS TANJUNG SIPATUNG', '');
INSERT INTO kppbc VALUES('108', '020457', 'POS TANJUNG KAREPA', '');
INSERT INTO kppbc VALUES('109', '020458', 'POS POKOB BARAT', '');
INSERT INTO kppbc VALUES('110', '020459', 'POS TANJUNG CAKANG', '');
INSERT INTO kppbc VALUES('111', '020500', 'KPBC TANJUNG PINANG', 'TANJUNG PINANG');
INSERT INTO kppbc VALUES('112', '020536', 'POS TANJUNG PINANG', '');
INSERT INTO kppbc VALUES('113', '020537', 'POS BANDARA KIJANG', '');
INSERT INTO kppbc VALUES('114', '020538', 'POS PELABUHAN KIJANG', '');
INSERT INTO kppbc VALUES('115', '020600', 'KPBC TANJUNG UBAN', 'TANJUNG UBAN');
INSERT INTO kppbc VALUES('116', '020632', 'POS TANJUNG UBAN', '');
INSERT INTO kppbc VALUES('117', '020633', 'POS LAGOI', '');
INSERT INTO kppbc VALUES('118', '020634', 'POS LOBAM', '');
INSERT INTO kppbc VALUES('119', '020800', 'KPBC DABO SINGKEP', 'DABO SINGKEP');
INSERT INTO kppbc VALUES('120', '020831', 'POS PENUBA', '');
INSERT INTO kppbc VALUES('121', '020832', 'POS SUNGAI BULUH', '');
INSERT INTO kppbc VALUES('122', '020833', 'POS SENAYANG', '');
INSERT INTO kppbc VALUES('123', '020834', 'POS  DAIK', '');
INSERT INTO kppbc VALUES('124', '020835', 'POS BANDARA DABO', '');
INSERT INTO kppbc VALUES('125', '020836', 'POS DABO SINGKEP', '');
INSERT INTO kppbc VALUES('126', '020900', 'KPBC DUMAI', 'DUMAI');
INSERT INTO kppbc VALUES('127', '020911', 'KANTOR BANTU TANJUNG MEDANG', '');
INSERT INTO kppbc VALUES('128', '020931', 'POS SELAT MORONG', '');
INSERT INTO kppbc VALUES('129', '020932', 'POS TANAH PUTIH', '');
INSERT INTO kppbc VALUES('130', '020933', 'POS DUMAI', '');
INSERT INTO kppbc VALUES('131', '020934', 'POS TANJUNG MEDANG', '');
INSERT INTO kppbc VALUES('132', '021000', 'KPBC BAGAN SIAPI-API', 'BAGAN SIAPI-API');
INSERT INTO kppbc VALUES('133', '021011', 'KANTOR BANTU PENIPAHAN', '');
INSERT INTO kppbc VALUES('134', '021032', 'POS SINABOI', '');
INSERT INTO kppbc VALUES('135', '021033', 'POS LUMBA-LUMBA', '');
INSERT INTO kppbc VALUES('136', '021034', 'POS PULAU HALANG', '');
INSERT INTO kppbc VALUES('137', '021035', 'POS BAGAN SIAPI-API', '');
INSERT INTO kppbc VALUES('138', '021100', 'KPBC BENGKALIS', 'BENGKALIS');
INSERT INTO kppbc VALUES('139', '021111', 'KANTOR BANTU SUNGAI PAKNING', '');
INSERT INTO kppbc VALUES('140', '021112', 'KANTOR BANTU BANTAN TENGAH', '');
INSERT INTO kppbc VALUES('141', '021131', 'POS SIAK KECIL', '');
INSERT INTO kppbc VALUES('142', '021132', 'POS SEI KEMBUNG', '');
INSERT INTO kppbc VALUES('143', '021133', 'POS BANDUL', '');
INSERT INTO kppbc VALUES('144', '021134', 'POS BUKIT BATU', '');
INSERT INTO kppbc VALUES('145', '021136', 'POS PRAPAT TUNGGAL', '');
INSERT INTO kppbc VALUES('146', '021137', 'POS BENGKALIS', '');
INSERT INTO kppbc VALUES('147', '021200', 'KPBC PEKANBARU', 'PEKANBARU');
INSERT INTO kppbc VALUES('148', '021211', 'KANTOR BANTU PERAWANG', '');
INSERT INTO kppbc VALUES('149', '021212', 'KANTOR BANTU RUMBAI', '');
INSERT INTO kppbc VALUES('150', '021213', 'KANTOR BANTU RANTAU PANJANG', '');
INSERT INTO kppbc VALUES('151', '021231', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('152', '021232', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('153', '021233', 'POS BUATAN', '');
INSERT INTO kppbc VALUES('154', '021300', 'KPBC SIAK SRI INDRAPURA', 'SIAK SRI INDRAPURA');
INSERT INTO kppbc VALUES('155', '021331', 'POS SUNGAI APIT', '');
INSERT INTO kppbc VALUES('156', '021333', 'POS TANJUNG BUTON', '');
INSERT INTO kppbc VALUES('157', '021334', 'POS SIAK SRI INDRA PURA', '');
INSERT INTO kppbc VALUES('158', '021500', 'KPBC KUALA ENOK', 'KUALA ENOK');
INSERT INTO kppbc VALUES('159', '021511', 'KANTOR BANTU SUNGAI GUNTUNG', '');
INSERT INTO kppbc VALUES('160', '021513', 'KANTOR BANTU RENGAT', '');
INSERT INTO kppbc VALUES('161', '021531', 'POS PERIGI RAJA', '');
INSERT INTO kppbc VALUES('162', '021532', 'POS CONCONG LUAR', '');
INSERT INTO kppbc VALUES('163', '021533', 'POS SEI BULUH, INDRAGIRI', '');
INSERT INTO kppbc VALUES('164', '021534', 'POS PULAU KIJANG', '');
INSERT INTO kppbc VALUES('165', '021535', 'POS KUALA GADUNG', '');
INSERT INTO kppbc VALUES('166', '021536', 'POS KUALA BLARAS', '');
INSERT INTO kppbc VALUES('167', '021538', 'POS KUALA ENOK', '');
INSERT INTO kppbc VALUES('168', '021543', 'POS KUALACINAKU', '');
INSERT INTO kppbc VALUES('169', '021544', 'POS BANDARA JAPURA', '');
INSERT INTO kppbc VALUES('170', '021545', 'POS PULAU CAWAN', '');
INSERT INTO kppbc VALUES('171', '021546', 'POS KUALA BAYAS', '');
INSERT INTO kppbc VALUES('172', '021547', 'POS PULAU BURUNG', '');
INSERT INTO kppbc VALUES('173', '021700', 'KPBC RANAI', '');
INSERT INTO kppbc VALUES('174', '021711', 'KANTOR BANTU TAREMPA', '');
INSERT INTO kppbc VALUES('175', '021731', 'POS UDANG NATUNA', '');
INSERT INTO kppbc VALUES('176', '021732', 'POS MATAK', '');
INSERT INTO kppbc VALUES('177', '021733', 'POS SERASAN', '');
INSERT INTO kppbc VALUES('178', '021734', 'POS MIDAI', '');
INSERT INTO kppbc VALUES('179', '021735', 'POS TAMBELAN', '');
INSERT INTO kppbc VALUES('180', '021736', 'POS JEMAJA', '');
INSERT INTO kppbc VALUES('181', '021737', 'POS BUNGURAN BARAT', '');
INSERT INTO kppbc VALUES('182', '021738', 'POS BUNGURAN TIMUR', '');
INSERT INTO kppbc VALUES('183', '030000', 'KANTOR WILAYAH III PALEMBANG', 'PALEMBANG');
INSERT INTO kppbc VALUES('184', '030100', 'KPBC PALEMBANG', 'PALEMBANG');
INSERT INTO kppbc VALUES('185', '030131', 'POS TANJUNG BUYUT', '');
INSERT INTO kppbc VALUES('186', '030134', 'POS MUARAENIM', '');
INSERT INTO kppbc VALUES('187', '030135', 'POS SEKAYU', '');
INSERT INTO kppbc VALUES('188', '030136', 'POS LUBUKLINGGAU', '');
INSERT INTO kppbc VALUES('189', '030138', 'POS BATURAJA', '');
INSERT INTO kppbc VALUES('190', '030139', 'POS PALEMBANG', '');
INSERT INTO kppbc VALUES('191', '030140', 'POS PLAJU', '');
INSERT INTO kppbc VALUES('192', '030141', 'POS SUNGAI GERONG', '');
INSERT INTO kppbc VALUES('193', '030142', 'POS KERTAPATI', '');
INSERT INTO kppbc VALUES('194', '030143', 'POS PUSRI', '');
INSERT INTO kppbc VALUES('195', '030144', 'POS BANDARA S. BADARUDIN II', '');
INSERT INTO kppbc VALUES('196', '030200', 'KPBC BENGKULU', 'PULAU BAAI');
INSERT INTO kppbc VALUES('197', '030231', 'POS LINAU', '');
INSERT INTO kppbc VALUES('198', '030232', 'POS MUKO-MUKO', '');
INSERT INTO kppbc VALUES('199', '030233', 'POS PULAU ENGGANO', '');
INSERT INTO kppbc VALUES('200', '030235', 'POS P.BAI', '');
INSERT INTO kppbc VALUES('201', '030237', 'POS BANDARA PADANG KEMILANG', '');
INSERT INTO kppbc VALUES('202', '030300', 'KPBC PANGKAL PINANG', 'PANGKAL BALAM');
INSERT INTO kppbc VALUES('203', '030311', 'KANTOR BANTU BELINYU', '');
INSERT INTO kppbc VALUES('204', '030312', 'KANTOR BANTU MUNTOK', '');
INSERT INTO kppbc VALUES('205', '030332', 'POS KURAU', '');
INSERT INTO kppbc VALUES('206', '030333', 'POS SUNGAI LIAT', '');
INSERT INTO kppbc VALUES('207', '030334', 'POS LUBUK BESAR', '');
INSERT INTO kppbc VALUES('208', '030335', 'POS SUNGAI SELAN', '');
INSERT INTO kppbc VALUES('209', '030337', 'POS PANGKAL BALAM', '');
INSERT INTO kppbc VALUES('210', '030338', 'POS TOBOALI', '');
INSERT INTO kppbc VALUES('211', '030339', 'POS AIR ITAM', '');
INSERT INTO kppbc VALUES('212', '030340', 'POS DEPATI AMIR BANGKA', '');
INSERT INTO kppbc VALUES('213', '030341', 'POS JEBUS', '');
INSERT INTO kppbc VALUES('214', '030342', 'POS KAYU ARANG', '');
INSERT INTO kppbc VALUES('215', '030343', 'POS TEMPILANG', '');
INSERT INTO kppbc VALUES('216', '030344', 'POS MUNTOK', '');
INSERT INTO kppbc VALUES('217', '030500', 'KPBC TANJUNG PANDAN', 'TANJUNG PANDAN');
INSERT INTO kppbc VALUES('218', '030511', 'KANTOR BANTU MANGGAR', '');
INSERT INTO kppbc VALUES('219', '030535', 'POS TANJUNG PANDAN', '');
INSERT INTO kppbc VALUES('220', '030537', 'POS KAMPIT', '');
INSERT INTO kppbc VALUES('221', '030538', 'POS BANDARA H. AS. HANANDJOEDDIN BELITUNG', '');
INSERT INTO kppbc VALUES('222', '030600', 'KPBC JAMBI', 'JAMBI');
INSERT INTO kppbc VALUES('223', '030611', 'KANTOR BANTU KUALA TUNGKAL', '');
INSERT INTO kppbc VALUES('224', '030612', 'KANTOR BANTU MUARA SABAK', '');
INSERT INTO kppbc VALUES('225', '030631', 'POS PANGKAL DURI', '');
INSERT INTO kppbc VALUES('226', '030632', 'POS SIMBUR NAIR', '');
INSERT INTO kppbc VALUES('227', '030633', 'POS KUALA MENDAHARA', '');
INSERT INTO kppbc VALUES('228', '030634', 'POS KAMPUNG LAUT', '');
INSERT INTO kppbc VALUES('229', '030635', 'POS NIPAH PANJANG', '');
INSERT INTO kppbc VALUES('230', '030636', 'POS JAMBI', '');
INSERT INTO kppbc VALUES('231', '030637', 'POS KUALA TUNGKAL', '');
INSERT INTO kppbc VALUES('232', '030700', 'KPBC BANDAR LAMPUNG', 'PANJANG');
INSERT INTO kppbc VALUES('233', '030712', 'KANTOR BANTU KOTA AGUNG', '');
INSERT INTO kppbc VALUES('234', '030735', 'POS KALIANDA', '');
INSERT INTO kppbc VALUES('235', '030736', 'POS PUTIH MATARAM', '');
INSERT INTO kppbc VALUES('236', '030739', 'POS WAY SEPUTIH', '');
INSERT INTO kppbc VALUES('237', '030744', 'POS BAKAUHENI', '');
INSERT INTO kppbc VALUES('238', '030745', 'POS DIPASENA', '');
INSERT INTO kppbc VALUES('239', '030746', 'POS BRATASENA', '');
INSERT INTO kppbc VALUES('240', '030747', 'POS BANDARA RADIN INTEN', '');
INSERT INTO kppbc VALUES('241', '040000', 'KANTOR WILAYAH IV JAKARTA', 'JAKARTA');
INSERT INTO kppbc VALUES('242', '040100', 'KPBC TANJUNG PRIOK I', 'JAKARTA');
INSERT INTO kppbc VALUES('243', '040101', 'PANGKALAN SARANA OPERASI TANJUNG PRIOK', '');
INSERT INTO kppbc VALUES('244', '040111', 'KANTOR BANTU SUNDA KELAPA', '');
INSERT INTO kppbc VALUES('245', '040138', 'POS UTAMA E', '');
INSERT INTO kppbc VALUES('246', '040142', 'POS UTPK II', '');
INSERT INTO kppbc VALUES('247', '040143', 'POS SUNDA KELAPA', '');
INSERT INTO kppbc VALUES('248', '040145', 'POS WIDURI', '');
INSERT INTO kppbc VALUES('249', '040146', 'POS ARJUNA', '');
INSERT INTO kppbc VALUES('250', '040147', 'POS CINTA NATOMAR', '');
INSERT INTO kppbc VALUES('251', '040148', 'POS KBN', '');
INSERT INTO kppbc VALUES('252', '040149', 'POS NUSANTARA I (002)', '');
INSERT INTO kppbc VALUES('253', '040150', 'POS NUSANTARA II (005)', '');
INSERT INTO kppbc VALUES('254', '040151', 'POS 009 X', '');
INSERT INTO kppbc VALUES('255', '040152', 'POS ARSA', '');
INSERT INTO kppbc VALUES('256', '040153', 'PELAB. PELNI BARAT (POS 104)', '');
INSERT INTO kppbc VALUES('257', '040154', 'TERMINAL PENUMPANG', '');
INSERT INTO kppbc VALUES('258', '040155', 'POS LAPANGAN 207X', '');
INSERT INTO kppbc VALUES('259', '040156', 'POS BANTU KADE 301/302', '');
INSERT INTO kppbc VALUES('260', '040157', 'POS KADE 209/210', '');
INSERT INTO kppbc VALUES('261', '040158', 'BANDA', '');
INSERT INTO kppbc VALUES('262', '040159', 'MARINA ANCOL', '');
INSERT INTO kppbc VALUES('263', '040160', 'MUARA BARU', '');
INSERT INTO kppbc VALUES('264', '040200', 'KPBC TANJUNG PRIOK II', 'JAKARTA');
INSERT INTO kppbc VALUES('265', '040241', 'POS UTPK I (EKSPOR)', '');
INSERT INTO kppbc VALUES('266', '040242', 'POS UTPK I (IMPOR)', '');
INSERT INTO kppbc VALUES('267', '040245', 'POS BEA CUKAI 305', '');
INSERT INTO kppbc VALUES('268', '040246', 'POS BITUNG UTAMA A', '');
INSERT INTO kppbc VALUES('269', '040247', 'POS BITUNG UTAMA B', '');
INSERT INTO kppbc VALUES('270', '040300', 'KPBC TANJUNG PRIOK III', 'JAKARTA');
INSERT INTO kppbc VALUES('271', '040333', 'POS DWIPA I', '');
INSERT INTO kppbc VALUES('272', '040334', 'POS DWIPA II', '');
INSERT INTO kppbc VALUES('273', '040335', 'POS UTPK KOJA I', '');
INSERT INTO kppbc VALUES('274', '040337', 'AGUNG RAYA', '');
INSERT INTO kppbc VALUES('275', '040338', 'POS CILINCING', '');
INSERT INTO kppbc VALUES('276', '040339', 'POS PERTAMINA', '');
INSERT INTO kppbc VALUES('277', '040340', 'POS BOGASARI', '');
INSERT INTO kppbc VALUES('278', '040341', 'POS MARUNDA', '');
INSERT INTO kppbc VALUES('279', '040342', 'DHARMA KARYA PERDANA', '');
INSERT INTO kppbc VALUES('280', '040343', 'KALIBARU', '');
INSERT INTO kppbc VALUES('281', '040400', 'KPBC JAKARTA', 'JAKARTA');
INSERT INTO kppbc VALUES('282', '040432', 'POS UDARA HALIM PERDANA KUSUMA', '');
INSERT INTO kppbc VALUES('283', '040600', 'KPBC KANTOR POS PASAR BARU', 'JAKARTA');
INSERT INTO kppbc VALUES('284', '050000', 'KANTOR WILAYAH V BANDUNG', 'BANDUNG');
INSERT INTO kppbc VALUES('285', '050100', 'KPBC SUKARNO-HATTA', 'CENGKARENG');
INSERT INTO kppbc VALUES('286', '050132', 'POS TANGERANG', '');
INSERT INTO kppbc VALUES('287', '050134', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('288', '050135', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('289', '050136', 'POS BANDARA III', '');
INSERT INTO kppbc VALUES('290', '050300', 'KPBC BOGOR', 'BOGOR');
INSERT INTO kppbc VALUES('291', '050331', 'POS SUKABUMI', 'SUKABUMI');
INSERT INTO kppbc VALUES('292', '050336', 'POS PEL. RATU', '');
INSERT INTO kppbc VALUES('293', '050337', 'POS DEPOK', '');
INSERT INTO kppbc VALUES('294', '050338', 'POS CIANJUR', '');
INSERT INTO kppbc VALUES('295', '050339', 'POS CIBINONG', '');
INSERT INTO kppbc VALUES('296', '050400', 'KPBC MERAK', 'MERAK');
INSERT INTO kppbc VALUES('297', '050437', 'POS MERAK', '');
INSERT INTO kppbc VALUES('298', '050439', 'POS TANJUNG LENENG', '');
INSERT INTO kppbc VALUES('299', '050440', 'POS CIGADING', '');
INSERT INTO kppbc VALUES('300', '050441', 'POS CHANDRA ASRI', '');
INSERT INTO kppbc VALUES('301', '050442', 'POS CIWANDAN', '');
INSERT INTO kppbc VALUES('302', '050500', 'KPBC BANDUNG', 'BANDUNG');
INSERT INTO kppbc VALUES('303', '050531', 'POS SUMEDANG', '');
INSERT INTO kppbc VALUES('304', '050535', 'POS GEDE BAGE', '');
INSERT INTO kppbc VALUES('305', '050536', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('306', '050537', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('307', '050600', 'KPBC TASIKMALAYA', 'TASIKMALAYA');
INSERT INTO kppbc VALUES('308', '050631', 'POS GARUT', '');
INSERT INTO kppbc VALUES('309', '050632', 'POS CIAMIS', '');
INSERT INTO kppbc VALUES('310', '050633', 'POS PANGANDARAN', '');
INSERT INTO kppbc VALUES('311', '050634', 'POS TASIKMALAYA', '');
INSERT INTO kppbc VALUES('312', '050700', 'KPBC CIREBON', 'CIREBON');
INSERT INTO kppbc VALUES('313', '050711', 'KANTOR BANTU BALONGAN', '');
INSERT INTO kppbc VALUES('314', '050745', 'POS CIREBON', '');
INSERT INTO kppbc VALUES('315', '050746', 'POS NASA SARI ACID', '');
INSERT INTO kppbc VALUES('316', '050747', 'POS PALIMANAN', '');
INSERT INTO kppbc VALUES('317', '050800', 'KPBC PURWAKARTA', 'PURWAKARTA');
INSERT INTO kppbc VALUES('318', '050833', 'POS PURWAKARTA', '');
INSERT INTO kppbc VALUES('319', '050834', 'POS SUBANG', '');
INSERT INTO kppbc VALUES('320', '050836', 'POS CILAMAYA', '');
INSERT INTO kppbc VALUES('321', '050900', 'KPBC BEKASI', 'BEKASI');
INSERT INTO kppbc VALUES('322', '060000', 'KANTOR WILAYAH VI SEMARANG', 'SEMARANG');
INSERT INTO kppbc VALUES('323', '060100', 'KPBC TANJUNG EMAS', 'SEMARANG');
INSERT INTO kppbc VALUES('324', '060133', 'POS DEMAK', '');
INSERT INTO kppbc VALUES('325', '060134', 'POS PURWODADI', '');
INSERT INTO kppbc VALUES('326', '060135', 'POS SALATIGA', '');
INSERT INTO kppbc VALUES('327', '060136', 'POS TANJUNG EMAS I', '');
INSERT INTO kppbc VALUES('328', '060137', 'POS TANJUNG EMAS II', '');
INSERT INTO kppbc VALUES('329', '060138', 'POS TANJUNG EMAS III', '');
INSERT INTO kppbc VALUES('330', '060139', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('331', '060140', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('332', '060141', 'POS KALIWUNGU', '');
INSERT INTO kppbc VALUES('333', '060143', 'POS LIK SEMARANG', '');
INSERT INTO kppbc VALUES('334', '060200', 'KPBC PEKALONGAN', 'PEKALONGAN');
INSERT INTO kppbc VALUES('335', '060235', 'POS BATANG', '');
INSERT INTO kppbc VALUES('336', '060236', 'POS PEKALONGAN', '');
INSERT INTO kppbc VALUES('337', '060300', 'KPBC KUDUS', 'KUDUS');
INSERT INTO kppbc VALUES('338', '060311', 'KANTOR BANTU JUWONO', '');
INSERT INTO kppbc VALUES('339', '060312', 'KANTOR BANTU JEPARA', '');
INSERT INTO kppbc VALUES('340', '060332', 'POS BANYUTOWO', '');
INSERT INTO kppbc VALUES('341', '060333', 'POS REMBANG', 'REMBANG');
INSERT INTO kppbc VALUES('342', '060334', 'POS CEPU', 'CEPU');
INSERT INTO kppbc VALUES('343', '060338', 'POS BLORA', '');
INSERT INTO kppbc VALUES('344', '060339', 'POS KARIMUN JAWA', '');
INSERT INTO kppbc VALUES('345', '060400', 'KPBC CILACAP', 'CILACAP');
INSERT INTO kppbc VALUES('346', '060412', 'KANTOR BANTU PURWOKERTO', '');
INSERT INTO kppbc VALUES('347', '060413', 'KANTOR BANTU KEBUMEN', '');
INSERT INTO kppbc VALUES('348', '060431', 'POS BANDARA TUNGGUL WULUNG', '');
INSERT INTO kppbc VALUES('349', '060433', 'POS MAJENANG', '');
INSERT INTO kppbc VALUES('350', '060434', 'POS TANJUNG INTAN', '');
INSERT INTO kppbc VALUES('351', '060435', 'POS PURBALINGGA', '');
INSERT INTO kppbc VALUES('352', '060436', 'POS BANJARNEGARA', '');
INSERT INTO kppbc VALUES('353', '060437', 'POS PURWOREJO', '');
INSERT INTO kppbc VALUES('354', '060500', 'KPPBC PURWOKERTO', 'PURWOKERTO');
INSERT INTO kppbc VALUES('355', '060600', 'KPBC SURAKARTA', 'SURAKARTA');
INSERT INTO kppbc VALUES('356', '060637', 'POS KEBAK KRAMAT', '');
INSERT INTO kppbc VALUES('357', '060638', 'POS KLATEN', '');
INSERT INTO kppbc VALUES('358', '060639', 'POS KARANGANYAR', '');
INSERT INTO kppbc VALUES('359', '060640', 'POS SRAGEN', '');
INSERT INTO kppbc VALUES('360', '060641', 'POS SUKOHARDJO', '');
INSERT INTO kppbc VALUES('361', '060642', 'POS WONOGIRI', '');
INSERT INTO kppbc VALUES('362', '060643', 'POS BOYOLALI', '');
INSERT INTO kppbc VALUES('363', '060644', 'POS JEBRES', '');
INSERT INTO kppbc VALUES('364', '060645', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('365', '060646', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('366', '060700', 'KPBC YOGYAKARTA', 'YOGYAKARTA');
INSERT INTO kppbc VALUES('367', '060711', 'KANTOR BANTU MAGELANG', '');
INSERT INTO kppbc VALUES('368', '060732', 'POS SLEMAN', '');
INSERT INTO kppbc VALUES('369', '060733', 'POS WATES', '');
INSERT INTO kppbc VALUES('370', '060734', 'POS BANTUL', '');
INSERT INTO kppbc VALUES('371', '060735', 'POS WONOSARI', '');
INSERT INTO kppbc VALUES('372', '060736', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('373', '060737', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('374', '060738', 'POS TEMANGGUNG', '');
INSERT INTO kppbc VALUES('375', '060739', 'POS WONOSOBO', '');
INSERT INTO kppbc VALUES('376', '061000', 'KPBC TEGAL', 'TEGAL');
INSERT INTO kppbc VALUES('377', '061035', 'POS BREBES', 'BREBES');
INSERT INTO kppbc VALUES('378', '061036', 'POS PEMALANG', '');
INSERT INTO kppbc VALUES('379', '061037', 'POS SLAWI', '');
INSERT INTO kppbc VALUES('380', '061038', 'POS COMAL', '');
INSERT INTO kppbc VALUES('381', '061039', 'POS SURODADI', '');
INSERT INTO kppbc VALUES('382', '061040', 'POS TEGAL', '');
INSERT INTO kppbc VALUES('383', '061041', 'POS SUGIH WARAS', '');
INSERT INTO kppbc VALUES('384', '070000', 'KANTOR WILAYAH VII SURABAYA', 'SURABAYA');
INSERT INTO kppbc VALUES('385', '070100', 'KPBC TANJUNG PERAK', 'SURABAYA');
INSERT INTO kppbc VALUES('386', '070134', 'POS ICT I', '');
INSERT INTO kppbc VALUES('387', '070135', 'POS ICT II', '');
INSERT INTO kppbc VALUES('388', '070136', 'POS NILAM I', '');
INSERT INTO kppbc VALUES('389', '070137', 'POS NILAM II', '');
INSERT INTO kppbc VALUES('390', '070138', 'POS BERLIAN I', '');
INSERT INTO kppbc VALUES('391', '070139', 'POS BERLIAN II', '');
INSERT INTO kppbc VALUES('392', '070140', 'POS MIRAH I', '');
INSERT INTO kppbc VALUES('393', '070141', 'POS MIRAH II', '');
INSERT INTO kppbc VALUES('394', '070142', 'POS JAMRUD I', '');
INSERT INTO kppbc VALUES('395', '070143', 'POS JAMRUD II', '');
INSERT INTO kppbc VALUES('396', '070144', 'POS ICT III', '');
INSERT INTO kppbc VALUES('397', '070145', 'POS ICT IV', '');
INSERT INTO kppbc VALUES('398', '070200', 'KPBC KALIANGET', 'KALIANGET');
INSERT INTO kppbc VALUES('399', '070201', 'BALAI PENGUJIAN DAN IDENTIFIKASI BARANG SURABAYA', '');
INSERT INTO kppbc VALUES('400', '070233', 'POS PASEAN', '');
INSERT INTO kppbc VALUES('401', '070234', 'POS SAMPANG', 'SAMPANG');
INSERT INTO kppbc VALUES('402', '070236', 'POS BONGKEK', '');
INSERT INTO kppbc VALUES('403', '070239', 'POS SAPUDI', '');
INSERT INTO kppbc VALUES('404', '070240', 'POS KANGEAN', '');
INSERT INTO kppbc VALUES('405', '070243', 'POS BRANTA', '');
INSERT INTO kppbc VALUES('406', '070244', 'POS BANDARA TRUNOJOYO', '');
INSERT INTO kppbc VALUES('407', '070245', 'POS KALIANGET', '');
INSERT INTO kppbc VALUES('408', '070246', 'POS TELAGA BIRU', '');
INSERT INTO kppbc VALUES('409', '070247', 'POS PAGERUNGAN', '');
INSERT INTO kppbc VALUES('410', '070300', 'KPBC GRESIK', 'GRESIK');
INSERT INTO kppbc VALUES('411', '070331', 'POS TAMBAK', '');
INSERT INTO kppbc VALUES('412', '070332', 'POS SEDAYULAWAS', '');
INSERT INTO kppbc VALUES('413', '070334', 'POS LAMONGAN', '');
INSERT INTO kppbc VALUES('414', '070335', 'POS GRESIK', '');
INSERT INTO kppbc VALUES('415', '070336', 'POS POLENG', '');
INSERT INTO kppbc VALUES('416', '070337', 'POS SANGKA PURA', '');
INSERT INTO kppbc VALUES('417', '070338', 'POS NGIMBOH', '');
INSERT INTO kppbc VALUES('418', '070400', 'KPBC BOJONEGORO', 'BOJONEGORO');
INSERT INTO kppbc VALUES('419', '070431', 'POS GLONDONG', '');
INSERT INTO kppbc VALUES('420', '070432', 'POS SOCOREJO-JENU', '');
INSERT INTO kppbc VALUES('421', '070433', 'POS TUBAN', '');
INSERT INTO kppbc VALUES('422', '070500', 'KPBC JUANDA', 'SURABAYA');
INSERT INTO kppbc VALUES('423', '070531', 'POS MOJOKERTO', 'MOJOKERTO');
INSERT INTO kppbc VALUES('424', '070533', 'POS SIDOARJO', 'SIDOARJO');
INSERT INTO kppbc VALUES('425', '070539', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('426', '070540', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('427', '070541', 'POS BANDARA III', '');
INSERT INTO kppbc VALUES('428', '070543', 'POS WATES', '');
INSERT INTO kppbc VALUES('429', '070600', 'KPBC MALANG', 'MALANG');
INSERT INTO kppbc VALUES('430', '070634', 'POS SENDANG BIRU', '');
INSERT INTO kppbc VALUES('431', '070635', 'POS BANDARA ABDULRACHMAN SALEH', '');
INSERT INTO kppbc VALUES('432', '070700', 'KPBC BLITAR', 'BLITAR');
INSERT INTO kppbc VALUES('433', '070800', 'KPBC KEDIRI', 'KEDIRI');
INSERT INTO kppbc VALUES('434', '070831', 'POS NGANJUK', 'NGANJUK');
INSERT INTO kppbc VALUES('435', '070833', 'POS KERTOSONO', 'KERTOSONO');
INSERT INTO kppbc VALUES('436', '070834', 'POS CUKIR', '');
INSERT INTO kppbc VALUES('437', '070835', 'POS JOMBANG', 'JOMBANG');
INSERT INTO kppbc VALUES('438', '070900', 'KPBC TULUNGAGUNG', 'TULUNGAGUNG');
INSERT INTO kppbc VALUES('439', '070932', 'POS POPOH', '');
INSERT INTO kppbc VALUES('440', '071000', 'KPBC MADIUN', 'MADIUN');
INSERT INTO kppbc VALUES('441', '071031', 'POS MAGETAN', 'MAGETAN');
INSERT INTO kppbc VALUES('442', '071032', 'POS NGAWI', 'NGAWI');
INSERT INTO kppbc VALUES('443', '071033', 'POS PONOROGO', 'PONOROGO');
INSERT INTO kppbc VALUES('444', '071034', 'POS CARUBAN', 'CARUBAN');
INSERT INTO kppbc VALUES('445', '071035', 'POS PACITAN', 'PACITAN');
INSERT INTO kppbc VALUES('446', '071100', 'KPBC PANARUKAN', 'PANARUKAN');
INSERT INTO kppbc VALUES('447', '071112', 'KANTOR BANTU TANJUNG WANGI', '');
INSERT INTO kppbc VALUES('448', '071132', 'POS JEMBER', 'JEMBER');
INSERT INTO kppbc VALUES('449', '071134', 'POS SITUBONDO', 'SITUBONDO');
INSERT INTO kppbc VALUES('450', '071135', 'POS BESUKI', '');
INSERT INTO kppbc VALUES('451', '071136', 'POS KALBUT', '');
INSERT INTO kppbc VALUES('452', '071137', 'POS JANGKAR', '');
INSERT INTO kppbc VALUES('453', '071138', 'POS BONDOWOSO', '');
INSERT INTO kppbc VALUES('454', '071139', 'POS PUGER', '');
INSERT INTO kppbc VALUES('455', '071140', 'POS PANARUKAN', '');
INSERT INTO kppbc VALUES('456', '071141', 'POS RAMBI PUJI', '');
INSERT INTO kppbc VALUES('457', '071142', 'POS BANYUWANGI', '');
INSERT INTO kppbc VALUES('458', '071143', 'POS TANJUNG WANGI', '');
INSERT INTO kppbc VALUES('459', '071144', 'POS MUNCAR', '');
INSERT INTO kppbc VALUES('460', '071145', 'POS GRAJAGAN', '');
INSERT INTO kppbc VALUES('461', '071146', 'POS KETAPANG', '');
INSERT INTO kppbc VALUES('462', '071200', 'KPBC PROBOLINGGO', 'PROBOLINGGO');
INSERT INTO kppbc VALUES('463', '071232', 'POS PEJARAKAN', '');
INSERT INTO kppbc VALUES('464', '071235', 'POS LUMAJANG', '');
INSERT INTO kppbc VALUES('465', '071236', 'POS PAITON', '');
INSERT INTO kppbc VALUES('466', '071237', 'POS PROBOLINGGO', '');
INSERT INTO kppbc VALUES('467', '071300', 'KPBC PASURUAN', 'PASURUAN');
INSERT INTO kppbc VALUES('468', '071333', 'POS PASURUAN', '');
INSERT INTO kppbc VALUES('469', '071334', 'POS LEKOK', '');
INSERT INTO kppbc VALUES('470', '080000', 'KANTOR WILAYAH VIII DENPASAR', 'DENPASAR');
INSERT INTO kppbc VALUES('471', '080100', 'KPBC NGURAH RAI', 'DENPASAR');
INSERT INTO kppbc VALUES('472', '080131', 'POS BANDARA I', '');
INSERT INTO kppbc VALUES('473', '080132', 'POS BANDARA II', '');
INSERT INTO kppbc VALUES('474', '080133', 'POS BANDARA III', '');
INSERT INTO kppbc VALUES('475', '080134', 'POS KARANGASEM', '');
INSERT INTO kppbc VALUES('476', '080135', 'POS BANGLI', '');
INSERT INTO kppbc VALUES('477', '080136', 'POS KLUNGKUNG', '');
INSERT INTO kppbc VALUES('478', '080137', 'POS GIANYAR', '');
INSERT INTO kppbc VALUES('479', '080138', 'POS TABANAN', '');
INSERT INTO kppbc VALUES('480', '080139', 'POS PINTU UTAMA PADANG BAI', '');
INSERT INTO kppbc VALUES('481', '080140', 'POS DARMAGA PADANG BAI', '');
INSERT INTO kppbc VALUES('482', '080141', 'POS PERTAMINA AMUK', '');
INSERT INTO kppbc VALUES('483', '080300', 'KPBC MATARAM', 'LEMBAR');
INSERT INTO kppbc VALUES('484', '080331', 'POS LABUHAN HAJI', '');
INSERT INTO kppbc VALUES('485', '080332', 'POS LABUHAN LOMBOK', '');
INSERT INTO kppbc VALUES('486', '080333', 'POS BANDARA SELAPARANG', '');
INSERT INTO kppbc VALUES('487', '080334', 'POS LEMBAR', '');
INSERT INTO kppbc VALUES('488', '080335', 'POS PEMENANG', '');
INSERT INTO kppbc VALUES('489', '080400', 'KPBC BIMA', 'BIMA');
INSERT INTO kppbc VALUES('490', '080411', 'KANTOR BANTU BADAS SUMBAWA', '');
INSERT INTO kppbc VALUES('491', '080412', 'KANTOR BANTU BENETE', '');
INSERT INTO kppbc VALUES('492', '080431', 'POS SAPE', '');
INSERT INTO kppbc VALUES('493', '080432', 'POS LABUHAN ALAS', '');
INSERT INTO kppbc VALUES('494', '080433', 'POS BANDARA BRANG BIJI', '');
INSERT INTO kppbc VALUES('495', '080434', 'POS BANDARA PALIBELO', '');
INSERT INTO kppbc VALUES('496', '080435', 'POS BIMA', '');
INSERT INTO kppbc VALUES('497', '080437', 'POS PEL. FERRY POTOTANO', '');
INSERT INTO kppbc VALUES('498', '080439', 'POS KEMPU', '');
INSERT INTO kppbc VALUES('499', '080500', 'KPBC KUPANG', 'TENAU KUPANG');
INSERT INTO kppbc VALUES('500', '080513', 'KANTOR BANTU WAINGAPU', '');
INSERT INTO kppbc VALUES('501', '080536', 'POS BAA/P. ROTE', '');
INSERT INTO kppbc VALUES('502', '080537', 'POS BANDARA MAUHAI', '');
INSERT INTO kppbc VALUES('503', '080538', 'POS BANDARA TAMBOLAKA', '');
INSERT INTO kppbc VALUES('504', '080539', 'POS RUA', '');
INSERT INTO kppbc VALUES('505', '080540', 'POS TENAU', '');
INSERT INTO kppbc VALUES('506', '080700', 'KPBC MAUMERE', 'MAUMERE');
INSERT INTO kppbc VALUES('507', '080711', 'KANTOR BANTU LARANTUKA', '');
INSERT INTO kppbc VALUES('508', '080712', 'KANTOR BANTU KEDINDI REO', '');
INSERT INTO kppbc VALUES('509', '080713', 'KANTOR BANTU ENDE (PL dan POS LALU BEA)', '');
INSERT INTO kppbc VALUES('510', '080731', 'POS LABUHAN BAJO (PU)', '');
INSERT INTO kppbc VALUES('511', '080733', 'POS BANDARA SATARTACIK', '');
INSERT INTO kppbc VALUES('512', '080734', 'POS BANDARA GEWAYANGTANA', '');
INSERT INTO kppbc VALUES('513', '080735', 'POS BANDARA WAJOTI', '');
INSERT INTO kppbc VALUES('514', '080737', 'POS BANDARA PADHA MALEDA', '');
INSERT INTO kppbc VALUES('515', '080738', 'POS MAUMERE', '');
INSERT INTO kppbc VALUES('516', '080739', 'POS ENDE IPI', '');
INSERT INTO kppbc VALUES('517', '080740', 'POS BANDARA H. AROEBOESMAN', '');
INSERT INTO kppbc VALUES('518', '080741', 'POS LABUHAN BAJO dan KOMODO (PL)', '');
INSERT INTO kppbc VALUES('519', '081200', 'KPBC BENOA', '');
INSERT INTO kppbc VALUES('520', '081211', 'KANTOR BANTU CELUKAN BAWANG', '');
INSERT INTO kppbc VALUES('521', '081231', 'POS NUSA PANIDA', '');
INSERT INTO kppbc VALUES('522', '081232', 'POS DARMAGA CARGO I', '');
INSERT INTO kppbc VALUES('523', '081233', 'POS DARMAGA CARGO II', '');
INSERT INTO kppbc VALUES('524', '081234', 'POS DARMAGA KAPAL IKAN', '');
INSERT INTO kppbc VALUES('525', '081235', 'POS DARMAGA KAPAL TURIS', '');
INSERT INTO kppbc VALUES('526', '081237', 'POS BULELENG', '');
INSERT INTO kppbc VALUES('527', '081238', 'POS NEGARA', '');
INSERT INTO kppbc VALUES('528', '081239', 'POS GILIMANUK', '');
INSERT INTO kppbc VALUES('529', '081300', 'KPBC ATAPUPU', '');
INSERT INTO kppbc VALUES('530', '081311', 'KANTOR BANTU MOTA AIN (LBD)', '');
INSERT INTO kppbc VALUES('531', '081312', 'KANTOR BANTU MOTA MAUK (LBD)', '');
INSERT INTO kppbc VALUES('532', '081313', 'KANTOR BANTU NAPAN (LBD)', '');
INSERT INTO kppbc VALUES('533', '081314', 'KANTOR BANTU KALABAHI (LBD)', '');
INSERT INTO kppbc VALUES('534', '081331', 'POS BANDARA HALIWEN', '');
INSERT INTO kppbc VALUES('535', '081332', 'POS LINTAS BATAS DAERAH WINI', '');
INSERT INTO kppbc VALUES('536', '081333', 'POS BANDARA MALI', '');
INSERT INTO kppbc VALUES('537', '090000', 'KANTOR WILAYAH IX PONTIANAK', 'PONTIANAK');
INSERT INTO kppbc VALUES('538', '090100', 'KPBC PONTIANAK', 'PONTIANAK');
INSERT INTO kppbc VALUES('539', '090111', 'KANTOR BANTU BANDARA SUPADIO', '');
INSERT INTO kppbc VALUES('540', '090131', 'POS JUNGKAT', '');
INSERT INTO kppbc VALUES('541', '090137', 'POS PONTIANAK', '');
INSERT INTO kppbc VALUES('542', '090138', 'POS SUNGAI KAKAP', '');
INSERT INTO kppbc VALUES('543', '090200', 'KPBC ENTIKONG', 'ENTIKONG');
INSERT INTO kppbc VALUES('544', '090211', 'KANTOR BANTU NANGAU BADAU', '');
INSERT INTO kppbc VALUES('545', '090231', 'POS MARAKAI PANJANG', '');
INSERT INTO kppbc VALUES('546', '090234', 'POS SIMPANG TIGA LUBUK SABUK', '');
INSERT INTO kppbc VALUES('547', '090235', 'POS SEGUMON', '');
INSERT INTO kppbc VALUES('548', '090236', 'POS BANTAN', '');
INSERT INTO kppbc VALUES('549', '090238', 'POS NANGA BAYAN', '');
INSERT INTO kppbc VALUES('550', '090300', 'KPBC TELUK AIR', 'TELUK AIR');
INSERT INTO kppbc VALUES('551', '090331', 'POS KUBU', '');
INSERT INTO kppbc VALUES('552', '090332', 'POS TELUK AIR', '');
INSERT INTO kppbc VALUES('553', '090333', 'POS PADANG TIKAR', '');
INSERT INTO kppbc VALUES('554', '090400', 'KPBC KETAPANG', 'KETAPANG');
INSERT INTO kppbc VALUES('555', '090411', 'KANTOR BANTU KENDAWANGAN', '');
INSERT INTO kppbc VALUES('556', '090431', 'POS TELUK BATANG', '');
INSERT INTO kppbc VALUES('557', '090433', 'POS TELUK MELANO', '');
INSERT INTO kppbc VALUES('558', '090434', 'POS KETAPANG', '');
INSERT INTO kppbc VALUES('559', '090435', 'POS BANDARA RAHADI USMAN', '');
INSERT INTO kppbc VALUES('560', '090500', 'KPBC SINTETE', 'SINTETE');
INSERT INTO kppbc VALUES('561', '090511', 'KANTOR BANTU JAGOI BABANG', '');
INSERT INTO kppbc VALUES('562', '090512', 'KANTOR BANTU SAMBAS', '');
INSERT INTO kppbc VALUES('563', '090531', 'POS SINGKAWANG', 'SINGKAWANG');
INSERT INTO kppbc VALUES('564', '090532', 'POS TELUK SUAK', '');
INSERT INTO kppbc VALUES('565', '090534', 'POS SIDDING', '');
INSERT INTO kppbc VALUES('566', '090537', 'POS PEMANGKAT', '');
INSERT INTO kppbc VALUES('567', '090538', 'POS PENJAJAB', '');
INSERT INTO kppbc VALUES('568', '090539', 'POS ARUK', '');
INSERT INTO kppbc VALUES('569', '090540', 'POS SAJINGAN', '');
INSERT INTO kppbc VALUES('570', '090541', 'POS SAPARAN', '');
INSERT INTO kppbc VALUES('571', '090542', 'POS TEMAJUK', '');
INSERT INTO kppbc VALUES('572', '090543', 'POS TEBAS', '');
INSERT INTO kppbc VALUES('573', '090700', 'KPBC SAMPIT', 'SAMPIT');
INSERT INTO kppbc VALUES('574', '090731', 'POS SAMUDA', '');
INSERT INTO kppbc VALUES('575', '090732', 'POS KUALA PEMBUANG', '');
INSERT INTO kppbc VALUES('576', '090733', 'POS PEGATAN MENDAWAI', '');
INSERT INTO kppbc VALUES('577', '090734', 'POS BANDARA H.ASAN', '');
INSERT INTO kppbc VALUES('578', '090735', 'POS SAMPIT', '');
INSERT INTO kppbc VALUES('579', '090800', 'KPBC PANGKALAN BUN', 'PANGKALAN BUN');
INSERT INTO kppbc VALUES('580', '090811', 'KANTOR BANTU KUMAI', '');
INSERT INTO kppbc VALUES('581', '090831', 'POS MUARA S. ARUT', '');
INSERT INTO kppbc VALUES('582', '090833', 'POS KUALA JELAI', '');
INSERT INTO kppbc VALUES('583', '090834', 'POS BANDARA ISKANDAR', '');
INSERT INTO kppbc VALUES('584', '090835', 'POS PANGKALAN BUN', '');
INSERT INTO kppbc VALUES('585', '090900', 'KPBC PULANG PISAU', 'PULANG PISAU');
INSERT INTO kppbc VALUES('586', '090911', 'KANTOR BANTU KUALA KAPUAS', '');
INSERT INTO kppbc VALUES('587', '090931', 'POS BAHAUR', '');
INSERT INTO kppbc VALUES('588', '090932', 'POS BANDARA CILIKRIWUT', '');
INSERT INTO kppbc VALUES('589', '090933', 'POS BANDARA BERINGIN', '');
INSERT INTO kppbc VALUES('590', '090934', 'POS PULANG PISAU', '');
INSERT INTO kppbc VALUES('591', '090935', 'POS MANGKAHOI', '');
INSERT INTO kppbc VALUES('592', '100000', 'KANTOR WILAYAH X BALIKPAPAN', 'BALIKPAPAN');
INSERT INTO kppbc VALUES('593', '100100', 'KPBC BANJARMASIN', 'BANJARMASIN');
INSERT INTO kppbc VALUES('594', '100131', 'POS BANDARA SAMSUDIN NOOR', 'BANJARMASIN');
INSERT INTO kppbc VALUES('595', '100134', 'POS BANDARA WARUKIN', '');
INSERT INTO kppbc VALUES('596', '100135', 'POS ASAM-ASAM / KINTAP', '');
INSERT INTO kppbc VALUES('597', '100136', 'POS BANJARMASIN', '');
INSERT INTO kppbc VALUES('598', '100137', 'POS JORONG', '');
INSERT INTO kppbc VALUES('599', '100200', 'KPBC KOTABARU', 'KOTABARU');
INSERT INTO kppbc VALUES('600', '100211', 'KANTOR BANTU BATU LICIN', '');
INSERT INTO kppbc VALUES('601', '100231', 'POS PEGATAN', '');
INSERT INTO kppbc VALUES('602', '100233', 'POS TG.PEMANCINGAN', '');
INSERT INTO kppbc VALUES('603', '100234', 'POS MEKAR PUTIH', '');
INSERT INTO kppbc VALUES('604', '100235', 'POS BANDARA STAGEN', '');
INSERT INTO kppbc VALUES('605', '100236', 'POS KOTA BARU', '');
INSERT INTO kppbc VALUES('606', '100237', 'POS TARJUN', '');
INSERT INTO kppbc VALUES('607', '100239', 'POS PELABUHAN STAGEN', '');
INSERT INTO kppbc VALUES('608', '100240', 'POS SATUI', '');
INSERT INTO kppbc VALUES('609', '100300', 'KPBC BALIKPAPAN', 'BALIKPAPAN');
INSERT INTO kppbc VALUES('610', '100312', 'KANTOR BANTU TANAH GROGOT', '');
INSERT INTO kppbc VALUES('611', '100313', 'KANTOR BANTU TANJUNG SANTAN', '');
INSERT INTO kppbc VALUES('612', '100331', 'POS KAMPUNG BARU', '');
INSERT INTO kppbc VALUES('613', '100332', 'POS PENAJAM', '');
INSERT INTO kppbc VALUES('614', '100335', 'POS BALIKPAPAN', '');
INSERT INTO kppbc VALUES('615', '100336', 'POS TANJUNG BATU', '');
INSERT INTO kppbc VALUES('616', '100337', 'POS KARIANGGAU', '');
INSERT INTO kppbc VALUES('617', '100500', 'KPBC SAMARINDA', 'SAMARINDA');
INSERT INTO kppbc VALUES('618', '100512', 'KANTOR BANTU SENIPAH', '');
INSERT INTO kppbc VALUES('619', '100531', 'POS HANDIL DUA', '');
INSERT INTO kppbc VALUES('620', '100532', 'POS MUARA SANGA-SANGA', '');
INSERT INTO kppbc VALUES('621', '100534', 'POS MUARA BADAK', '');
INSERT INTO kppbc VALUES('622', '100535', 'POS TENGGARONG', '');
INSERT INTO kppbc VALUES('623', '100536', 'POS BANDARA TEMINDUNG', '');
INSERT INTO kppbc VALUES('624', '100538', 'POS SAMARINDA', '');
INSERT INTO kppbc VALUES('625', '100600', 'KPBC BONTANG', 'BONTANG');
INSERT INTO kppbc VALUES('626', '100631', 'POS LHOK TUAN', '');
INSERT INTO kppbc VALUES('627', '100632', 'POS BONTANG', '');
INSERT INTO kppbc VALUES('628', '100633', 'POS NYERANGAT SEKAMBING', '');
INSERT INTO kppbc VALUES('629', '100800', 'KPBC TARAKAN', 'TARAKAN');
INSERT INTO kppbc VALUES('630', '100811', 'KANTOR BANTU BUNYU', '');
INSERT INTO kppbc VALUES('631', '100812', 'KANTOR BANTU REDEP', '');
INSERT INTO kppbc VALUES('632', '100832', 'POS TANJUNG SELOR', '');
INSERT INTO kppbc VALUES('633', '100833', 'POS BANDARA TARAKAN', '');
INSERT INTO kppbc VALUES('634', '100834', 'POS BANDARA TANJUNG REDEP', '');
INSERT INTO kppbc VALUES('635', '100835', 'POS TARAKAN', '');
INSERT INTO kppbc VALUES('636', '100836', 'POS BUNYU', '');
INSERT INTO kppbc VALUES('637', '100837', 'POS LONG NAWANG', '');
INSERT INTO kppbc VALUES('638', '100838', 'POS LONG BAWAN', '');
INSERT INTO kppbc VALUES('639', '100839', 'POS MALINO', '');
INSERT INTO kppbc VALUES('640', '100900', 'KPBC NUNUKAN', 'NUNUKAN');
INSERT INTO kppbc VALUES('641', '100912', 'KANTOR BANTU SUNGAI NYAMUK', '');
INSERT INTO kppbc VALUES('642', '100932', 'POS LEMIJUNG', '');
INSERT INTO kppbc VALUES('643', '100933', 'POS NUNUKAN', '');
INSERT INTO kppbc VALUES('644', '100934', 'POS SUNGAI PANCANG', '');
INSERT INTO kppbc VALUES('645', '100935', 'POS AJI KUNING', '');
INSERT INTO kppbc VALUES('646', '101000', 'KPBC TANJUNG BARA /SANGATA', '');
INSERT INTO kppbc VALUES('647', '101031', 'POS SANGKURILANG', '');
INSERT INTO kppbc VALUES('648', '101032', 'POS TANJUNG BARA SANGATA', '');
INSERT INTO kppbc VALUES('649', '110000', 'KANTOR WILAYAH XI MAKASAR', 'MAKASSAR');
INSERT INTO kppbc VALUES('650', '110100', 'KPBC MAKASAR', 'MAKASSAR');
INSERT INTO kppbc VALUES('651', '110101', 'PANGKALAN SARANA OPERASI PANTOLOAN', '');
INSERT INTO kppbc VALUES('652', '110111', 'KANTOR BANTU BENTENG/P.SELAYAR', '');
INSERT INTO kppbc VALUES('653', '110113', 'KANTOR BANTU BIRINGKASI', '');
INSERT INTO kppbc VALUES('654', '110131', 'POS BANTAENG', '');
INSERT INTO kppbc VALUES('655', '110132', 'POS BULU KUMBA', '');
INSERT INTO kppbc VALUES('656', '110138', 'POS PAOTERE', '');
INSERT INTO kppbc VALUES('657', '110139', 'POS SUKARNO I', '');
INSERT INTO kppbc VALUES('658', '110140', 'POS SUKARNO II', '');
INSERT INTO kppbc VALUES('659', '110141', 'POS HATTA I', '');
INSERT INTO kppbc VALUES('660', '110142', 'POS HATTAII', '');
INSERT INTO kppbc VALUES('661', '110300', 'KPBC PARE-PARE', 'PARE-PARE');
INSERT INTO kppbc VALUES('662', '110332', 'POS BARRU', '');
INSERT INTO kppbc VALUES('663', '110339', 'POS PARE-PARE', '');
INSERT INTO kppbc VALUES('664', '110340', 'POS WATANSOPPENG', '');
INSERT INTO kppbc VALUES('665', '110342', 'POS MAMUJU', '');
INSERT INTO kppbc VALUES('666', '110400', 'KPBC MALILI', 'BALANTANG');
INSERT INTO kppbc VALUES('667', '110411', 'KANTOR BANTU PALOPO', 'PALOPO');
INSERT INTO kppbc VALUES('668', '110433', 'POS SIWA', '');
INSERT INTO kppbc VALUES('669', '110436', 'POS BALANTANG', '');
INSERT INTO kppbc VALUES('670', '110437', 'POS BANDARA SOROAKO', '');
INSERT INTO kppbc VALUES('671', '110500', 'KPBC BAJOE', 'BAJOE');
INSERT INTO kppbc VALUES('672', '110533', 'POS SINJAI', '');
INSERT INTO kppbc VALUES('673', '110535', 'POS ULOE', '');
INSERT INTO kppbc VALUES('674', '110537', 'POS BAJOE', '');
INSERT INTO kppbc VALUES('675', '110539', 'POS ARESOE', '');
INSERT INTO kppbc VALUES('676', '110540', 'POS PATTIRO', '');
INSERT INTO kppbc VALUES('677', '110600', 'KPBC KENDARI', 'KENDARI');
INSERT INTO kppbc VALUES('678', '110611', 'KANTOR BANTU BAU-BAU', '');
INSERT INTO kppbc VALUES('679', '110631', 'POS WAWONI', '');
INSERT INTO kppbc VALUES('680', '110632', 'POS LASOLO', '');
INSERT INTO kppbc VALUES('681', '110634', 'POS WANCI', '');
INSERT INTO kppbc VALUES('682', '110635', 'POS RAHA', '');
INSERT INTO kppbc VALUES('683', '110636', 'POS SIKELI', '');
INSERT INTO kppbc VALUES('684', '110637', 'POS BANABUNI', '');
INSERT INTO kppbc VALUES('685', '110638', 'POS BANDARA WOLTER MONGINSIDI', '');
INSERT INTO kppbc VALUES('686', '110639', 'POS KENDARI', '');
INSERT INTO kppbc VALUES('687', '110640', 'POS EREKE', '');
INSERT INTO kppbc VALUES('688', '110700', 'KPBC POMALAA', 'POMALAA');
INSERT INTO kppbc VALUES('689', '110731', 'POS KOLAKA', '');
INSERT INTO kppbc VALUES('690', '110734', 'POS POMALAA', '');
INSERT INTO kppbc VALUES('691', '110735', 'POS BOEPINANG', '');
INSERT INTO kppbc VALUES('692', '110800', 'KPBC PANTOLOAN', 'PANTOLOAN');
INSERT INTO kppbc VALUES('693', '110811', 'KANTOR BANTU TOLI-TOLI', 'TOLI-TOLI');
INSERT INTO kppbc VALUES('694', '110832', 'POS WANI', '');
INSERT INTO kppbc VALUES('695', '110833', 'POS SABANG', '');
INSERT INTO kppbc VALUES('696', '110834', 'POS PARIGI', '');
INSERT INTO kppbc VALUES('697', '110835', 'POS BANDARA MUTIARA', '');
INSERT INTO kppbc VALUES('698', '110836', 'POS LOLI', '');
INSERT INTO kppbc VALUES('699', '110837', 'POS OGOTUA', '');
INSERT INTO kppbc VALUES('700', '110838', 'POS LEOK', '');
INSERT INTO kppbc VALUES('701', '110839', 'POS PALELEH', '');
INSERT INTO kppbc VALUES('702', '110840', 'POS PANTOLOAN', '');
INSERT INTO kppbc VALUES('703', '110841', 'POS PASANG KAYU', '');
INSERT INTO kppbc VALUES('704', '110842', 'POS MOUTONG', '');
INSERT INTO kppbc VALUES('705', '110843', 'POS DONGGALA', '');
INSERT INTO kppbc VALUES('706', '110900', 'KPBC POSO', 'POSO');
INSERT INTO kppbc VALUES('707', '110931', 'POS AMPANA', '');
INSERT INTO kppbc VALUES('708', '110932', 'POS KOLONEDALE', '');
INSERT INTO kppbc VALUES('709', '110933', 'POS BANDARA KASIGUNCU', '');
INSERT INTO kppbc VALUES('710', '110934', 'POS MOAHINO/BOHUMBELU', '');
INSERT INTO kppbc VALUES('711', '110935', 'POS POSO', '');
INSERT INTO kppbc VALUES('712', '110936', 'POS WAKAI', '');
INSERT INTO kppbc VALUES('713', '111000', 'KPBC LUWUK', 'LUWUK');
INSERT INTO kppbc VALUES('714', '111031', 'POS PAGIMANA', '');
INSERT INTO kppbc VALUES('715', '111032', 'POS BANGGAI', '');
INSERT INTO kppbc VALUES('716', '111033', 'POS TOILI', '');
INSERT INTO kppbc VALUES('717', '111034', 'POS BUNTA', '');
INSERT INTO kppbc VALUES('718', '111035', 'POS BANDARA BUBUNG', '');
INSERT INTO kppbc VALUES('719', '111036', 'POS LUWUK', '');
INSERT INTO kppbc VALUES('720', '111100', 'KPBC BITUNG', 'BITUNG');
INSERT INTO kppbc VALUES('721', '111131', 'POS KEMA', '');
INSERT INTO kppbc VALUES('722', '111132', 'POS BELANG', '');
INSERT INTO kppbc VALUES('723', '111133', 'POS KOTABUNAN', '');
INSERT INTO kppbc VALUES('724', '111134', 'POS LIKUPANG', '');
INSERT INTO kppbc VALUES('725', '111137', 'POS BITUNG', '');
INSERT INTO kppbc VALUES('726', '111139', 'POS RATATOTOK', '');
INSERT INTO kppbc VALUES('727', '111200', 'KPBC MANADO', 'MANADO');
INSERT INTO kppbc VALUES('728', '111211', 'KANTOR BANTU LABUHAN UKI', '');
INSERT INTO kppbc VALUES('729', '111212', 'KANTOR BANTU TAHUNA', '');
INSERT INTO kppbc VALUES('730', '111213', 'KANTOR BANTU HULU SIAU', '');
INSERT INTO kppbc VALUES('731', '111214', 'KANTOR BANTU MARORE', '');
INSERT INTO kppbc VALUES('732', '111215', 'KANTOR BANTU MIANGAS', '');
INSERT INTO kppbc VALUES('733', '111216', 'KANTOR BANTU AMURANG', '');
INSERT INTO kppbc VALUES('734', '111217', 'KANTOR BANTU LIRUNG', '');
INSERT INTO kppbc VALUES('735', '111233', 'POS INOBONTO', '');
INSERT INTO kppbc VALUES('736', '111239', 'POS TAGULANDANG', '');
INSERT INTO kppbc VALUES('737', '111240', 'POS MANADO', '');
INSERT INTO kppbc VALUES('738', '111241', 'POS BANDARA SAM RATULANGI', '');
INSERT INTO kppbc VALUES('739', '111242', 'POS MALIBAGU', '');
INSERT INTO kppbc VALUES('740', '111300', 'KPBC GORONTALO', 'GORONTALO');
INSERT INTO kppbc VALUES('741', '111331', 'POS KUANDANG', '');
INSERT INTO kppbc VALUES('742', '111333', 'POS PAGUAT', '');
INSERT INTO kppbc VALUES('743', '111334', 'POS PAPAYATO', '');
INSERT INTO kppbc VALUES('744', '111335', 'POS BANDARA JALALUDIN', '');
INSERT INTO kppbc VALUES('745', '111336', 'POS GORONTALO', '');
INSERT INTO kppbc VALUES('746', '120000', 'KANTOR WILAYAH XII AMBON', 'AMBON');
INSERT INTO kppbc VALUES('747', '120100', 'KPBC AMBON', 'AMBON');
INSERT INTO kppbc VALUES('748', '120111', 'KANTOR BANTU WAISARISA', '');
INSERT INTO kppbc VALUES('749', '120114', 'KANTOR BANTU BANDARA PATTIMURA', '');
INSERT INTO kppbc VALUES('750', '120131', 'POS BANDA', '');
INSERT INTO kppbc VALUES('751', '120132', 'POS NAMLEA', '');
INSERT INTO kppbc VALUES('752', '120135', 'POS GESER', '');
INSERT INTO kppbc VALUES('753', '120137', 'POS WAINIBE / P.BURU', '');
INSERT INTO kppbc VALUES('754', '120138', 'POS MASOHI', '');
INSERT INTO kppbc VALUES('755', '120139', 'POS AMBON', '');
INSERT INTO kppbc VALUES('756', '120140', 'POS GALALA', '');
INSERT INTO kppbc VALUES('757', '120141', 'POS TULEHU', '');
INSERT INTO kppbc VALUES('758', '120143', 'POS HITU', '');
INSERT INTO kppbc VALUES('759', '120144', 'POS OPIN/PASAHARI', '');
INSERT INTO kppbc VALUES('760', '120200', 'KPBC TERNATE', 'TERNATE');
INSERT INTO kppbc VALUES('761', '120211', 'KANTOR BANTU P. GEBE', '');
INSERT INTO kppbc VALUES('762', '120212', 'KANTOR BANTU GALELA/TOBELO', '');
INSERT INTO kppbc VALUES('763', '120213', 'KANTOR BANTU P. MANOLE', '');
INSERT INTO kppbc VALUES('764', '120232', 'POS LABUHA', '');
INSERT INTO kppbc VALUES('765', '120234', 'POS BANDARA BABULLAH', '');
INSERT INTO kppbc VALUES('766', '120236', 'POS TERNATE', '');
INSERT INTO kppbc VALUES('767', '120237', 'POS BASTIONG', '');
INSERT INTO kppbc VALUES('768', '120238', 'POS SANANA', '');
INSERT INTO kppbc VALUES('769', '120239', 'POS TANJUNG BARNABAS', '');
INSERT INTO kppbc VALUES('770', '120300', 'KPBC SORONG', 'SORONG');
INSERT INTO kppbc VALUES('771', '120311', 'KANTOR BANTU TELUK KASIM', '');
INSERT INTO kppbc VALUES('772', '120331', 'POS BANDARA JEFMAN', '');
INSERT INTO kppbc VALUES('773', '120332', 'POS PULAU GAK', '');
INSERT INTO kppbc VALUES('774', '120335', 'POS DARMAGA KHUSUS USAHA MINA', 'MINA');
INSERT INTO kppbc VALUES('775', '120337', 'POS ARAR', '');
INSERT INTO kppbc VALUES('776', '120338', 'POS SORONG', '');
INSERT INTO kppbc VALUES('777', '120400', 'KPBC MANOKWARI', 'MANOKWARI');
INSERT INTO kppbc VALUES('778', '120412', 'KANTOR BANTU BABO', '');
INSERT INTO kppbc VALUES('779', '120431', 'POS BINTUNI', '');
INSERT INTO kppbc VALUES('780', '120432', 'POS BANDARA RENDANI', '');
INSERT INTO kppbc VALUES('781', '120433', 'POS MANOKWARI', '');
INSERT INTO kppbc VALUES('782', '120435', 'POS WIMRO', '');
INSERT INTO kppbc VALUES('783', '120500', 'KPBC FAK-FAK', 'FAK-FAK');
INSERT INTO kppbc VALUES('784', '120531', 'POS KAIMANA', '');
INSERT INTO kppbc VALUES('785', '120532', 'POS KOKAS', '');
INSERT INTO kppbc VALUES('786', '120533', 'POS PULAU ADI', '');
INSERT INTO kppbc VALUES('787', '120534', 'POS BANDARA FAK-FAK', '');
INSERT INTO kppbc VALUES('788', '120535', 'POS FAK-FAK', '');
INSERT INTO kppbc VALUES('789', '120600', 'KPBC JAYAPURA', 'JAYAPURA');
INSERT INTO kppbc VALUES('790', '120611', 'KANTOR BANTU BANDARA SENTANI', '');
INSERT INTO kppbc VALUES('791', '120612', 'KANTOR BANTU SKOU', '');
INSERT INTO kppbc VALUES('792', '120631', 'POS SARMI', '');
INSERT INTO kppbc VALUES('793', '120633', 'POS KIWIROK', '');
INSERT INTO kppbc VALUES('794', '120634', 'POS SENGAI', '');
INSERT INTO kppbc VALUES('795', '120635', 'POS WARIS', '');
INSERT INTO kppbc VALUES('796', '120636', 'POS WEMBI', '');
INSERT INTO kppbc VALUES('797', '120637', 'POS DEMTA', '');
INSERT INTO kppbc VALUES('798', '120638', 'POS WAMENA', '');
INSERT INTO kppbc VALUES('799', '120639', 'POS JAYAPURA', '');
INSERT INTO kppbc VALUES('800', '120700', 'KPBC MERAUKE', 'MERAUKE');
INSERT INTO kppbc VALUES('801', '120731', 'POS SORTA', '');
INSERT INTO kppbc VALUES('802', '120732', 'POS BUPUL', '');
INSERT INTO kppbc VALUES('803', '120734', 'POS MINDIPTANAA', '');
INSERT INTO kppbc VALUES('804', '120736', 'POS AGATS', '');
INSERT INTO kppbc VALUES('805', '120737', 'POS  BADE', '');
INSERT INTO kppbc VALUES('806', '120738', 'POS BANDARA MOPAH', '');
INSERT INTO kppbc VALUES('807', '120739', 'POS MERAUKE', '');
INSERT INTO kppbc VALUES('808', '120740', 'POS WANAM', '');
INSERT INTO kppbc VALUES('809', '120800', 'KPBC AMAMAPARE', 'AMAMAPARE');
INSERT INTO kppbc VALUES('810', '120812', 'KANTOR BANTU KULALA KENCANA/KOTA BARU', '');
INSERT INTO kppbc VALUES('811', '120813', 'KANTOR BANTU BANDARA TIMIKA', '');
INSERT INTO kppbc VALUES('812', '120831', 'POS AMAMAPARE', '');
INSERT INTO kppbc VALUES('813', '120832', 'POS CARGO DOCK', '');
INSERT INTO kppbc VALUES('814', '120833', 'POS PAD XI', '');
INSERT INTO kppbc VALUES('815', '120834', 'POS ETNA', '');
INSERT INTO kppbc VALUES('816', '120835', 'POS TEMBAGAPURA', '');
INSERT INTO kppbc VALUES('817', '120836', 'POS POMAKO I', '');
INSERT INTO kppbc VALUES('818', '120900', 'KPBC BIAK', 'BIAK');
INSERT INTO kppbc VALUES('819', '120911', 'KANTOR BANTU NABIRE/TELUK KIMI', '');
INSERT INTO kppbc VALUES('820', '120931', 'POS SERUI', '');
INSERT INTO kppbc VALUES('821', '120933', 'POS BIAK', '');
INSERT INTO kppbc VALUES('822', '120934', 'POS DAWAI', '');
INSERT INTO kppbc VALUES('823', '121000', 'KPBC TUAL', '');
INSERT INTO kppbc VALUES('824', '121031', 'POS DABO', '');
INSERT INTO kppbc VALUES('825', '121032', 'POS BENJINA/P. KEI', '');
INSERT INTO kppbc VALUES('826', '121033', 'POS SAUMLAKI', '');
INSERT INTO kppbc VALUES('827', '121034', 'POS NGADI', '');
INSERT INTO kppbc VALUES('828', '121035', 'POS ELAT', '');
INSERT INTO kppbc VALUES('829', '121036', 'POS LARAT', '');
INSERT INTO kppbc VALUES('830', '121037', 'POS WONRELI/KISAR', '');
INSERT INTO kppbc VALUES('831', '121038', 'POS BANDARA D. DUMATUBUN LANGGUR', '');
INSERT INTO kppbc VALUES('832', '121039', 'POS SERWARU', '');
INSERT INTO kppbc VALUES('833', '121040', 'POS HWAKI/WETAR', '');
INSERT INTO kppbc VALUES('834', '130000', 'KANTOR WILAYAH XIII BANDA ACEH', '');
INSERT INTO kppbc VALUES('835', '130100', 'KPBC ULEELHEUE', '');
INSERT INTO kppbc VALUES('836', '130111', 'KANTOR BANTU LHOK NGA', '');
INSERT INTO kppbc VALUES('837', '130131', 'POS LAM PULO', '');
INSERT INTO kppbc VALUES('838', '130132', 'POS SIGLI', '');
INSERT INTO kppbc VALUES('839', '130133', 'POS COT BAU', '');
INSERT INTO kppbc VALUES('840', '130134', 'POS MALAHAYATI', '');
INSERT INTO kppbc VALUES('841', '130200', 'KPBC ISKANDAR MUDA', '');
INSERT INTO kppbc VALUES('842', '130231', 'POS BANDARA ISKANDAR MUDA', '');
INSERT INTO kppbc VALUES('843', '130300', 'KPBC SABANG', '');
INSERT INTO kppbc VALUES('844', '130400', 'KPBC MEULABOH', '');
INSERT INTO kppbc VALUES('845', '130411', 'KANTOR BANTU SINABANG', '');
INSERT INTO kppbc VALUES('846', '130412', 'KANTOR BANTU TAPAK TUAN', '');
INSERT INTO kppbc VALUES('847', '130413', 'KANTOR BANTU SINGKEL', '');
INSERT INTO kppbc VALUES('848', '130431', 'POS SUSOH', '');
INSERT INTO kppbc VALUES('849', '130500', 'KPBC LHOK SEUMAWE', '');
INSERT INTO kppbc VALUES('850', '130511', 'KANTOR BANTU LHOK SUKON', '');
INSERT INTO kppbc VALUES('851', '130531', 'POS BLANG LANCANG', '');
INSERT INTO kppbc VALUES('852', '130532', 'POS KRUENG GEUKUH', '');
INSERT INTO kppbc VALUES('853', '130600', 'KPBC KUALA LANGSA', '');
INSERT INTO kppbc VALUES('854', '130631', 'POS KUALA LANGSA', '');
INSERT INTO kppbc VALUES('855', '130632', 'POS SARANG JAYA', '');
INSERT INTO kppbc VALUES('856', '150300', 'KPPBC TANGERANG', 'TANGERANG');
INSERT INTO kppbc VALUES('857', '160200', 'KPPBC SUNDA KELAPA', 'JAKARTA');



DROP TABLE IF EXISTS matauang;

CREATE TABLE `matauang` (
  `kd_valas` char(6) collate latin1_general_ci NOT NULL,
  `jenis_valas` varchar(100) collate latin1_general_ci NOT NULL,
  `nama_valas` varchar(100) collate latin1_general_ci NOT NULL,
  `negara_valas` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO matauang VALUES('CUR001', 'AFN', 'Afghani', 'Afghanistan');
INSERT INTO matauang VALUES('CUR002', 'EUR', 'Euro', 'Aland Islands');
INSERT INTO matauang VALUES('CUR003', 'ALL', 'Lek', 'Albania');
INSERT INTO matauang VALUES('CUR004', 'DZD', 'Algerian Dinar', 'Algeria');
INSERT INTO matauang VALUES('CUR005', 'USD', 'US Dollar', 'American Samoa');
INSERT INTO matauang VALUES('CUR006', 'EUR', 'Euro', 'Andorra');
INSERT INTO matauang VALUES('CUR007', 'AOA', 'Kwanza', 'Angola');
INSERT INTO matauang VALUES('CUR008', 'XCD', 'East Caribbean Dollar', 'Anguilla');
INSERT INTO matauang VALUES('CUR009', 'XCD', 'East Caribbean Dollar', 'Antigua and Barbuda');
INSERT INTO matauang VALUES('CUR010', 'ARS', 'Argentine Peso', 'Argentina');
INSERT INTO matauang VALUES('CUR011', 'AMD', 'Armenian Dram', 'Armenia');
INSERT INTO matauang VALUES('CUR012', 'AWG', 'Aruban Florin', 'Aruba');
INSERT INTO matauang VALUES('CUR013', 'AUD', 'Australian Dollar', 'Australia');
INSERT INTO matauang VALUES('CUR014', 'EUR', 'Euro', 'Austria');
INSERT INTO matauang VALUES('CUR015', 'AZN', 'Azerbaijanian Manat', 'Azerbaijan');
INSERT INTO matauang VALUES('CUR016', 'BSD', 'Bahamian Dollar', 'Bahamas');
INSERT INTO matauang VALUES('CUR017', 'BHD', 'Bahraini Dinar', 'Bahrain');
INSERT INTO matauang VALUES('CUR018', 'BDT', 'Taka', 'Bangladesh');
INSERT INTO matauang VALUES('CUR019', 'BBD', 'Barbados Dollar', 'Barbados');
INSERT INTO matauang VALUES('CUR020', 'BYR', 'Belarussian Ruble', 'Belarus');
INSERT INTO matauang VALUES('CUR021', 'EUR', 'Euro', 'Belgium');
INSERT INTO matauang VALUES('CUR022', 'BZD', 'Belize Dollar', 'Belize');
INSERT INTO matauang VALUES('CUR023', 'XOF', 'CFA Franc BCEAO ', 'Benin');
INSERT INTO matauang VALUES('CUR024', 'BMD', 'Bermudian Dollar', 'Bermuda');
INSERT INTO matauang VALUES('CUR025', 'BTN', 'Ngultrum', 'Bhutan');
INSERT INTO matauang VALUES('CUR026', 'BOB', 'Boliviano', 'Bolivia, Plurinational State of');
INSERT INTO matauang VALUES('CUR027', 'USD', 'US Dollar', 'Bonaire, Sint Eustatius and Saba');
INSERT INTO matauang VALUES('CUR028', 'BAM', 'Convertible Marks', 'Bosnia and Herzegovina');
INSERT INTO matauang VALUES('CUR029', 'BWP', 'Pula', 'Botswana');
INSERT INTO matauang VALUES('CUR030', 'NOK', 'Norwegian Krone', 'Bouvet Island');
INSERT INTO matauang VALUES('CUR031', 'BRL', 'Brazilian Real', 'Brazil');
INSERT INTO matauang VALUES('CUR032', 'USD', 'US Dollar', 'British Indian Ocean Territory');
INSERT INTO matauang VALUES('CUR033', 'BND', 'Brunei Dollar', 'Brunei Darussalam');
INSERT INTO matauang VALUES('CUR034', 'BGN', 'Bulgarian Lev', 'Bulgaria');
INSERT INTO matauang VALUES('CUR035', 'XOF', 'CFA Franc BCEAO ?', 'Burkina Faso');
INSERT INTO matauang VALUES('CUR036', 'BIF', 'Burundi Franc', 'Burundi');
INSERT INTO matauang VALUES('CUR037', 'KHR', 'Riel', 'Cambodia');
INSERT INTO matauang VALUES('CUR038', 'XAF', 'CFA Franc BEAC ', 'Cameroon');
INSERT INTO matauang VALUES('CUR039', 'CAD', 'Canadian Dollar', 'Canada');
INSERT INTO matauang VALUES('CUR040', 'CVE', 'Cape Verde Escudo', 'Cape Verde');
INSERT INTO matauang VALUES('CUR041', 'KYD', 'Cayman Islands Dollar', 'Cayman Islands');
INSERT INTO matauang VALUES('CUR042', 'XAF', 'CFA Franc BEAC ', 'Central African Republic');
INSERT INTO matauang VALUES('CUR043', 'XAF', 'CFA Franc BEAC ', 'Chad');
INSERT INTO matauang VALUES('CUR044', 'CLP', 'Chilean Peso', 'Chile');
INSERT INTO matauang VALUES('CUR045', 'CNY', 'Yuan Renminbi', 'China');
INSERT INTO matauang VALUES('CUR046', 'AUD', 'Australian Dollar', 'Christmas Island');
INSERT INTO matauang VALUES('CUR047', 'COP', 'Colombian Peso', 'Colombia');
INSERT INTO matauang VALUES('CUR048', 'KMF', 'Comoro Franc', 'Comoros');
INSERT INTO matauang VALUES('CUR049', 'XAF', 'CFA Franc BEAC ', 'Congo');
INSERT INTO matauang VALUES('CUR050', 'CDF', 'Franc Congolais', 'Congo, The Democratic Republic of the');
INSERT INTO matauang VALUES('CUR051', 'NZD', 'New Zealand Dollar', 'Cook Islands');
INSERT INTO matauang VALUES('CUR052', 'CRC', 'Costa Rican Colon', 'Costa Rica');
INSERT INTO matauang VALUES('CUR053', 'XOF', 'CFA Franc BCEAO ?', 'C?te D?Ivoire');
INSERT INTO matauang VALUES('CUR054', 'HRK', 'Croatian Kuna', 'Croatia');
INSERT INTO matauang VALUES('CUR055', 'CUP', 'Cuban Peso', 'Cuba');
INSERT INTO matauang VALUES('CUR056', 'ANG', 'Netherlands Antillean Guilder', 'Cura?o');
INSERT INTO matauang VALUES('CUR057', 'CYP', 'Cyprus Pound', 'Cyprus');
INSERT INTO matauang VALUES('CUR058', 'CZK', 'Czech Koruna', 'Czech Republic');
INSERT INTO matauang VALUES('CUR059', 'DKK', 'Danish Krone', 'Denmark');
INSERT INTO matauang VALUES('CUR060', 'DJF', 'Djibouti Franc', 'Djibouti');
INSERT INTO matauang VALUES('CUR061', 'XCD', 'East Caribbean Dollar', 'Dominica');
INSERT INTO matauang VALUES('CUR062', 'DOP', 'Dominican Peso', 'Dominican Republic');
INSERT INTO matauang VALUES('CUR063', 'USD', 'US Dollar', 'Ecuador');
INSERT INTO matauang VALUES('CUR064', 'EGP', 'Egyptian Pound', 'Egypt');
INSERT INTO matauang VALUES('CUR065', 'SVC', 'El Salvador Colon', 'El Salvador');
INSERT INTO matauang VALUES('CUR066', 'XAF', 'CFA Franc BEAC ', 'Equatorial Guinea');
INSERT INTO matauang VALUES('CUR067', 'ERN', 'Nakfa', 'Eritrea');
INSERT INTO matauang VALUES('CUR068', 'EUR', 'Euro', 'Estonia');
INSERT INTO matauang VALUES('CUR069', 'ETB', 'Ethiopian Birr', 'Ethiopia');
INSERT INTO matauang VALUES('CUR070', 'EUR', 'Euro', 'European Economic and Monetary Union area');
INSERT INTO matauang VALUES('CUR071', 'FKP', 'Falkland Islands Pound', 'Falkland Islands (Malvinas)');
INSERT INTO matauang VALUES('CUR072', 'DKK', 'Danish Krone', 'Faroe Islands');
INSERT INTO matauang VALUES('CUR073', 'FJD', 'Fiji Dollar', 'Fiji');
INSERT INTO matauang VALUES('CUR074', 'EUR', 'Euro', 'Finland');
INSERT INTO matauang VALUES('CUR075', 'EUR', 'Euro', 'France');
INSERT INTO matauang VALUES('CUR076', 'EUR', 'Euro', 'French Guiana');
INSERT INTO matauang VALUES('CUR077', 'XPF', 'CFP Franc', 'French Polynesia');
INSERT INTO matauang VALUES('CUR078', 'EUR', 'Euro', 'French Southern Territories');
INSERT INTO matauang VALUES('CUR079', 'XAF', 'CFA Franc BEAC ', 'Gabon');
INSERT INTO matauang VALUES('CUR080', 'GMD', 'Dalasi', 'Gambia');
INSERT INTO matauang VALUES('CUR081', 'GEL', 'Lari', 'Georgia');
INSERT INTO matauang VALUES('CUR082', 'EUR', 'Euro', 'Germany');
INSERT INTO matauang VALUES('CUR083', 'GHS', 'Ghana Cedi', 'Ghana');
INSERT INTO matauang VALUES('CUR084', 'GIP', 'Gibraltar Pound', 'Gibraltar');
INSERT INTO matauang VALUES('CUR085', 'EUR', 'Euro', 'Greece');
INSERT INTO matauang VALUES('CUR086', 'DKK', 'Danish Krone', 'Greenland');
INSERT INTO matauang VALUES('CUR087', 'XCD', 'East Caribbean Dollar', 'Grenada');
INSERT INTO matauang VALUES('CUR088', 'EUR', 'Euro', 'Guadeloupe');
INSERT INTO matauang VALUES('CUR089', 'USD', 'US Dollar', 'Guam');
INSERT INTO matauang VALUES('CUR090', 'GTQ', 'Quetzal', 'Guatemala');
INSERT INTO matauang VALUES('CUR091', 'GBP', 'Pound Sterling', 'Guernsey');
INSERT INTO matauang VALUES('CUR092', 'GNF', 'Guinea Franc', 'Guinea');
INSERT INTO matauang VALUES('CUR093', 'GWP', 'Guinea-Bissau Peso', 'Guinea-Bissau');
INSERT INTO matauang VALUES('CUR094', 'GYD', 'Guyana Dollar', 'Guyana');
INSERT INTO matauang VALUES('CUR095', 'HTG', 'Gourde', 'Haiti');
INSERT INTO matauang VALUES('CUR096', 'AUD', 'Australian Dollar', 'Heard Island and McDonald Islands');
INSERT INTO matauang VALUES('CUR097', 'EUR', 'Euro', 'Holy See (Vatican City State)');
INSERT INTO matauang VALUES('CUR098', 'HNL', 'Lempira', 'Honduras');
INSERT INTO matauang VALUES('CUR099', 'HKD', 'Hong Kong Dollar', 'Hong Kong');
INSERT INTO matauang VALUES('CUR100', 'HUF', 'Forint', 'Hungary');
INSERT INTO matauang VALUES('CUR101', 'ISK', 'Iceland Krona', 'Iceland');
INSERT INTO matauang VALUES('CUR102', 'INR', 'Indian Rupee', 'India');
INSERT INTO matauang VALUES('CUR103', 'IDR', 'Rupiah', 'Indonesia');
INSERT INTO matauang VALUES('CUR104', 'IRR', 'Iranian Rial', 'Iran, Islamic Republic Of');
INSERT INTO matauang VALUES('CUR105', 'IQD', 'Iraqi Dinar', 'Iraq');
INSERT INTO matauang VALUES('CUR106', 'EUR', 'Euro', 'Ireland');
INSERT INTO matauang VALUES('CUR107', 'GBP', 'Pound Sterling', 'Isle of Man');
INSERT INTO matauang VALUES('CUR108', 'ILS', 'New Israeli Sheqel', 'Israel');
INSERT INTO matauang VALUES('CUR109', 'EUR', 'Euro', 'Italy');
INSERT INTO matauang VALUES('CUR110', 'JMD', 'Jamaican Dollar', 'Jamaica');
INSERT INTO matauang VALUES('CUR111', 'JPY', 'Yen', 'Japan');
INSERT INTO matauang VALUES('CUR112', 'GBP', 'Pound Sterling', 'Jersey');
INSERT INTO matauang VALUES('CUR113', 'JOD', 'Jordanian Dinar', 'Jordan');
INSERT INTO matauang VALUES('CUR114', 'KZT', 'Tenge', 'Kazakhstan');
INSERT INTO matauang VALUES('CUR115', 'KES', 'Kenyan Shilling', 'Kenya');
INSERT INTO matauang VALUES('CUR116', 'AUD', 'Australian Dollar', 'Kiribati');
INSERT INTO matauang VALUES('CUR117', 'KPW', 'North Korean Won', 'Korea, Democratic People?s Republic of');
INSERT INTO matauang VALUES('CUR118', 'KRW', 'Won', 'Korea, Republic of');
INSERT INTO matauang VALUES('CUR119', 'KWD', 'Kuwaiti Dinar', 'Kuwait');
INSERT INTO matauang VALUES('CUR120', 'KGS', 'Som', 'Kyrgyzstan');
INSERT INTO matauang VALUES('CUR121', 'LAK', 'Kip', 'Lao People?s Democratic Republic');
INSERT INTO matauang VALUES('CUR122', 'LVL', 'Latvian Lats', 'Latvia');
INSERT INTO matauang VALUES('CUR123', 'LBP', 'Lebanese Pound', 'Lebanon');
INSERT INTO matauang VALUES('CUR124', 'LSL', 'Loti', 'Lesotho');
INSERT INTO matauang VALUES('CUR125', 'LRD', 'Liberian Dollar', 'Liberia');
INSERT INTO matauang VALUES('CUR126', 'LYD', 'Libyan Dinar', 'Libya');
INSERT INTO matauang VALUES('CUR127', 'CHF', 'Swiss Franc', 'Liechtenstein');
INSERT INTO matauang VALUES('CUR128', 'LTL', 'Lithuanian Litas', 'Lithuania');
INSERT INTO matauang VALUES('CUR129', 'EUR', 'Euro', 'Luxembourg');
INSERT INTO matauang VALUES('CUR130', 'MOP', 'Pataca', 'Macao');
INSERT INTO matauang VALUES('CUR131', 'MKD', 'Denar', 'Macedonia, The Former Yugoslav Republic of');
INSERT INTO matauang VALUES('CUR132', 'MGA', 'Malagasy Ariary', 'Madagascar');
INSERT INTO matauang VALUES('CUR133', 'MWK', 'Kwacha', 'Malawi');
INSERT INTO matauang VALUES('CUR134', 'MYR', 'Malaysian Ringgit', 'Malaysia');
INSERT INTO matauang VALUES('CUR135', 'MVR', 'Rufiyaa', 'Maldives');
INSERT INTO matauang VALUES('CUR136', 'XOF', 'CFA Franc BCEAO ?', 'Mali');
INSERT INTO matauang VALUES('CUR137', 'EUR', 'Euro', 'Malta');
INSERT INTO matauang VALUES('CUR138', 'USD', 'US Dollar', 'Marshall Islands');
INSERT INTO matauang VALUES('CUR139', 'EUR', 'Euro', 'Martinique');
INSERT INTO matauang VALUES('CUR140', 'MRO', 'Ouguiya', 'Mauritania');
INSERT INTO matauang VALUES('CUR141', 'MUR', 'Mauritius Rupee', 'Mauritius');
INSERT INTO matauang VALUES('CUR142', 'EUR', 'Euro', 'Mayotte');
INSERT INTO matauang VALUES('CUR143', 'MXN', 'Mexican Peso', 'Mexico');
INSERT INTO matauang VALUES('CUR144', 'USD', 'US Dollar', 'Micronesia, Federated States of');
INSERT INTO matauang VALUES('CUR145', 'MDL', 'Moldovan Leu', 'Moldova, Republic of');
INSERT INTO matauang VALUES('CUR146', 'EUR', 'Euro', 'Monaco');
INSERT INTO matauang VALUES('CUR147', 'MNT', 'Tugrik', 'Mongolia');
INSERT INTO matauang VALUES('CUR148', 'EUR', 'Euro', 'Montenegro');
INSERT INTO matauang VALUES('CUR149', 'XCD', 'East Caribbean Dollar', 'Montserrat');
INSERT INTO matauang VALUES('CUR150', 'MAD', 'Moroccan Dirham', 'Morocco');
INSERT INTO matauang VALUES('CUR151', 'MZN', 'Mozambique Metical', 'Mozambique');
INSERT INTO matauang VALUES('CUR152', 'MMK', 'Kyat', 'Myanmar');
INSERT INTO matauang VALUES('CUR153', 'NAD', 'Namibia Dollar', 'Namibia');
INSERT INTO matauang VALUES('CUR154', 'AUD', 'Australian Dollar', 'Nauru');
INSERT INTO matauang VALUES('CUR155', 'NPR', 'Nepalese Rupee', 'Nepal');
INSERT INTO matauang VALUES('CUR156', 'EUR', 'Euro', 'Netherlands');
INSERT INTO matauang VALUES('CUR157', 'ANG', 'Netherlands Antillean Guilder', 'Netherlands Antilles');
INSERT INTO matauang VALUES('CUR158', 'XPF', 'CFP Franc', 'New Caledonia');
INSERT INTO matauang VALUES('CUR159', 'NZD', 'New Zealand Dollar', 'New Zealand');
INSERT INTO matauang VALUES('CUR160', 'NIO', 'Cordoba Oro', 'Nicaragua');
INSERT INTO matauang VALUES('CUR161', 'XOF', 'CFA Franc BCEAO ?', 'Niger');
INSERT INTO matauang VALUES('CUR162', 'NGN', 'Naira', 'Nigeria');
INSERT INTO matauang VALUES('CUR163', 'NZD', 'New Zealand Dollar', 'Niue');
INSERT INTO matauang VALUES('CUR164', 'AUD', 'Australian Dollar', 'Norfolk Island');
INSERT INTO matauang VALUES('CUR165', 'USD', 'US Dollar', 'Northern Mariana Islands');
INSERT INTO matauang VALUES('CUR166', 'NOK', 'Norwegian Krone', 'Norway');
INSERT INTO matauang VALUES('CUR167', 'OMR', 'Rial Omani', 'Oman');
INSERT INTO matauang VALUES('CUR168', 'PKR', 'Pakistan Rupee', 'Pakistan');
INSERT INTO matauang VALUES('CUR169', 'USD', 'US Dollar', 'Palau');
INSERT INTO matauang VALUES('CUR170', '', 'No universal currency', 'Palestinian Territory, Occupied');
INSERT INTO matauang VALUES('CUR171', 'PAB', 'Balboa', 'Panama');
INSERT INTO matauang VALUES('CUR172', 'PGK', 'Kina', 'Papua New Guinea');
INSERT INTO matauang VALUES('CUR173', 'PYG', 'Guarani', 'Paraguay');
INSERT INTO matauang VALUES('CUR174', 'PEN', 'Nuevo Sol', 'Peru');
INSERT INTO matauang VALUES('CUR175', 'PHP', 'Philippine Peso', 'Philippines');
INSERT INTO matauang VALUES('CUR176', 'NZD', 'New Zealand Dollar', 'Pitcairn');
INSERT INTO matauang VALUES('CUR177', 'PLN', 'Zloty', 'Poland');
INSERT INTO matauang VALUES('CUR178', 'EUR', 'Euro', 'Portugal');
INSERT INTO matauang VALUES('CUR179', 'USD', 'US Dollar', 'Puerto Rico');
INSERT INTO matauang VALUES('CUR180', 'QAR', 'Qatari Rial', 'Qatar');
INSERT INTO matauang VALUES('CUR181', 'EUR', 'Euro', 'R?union');
INSERT INTO matauang VALUES('CUR182', 'RON', 'New Romanian Leu', 'Romania');
INSERT INTO matauang VALUES('CUR183', 'RUB', 'Russian Ruble', 'Russian Federation');
INSERT INTO matauang VALUES('CUR184', 'RWF', 'Rwanda Franc', 'Rwanda');
INSERT INTO matauang VALUES('CUR185', 'EUR', 'Euro', 'Saint Barth?lemy');
INSERT INTO matauang VALUES('CUR186', 'SHP', 'Saint Helena Pound', 'Saint Helena, Ascension and Tristan Da Cunha');
INSERT INTO matauang VALUES('CUR187', 'XCD', 'East Caribbean Dollar', 'Saint Kitts and Nevis');
INSERT INTO matauang VALUES('CUR188', 'XCD', 'East Caribbean Dollar', 'Saint Lucia');
INSERT INTO matauang VALUES('CUR189', 'EUR', 'Euro', 'Saint Martin (French part)');
INSERT INTO matauang VALUES('CUR190', 'EUR', 'Euro', 'Saint Pierre and Miquelon');
INSERT INTO matauang VALUES('CUR191', 'XCD', 'East Caribbean Dollar', 'Saint Vincent and The Grenadines');
INSERT INTO matauang VALUES('CUR192', 'WST', 'Tala', 'Samoa');
INSERT INTO matauang VALUES('CUR193', 'EUR', 'Euro', 'San Marino');
INSERT INTO matauang VALUES('CUR194', 'STD', 'Dobra', 'Sao Tome and Principe');
INSERT INTO matauang VALUES('CUR195', 'SAR', 'Saudi Riyal', 'Saudi Arabia');
INSERT INTO matauang VALUES('CUR196', 'XOF', 'CFA Franc BCEAO ?', 'Senegal');
INSERT INTO matauang VALUES('CUR197', 'RSD', 'Serbian Dinar', 'Serbia');
INSERT INTO matauang VALUES('CUR198', 'SCR', 'Seychelles Rupee', 'Seychelles');
INSERT INTO matauang VALUES('CUR199', 'SLL', 'Leone', 'Sierra Leone');
INSERT INTO matauang VALUES('CUR200', 'SGD', 'Singapore Dollar', 'Singapore');
INSERT INTO matauang VALUES('CUR201', 'ANG', 'Netherlands Antillean Guilder', 'Sint Maarten (Dutch part)');
INSERT INTO matauang VALUES('CUR202', 'EUR', 'Euro', 'Slovakia');
INSERT INTO matauang VALUES('CUR203', 'EUR', 'Euro', 'Slovenia');
INSERT INTO matauang VALUES('CUR204', 'SBD', 'Solomon Islands Dollar', 'Solomon Islands');
INSERT INTO matauang VALUES('CUR205', 'SOS', 'Somali Shilling', 'Somalia');
INSERT INTO matauang VALUES('CUR206', 'ZAR', 'Rand', 'South Africa');
INSERT INTO matauang VALUES('CUR208', 'SSP', 'South Sudanese Pound', 'South Sudan');
INSERT INTO matauang VALUES('CUR209', 'EUR', 'Euro', 'Spain');
INSERT INTO matauang VALUES('CUR210', 'LKR', 'Sri Lanka Rupee', 'Sri Lanka');
INSERT INTO matauang VALUES('CUR211', 'SDG', 'Sudanese Pound', 'Sudan');
INSERT INTO matauang VALUES('CUR212', 'SRD', 'Surinam Dollar', 'Suriname');
INSERT INTO matauang VALUES('CUR213', 'NOK', 'Norwegian Krone', 'Svalbard and Jan Mayen');
INSERT INTO matauang VALUES('CUR214', 'SZL', 'Lilangeni', 'Swaziland');
INSERT INTO matauang VALUES('CUR215', 'SEK', 'Swedish Krona', 'Sweden');
INSERT INTO matauang VALUES('CUR216', 'CHF', 'Swiss Franc', 'Switzerland');
INSERT INTO matauang VALUES('CUR217', 'SYP', 'Syrian Pound', 'Syrian Arab Republic');
INSERT INTO matauang VALUES('CUR218', 'TWD', 'New Taiwan Dollar', 'Taiwan, Province of China');
INSERT INTO matauang VALUES('CUR219', 'TJS', 'Somoni', 'Tajikistan');
INSERT INTO matauang VALUES('CUR220', 'TZS', 'Tanzanian Shilling', 'Tanzania, United Republic of');
INSERT INTO matauang VALUES('CUR221', 'THB', 'Baht', 'Thailand');
INSERT INTO matauang VALUES('CUR222', 'USD', 'US Dollar', 'Timor-Leste');
INSERT INTO matauang VALUES('CUR223', 'XOF', 'CFA Franc BCEAO ?', 'Togo');
INSERT INTO matauang VALUES('CUR224', 'NZD', 'New Zealand Dollar', 'Tokelau');
INSERT INTO matauang VALUES('CUR225', 'TOP', 'Pa?anga', 'Tonga');
INSERT INTO matauang VALUES('CUR226', 'TTD', 'Trinidad and Tobago Dollar', 'Trinidad and Tobago');
INSERT INTO matauang VALUES('CUR227', 'TND', 'Tunisian Dinar', 'Tunisia');
INSERT INTO matauang VALUES('CUR228', 'TRY', 'New Turkish Lira', 'Turkey');
INSERT INTO matauang VALUES('CUR229', 'TMM', 'Turkmenistan New Manat', 'Turkmenistan');
INSERT INTO matauang VALUES('CUR230', 'USD', 'US Dollar', 'Turks and Caicos Islands');
INSERT INTO matauang VALUES('CUR231', 'AUD', 'Australian Dollar', 'Tuvalu');
INSERT INTO matauang VALUES('CUR232', 'UGX', 'Uganda Shilling', 'Uganda');
INSERT INTO matauang VALUES('CUR233', 'UAH', 'Hryvnia', 'Ukraine');
INSERT INTO matauang VALUES('CUR234', 'AED', 'UAE Dirham', 'United Arab Emirates');
INSERT INTO matauang VALUES('CUR235', 'GBP', 'Pound Sterling', 'United Kingdom');
INSERT INTO matauang VALUES('CUR236', 'USD', 'US Dollar', 'United States');
INSERT INTO matauang VALUES('CUR237', 'UYU', 'Peso Uruguayo', 'Uruguay');
INSERT INTO matauang VALUES('CUR238', 'UZS', 'Uzbekistan Sum', 'Uzbekistan');
INSERT INTO matauang VALUES('CUR239', 'VUV', 'Vatu', 'Vanuatu');
INSERT INTO matauang VALUES('CUR240', 'VEF', 'Bolivar', 'Venezuela, Bolivarian Republic of');
INSERT INTO matauang VALUES('CUR241', 'VND', 'Dong', 'Viet Nam');
INSERT INTO matauang VALUES('CUR242', 'USD', 'US Dollar', 'Virgin Islands, British');
INSERT INTO matauang VALUES('CUR243', 'USD', 'US Dollar', 'Virgin Islands, U.S.');
INSERT INTO matauang VALUES('CUR244', 'XPF', 'CFP Franc', 'Wallis And Futuna');
INSERT INTO matauang VALUES('CUR245', 'MAD', 'Moroccan Dirham', 'Western Sahara');
INSERT INTO matauang VALUES('CUR246', 'YER', 'Yemeni Rial', 'Yemen');
INSERT INTO matauang VALUES('CUR247', 'ZMK', 'Kwacha', 'Zambia');
INSERT INTO matauang VALUES('CUR248', 'ZWD', 'Zimbabwe Dollar', 'Zimbabwe');



DROP TABLE IF EXISTS outgoing_incoming;

CREATE TABLE `outgoing_incoming` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(100) collate latin1_general_ci NOT NULL,
  `name_ppc` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_incoming VALUES('0000000001', 'SPB-2013000001/OUTGOING', '2013-03-17', 'Bagian Alat Produksi', 'ewr', 'wer', 'admin');



DROP TABLE IF EXISTS outgoing_incoming_detail;

CREATE TABLE `outgoing_incoming_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_incoming_detail VALUES('0000000001', '3', 'SPB-2013000001/OUTGOING', '2013-03-17', 'B00001', '1.00', 'wre');



DROP TABLE IF EXISTS outgoing_produksi;

CREATE TABLE `outgoing_produksi` (
  `nomor` varchar(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(100) collate latin1_general_ci NOT NULL,
  `name_ppc` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_produksi VALUES('0000000001', 'SPB-2013000001/OUTGOING', '2013-03-17', 'Bagian Alat Produksi', '34', '34', 'admin');



DROP TABLE IF EXISTS outgoing_produksi_detail;

CREATE TABLE `outgoing_produksi_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_produksi_detail VALUES('0000000001', '1', 'SPB-2013000001/OUTGOING', '2013-03-17', 'B00003', '1.00', '345');



DROP TABLE IF EXISTS outgoing_terima;

CREATE TABLE `outgoing_terima` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `user_trt` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_terima VALUES('0000000001', '123', '2013-03-04', 'PRODUKSI', '123', '2013-03-04', '45', '45', '57', 'goestoe', 'goestoe');
INSERT INTO outgoing_terima VALUES('0000000002', 'LPB-2013000001/OUTGOING', '2013-03-17', 'PRODUKSI', 'SPB-2013000001/PRODUKSI', '2013-03-17', 'Bagian Alat Produksi', 'ewr', 'wer', 'admin', 'admin');
INSERT INTO outgoing_terima VALUES('0000000003', 'LPB-2013000002/OUTGOING', '2013-03-17', 'PRODUKSI', '234', '2013-03-04', '234', '234', '234', 'goestoe', 'admin');



DROP TABLE IF EXISTS outgoing_terima_detail;

CREATE TABLE `outgoing_terima_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO outgoing_terima_detail VALUES('0000000001', '1', 'PRODUKSI', '123', '2013-03-04', 'B00001', '1.00', '555');
INSERT INTO outgoing_terima_detail VALUES('0000000002', '2', 'PRODUKSI', 'LPB-2013000001/OUTGOING', '2013-03-17', 'B00002', '1.00', 'wer');
INSERT INTO outgoing_terima_detail VALUES('0000000003', '3', 'PRODUKSI', 'LPB-2013000002/OUTGOING', '2013-03-17', 'B00001', '1.00', '234');
INSERT INTO outgoing_terima_detail VALUES('0000000003', '4', 'PRODUKSI', 'LPB-2013000002/OUTGOING', '2013-03-17', 'B00001', '1.00', '234');



DROP TABLE IF EXISTS pemasok;

CREATE TABLE `pemasok` (
  `kode_pemasok` char(8) collate latin1_general_ci NOT NULL,
  `npwp` varchar(20) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL,
  `alamat` varchar(200) collate latin1_general_ci NOT NULL,
  `kota` varchar(100) collate latin1_general_ci NOT NULL,
  `negara` varchar(100) collate latin1_general_ci NOT NULL,
  `notelp` varchar(100) collate latin1_general_ci NOT NULL,
  `nofax` varchar(100) collate latin1_general_ci NOT NULL,
  `email` varchar(100) collate latin1_general_ci NOT NULL,
  `status` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pemasok VALUES('S00001', '01021221545555', 'PT LG Electronics Indonesia', 'Kawasan Industri MM 2100, Jl Sumatera Blok D Nomor 5', 'Bekasi', 'Indonesia', '021-22222', '021-4545454', '45EWR', 'Kawasan Berikat');
INSERT INTO pemasok VALUES('S00002', '010002221212000', 'PT Kolang Kaling', 'JL. Raya Setu', 'WER', 'Indonesia', 'WER', 'WER', 'WER', 'TLDDP/Lokal');



DROP TABLE IF EXISTS pemasukan;

CREATE TABLE `pemasukan` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_bpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_bpb` date NOT NULL,
  `pemasok` varchar(100) collate latin1_general_ci NOT NULL,
  `no_invoice` char(100) collate latin1_general_ci NOT NULL,
  `tgl_invoice` date NOT NULL,
  `no_do` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `jenis_dokpab` char(100) collate latin1_general_ci NOT NULL,
  `no_dokpab` int(6) NOT NULL,
  `tgl_dokpab` date NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`no_bpb`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pemasukan VALUES('0000000001', 'BPB-2013000001/EPSON', '2013-03-17', 'S00001', 'werwer', '2013-03-17', 'ewr', 'Ditimbun', 'BC 2.3', '222222', '2013-03-17', 'admin');
INSERT INTO pemasukan VALUES('0000000002', 'BPB-2013000002/EPSON', '2013-03-17', 'S00001', 'ewr', '2013-03-17', 'wer', 'Diproses', 'BC 2.3', '324324', '2013-03-17', 'admin');
INSERT INTO pemasukan VALUES('0000000003', 'BPB-2013000003/DEMO', '2013-03-23', 'S00002', '435', '2013-03-23', '3423', 'Disubkontrakkan', 'BC 2.7', '435435', '2013-03-23', 'goestoe');
INSERT INTO pemasukan VALUES('0000000004', 'BPB-2013000004/DEMO', '2013-03-24', 'S00002', '324', '2013-03-24', '3423', 'Disubkontrakkan', 'BC 2.7', '324324', '2013-03-24', 'goestoe');
INSERT INTO pemasukan VALUES('0000000005', 'BPB-2013000005/DEMO', '2013-03-24', 'S00001', 'weew', '2013-03-24', 'we', 'Diproses', 'BC 2.3', '121222', '2013-03-24', 'goestoe');



DROP TABLE IF EXISTS pemasukan_detail;

CREATE TABLE `pemasukan_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_bpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_bpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` char(8) collate latin1_general_ci NOT NULL,
  `nilai` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pemasukan_detail VALUES('0000000001', '15', 'BPB-2013000001/EPSON', '2013-03-17', 'B00002', '1.00', 'JPY', '0.00');
INSERT INTO pemasukan_detail VALUES('0000000002', '16', 'BPB-2013000002/EPSON', '2013-03-17', 'B00002', '1.00', 'JPY', '0.00');
INSERT INTO pemasukan_detail VALUES('0000000003', '17', 'BPB-2013000003/DEMO', '2013-03-23', 'B00002', '1.00', 'JPY', '444.00');
INSERT INTO pemasukan_detail VALUES('0000000003', '18', 'BPB-2013000003/DEMO', '2013-03-23', 'B00003', '1.00', 'JPY', '345.00');
INSERT INTO pemasukan_detail VALUES('0000000004', '19', 'BPB-2013000004/DEMO', '2013-03-24', 'B00003', '1.00', 'JPY', '324234.00');
INSERT INTO pemasukan_detail VALUES('0000000004', '20', 'BPB-2013000004/DEMO', '2013-03-24', 'B00004', '200.00', 'JPY', '324.00');
INSERT INTO pemasukan_detail VALUES('0000000005', '21', 'BPB-2013000005/DEMO', '2013-03-24', 'B00002', '1.00', 'MMK', '0.00');
INSERT INTO pemasukan_detail VALUES('0000000005', '22', 'BPB-2013000005/DEMO', '2013-03-24', 'B00003', '200.00', 'JMD', '122.00');



DROP TABLE IF EXISTS penerima;

CREATE TABLE `penerima` (
  `kode_penerima` char(8) collate latin1_general_ci NOT NULL,
  `npwp` varchar(20) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL,
  `alamat` varchar(200) collate latin1_general_ci NOT NULL,
  `kota` varchar(100) collate latin1_general_ci NOT NULL,
  `negara` varchar(100) collate latin1_general_ci NOT NULL,
  `notelp` varchar(100) collate latin1_general_ci NOT NULL,
  `nofax` varchar(100) collate latin1_general_ci NOT NULL,
  `email` varchar(100) collate latin1_general_ci NOT NULL,
  `status` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO penerima VALUES('P00001', '010002221212000', 'PT Berlian Tahta', 'Bagong Raya Bejasi', 'Bekasi Raya', 'Indonesia', '021-45456', '021', '45asd@gmail.com', 'LDP/Luar Negeri');



DROP TABLE IF EXISTS pengeluaran;

CREATE TABLE `pengeluaran` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_sj` char(100) collate latin1_general_ci NOT NULL,
  `tgl_sj` date NOT NULL,
  `penerima` varchar(100) collate latin1_general_ci NOT NULL,
  `no_invoice` char(100) collate latin1_general_ci NOT NULL,
  `tgl_invoice` date NOT NULL,
  `no_do` char(100) collate latin1_general_ci NOT NULL,
  `catatan` varchar(100) collate latin1_general_ci NOT NULL,
  `jenis_dokpab` char(100) collate latin1_general_ci NOT NULL,
  `no_dokpab` int(6) NOT NULL,
  `tgl_dokpab` date NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pengeluaran VALUES('0000000001', 'SJ-2013000001/EPSON', '2013-03-17', 'P00001', '23432', '2013-03-17', '234', 'Diproses', 'BC 2.7', '23423', '2013-03-17', 'admin');
INSERT INTO pengeluaran VALUES('0000000002', 'SJ-2013000002/DEMO', '2013-03-23', 'P00001', '324324', '2013-03-23', '3423', 'Disubkontrakkan', 'BC 4.1', '454354', '2013-03-23', 'goestoe');
INSERT INTO pengeluaran VALUES('0000000003', 'SJ-2013000003/DEMO', '2013-03-23', 'P00001', '33', '2013-03-23', '345', 'Dipinjamkan', 'BC 2.7', '323233', '2013-03-23', 'goestoe');



DROP TABLE IF EXISTS pengeluaran_detail;

CREATE TABLE `pengeluaran_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_sj` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_sj` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` char(8) collate latin1_general_ci NOT NULL,
  `nilai` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pengeluaran_detail VALUES('0000000001', '2', 'SJ-2013000001/EPSON', '2013-03-17', 'B00002', '1.00', 'JPY', '3434.00');
INSERT INTO pengeluaran_detail VALUES('0000000002', '3', 'SJ-2013000002/DEMO', '2013-03-23', 'B00003', '100.10', 'JPY', '200.20');
INSERT INTO pengeluaran_detail VALUES('0000000002', '4', 'SJ-2013000002/DEMO', '2013-03-23', 'B00002', '500.00', 'JPY', '200.00');
INSERT INTO pengeluaran_detail VALUES('0000000002', '5', 'SJ-2013000002/DEMO', '2013-03-23', 'B00002', '400.10', 'JPY', '500.40');
INSERT INTO pengeluaran_detail VALUES('0000000002', '6', 'SJ-2013000002/DEMO', '2013-03-23', 'B00002', '1.00', 'JPY', '200.00');
INSERT INTO pengeluaran_detail VALUES('0000000003', '7', 'SJ-2013000003/DEMO', '2013-03-23', 'B00004', '1.00', 'USD', '33.00');



DROP TABLE IF EXISTS pengguna;

CREATE TABLE `pengguna` (
  `id` int(4) NOT NULL auto_increment,
  `penggunaid` char(20) collate latin1_general_ci NOT NULL,
  `password` varchar(200) collate latin1_general_ci NOT NULL,
  `nm_pengguna` varchar(100) collate latin1_general_ci NOT NULL,
  `level` enum('BeaCukai','Admin','SuperAdmin') collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO pengguna VALUES('2', 'goestoe', 'ba1d96f9f8a054ae54137008667eecf8', 'Agustu Atihuta', 'SuperAdmin');
INSERT INTO pengguna VALUES('3', 'bayu', '6853aa20dbf58f53d482a55f0ad694a6', 'Bayu Hendra Wianto', 'SuperAdmin');



DROP TABLE IF EXISTS produksi;

CREATE TABLE `produksi` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `no_request` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_request` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi VALUES('0000000001', 'SPB-2013000001/INCOMING', '2013-03-17', '345', '2013-03-17', 'Bagian Penyimpanan Bahan Baku / Penolong', '345', '345', 'admin');



DROP TABLE IF EXISTS produksi_detail;

CREATE TABLE `produksi_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_detail VALUES('0000000001', '10', 'SPB-2013000001/INCOMING', '2013-03-17', 'B00002', '1.00', '45');



DROP TABLE IF EXISTS produksi_incoming;

CREATE TABLE `produksi_incoming` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_incoming VALUES('0000000001', 'SPB-2013000001/PRODUKSI', '2013-03-17', 'Bagian Alat Produksi', '324', '234', 'admin');



DROP TABLE IF EXISTS produksi_incoming_detail;

CREATE TABLE `produksi_incoming_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_incoming_detail VALUES('0000000001', '5', 'SPB-2013000001/PRODUKSI', '2013-03-17', 'B00003', '1.00', '324');



DROP TABLE IF EXISTS produksi_outgoing;

CREATE TABLE `produksi_outgoing` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_outgoing VALUES('0000000001', 'SPB-2013000001/PRODUKSI', '2013-03-17', 'Bagian Alat Produksi', 'ewr', 'wer', 'admin');



DROP TABLE IF EXISTS produksi_outgoing_detail;

CREATE TABLE `produksi_outgoing_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `no_spb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_outgoing_detail VALUES('0000000001', '5', 'SPB-2013000001/PRODUKSI', '2013-03-17', 'B00002', '1.00', 'wer');



DROP TABLE IF EXISTS produksi_terima;

CREATE TABLE `produksi_terima` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `user_trt` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_terima VALUES('0000000001', '23324', '2013-02-14', 'INCOMING', 'ewr', '2013-02-14', 'werwe', 'wer', 'wer', 'goestoe', 'goestoe');
INSERT INTO produksi_terima VALUES('0000000002', 'erwrwer', '2013-02-20', 'INCOMING', '1235', '2013-02-20', '4555', '455', '4555', 'goestoe', 'goestoe');
INSERT INTO produksi_terima VALUES('0000000003', '879', '2013-02-20', 'INCOMING', '78978', '2013-02-20', '789', '789', '789', 'goestoe', 'goestoe');
INSERT INTO produksi_terima VALUES('0000000004', '1234', '2013-03-04', 'INCOMING', '123', '2013-03-04', '123', '123', '234', 'goestoe', 'goestoe');
INSERT INTO produksi_terima VALUES('0000000005', 'LPB-2013000001/PRODUKSI', '2013-03-17', 'OUTGOING', 'SPB-2013000001/OUTGOING', '2013-03-17', 'Bagian Alat Produksi', '34', '34', 'admin', 'admin');



DROP TABLE IF EXISTS produksi_terima_detail;

CREATE TABLE `produksi_terima_detail` (
  `nomor` char(10) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_lpb` varchar(100) collate latin1_general_ci NOT NULL,
  `tgl_lpb` date NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO produksi_terima_detail VALUES('0000000001', '1', 'INCOMING', '23324', '2013-02-14', 'B00001', '200.00', 'ewr');
INSERT INTO produksi_terima_detail VALUES('0000000001', '2', 'INCOMING', '23324', '2013-02-14', 'B00005', '400.00', 'wer');
INSERT INTO produksi_terima_detail VALUES('0000000002', '3', 'INCOMING', 'erwrwer', '2013-02-20', 'B00003', '200.00', '200');
INSERT INTO produksi_terima_detail VALUES('0000000003', '4', 'INCOMING', '879', '2013-02-20', 'B00002', '400.00', '456');
INSERT INTO produksi_terima_detail VALUES('0000000003', '5', 'INCOMING', '879', '2013-02-20', 'B00002', '100.00', '111');
INSERT INTO produksi_terima_detail VALUES('0000000003', '6', 'INCOMING', '879', '2013-02-20', 'B00002', '100.00', '455');
INSERT INTO produksi_terima_detail VALUES('0000000004', '7', 'INCOMING', '1234', '2013-03-04', 'B00002', '1.00', 'jkhj');
INSERT INTO produksi_terima_detail VALUES('0000000004', '8', 'INCOMING', '1234', '2013-03-04', 'B00001', '1.00', 'ert');
INSERT INTO produksi_terima_detail VALUES('0000000005', '9', 'OUTGOING', 'LPB-2013000001/PRODUKSI', '2013-03-17', 'B00003', '1.00', '345');



DROP TABLE IF EXISTS satuan;

CREATE TABLE `satuan` (
  `kode` char(6) collate latin1_general_ci NOT NULL,
  `jenis` varchar(100) collate latin1_general_ci NOT NULL,
  `nama` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO satuan VALUES('SAT001', 'ACR', 'Acre (4840 yd2)');
INSERT INTO satuan VALUES('SAT002', 'AMH', 'Ampere-hour  (3,6 kC)');
INSERT INTO satuan VALUES('SAT003', 'AMP', 'Ampere');
INSERT INTO satuan VALUES('SAT004', 'ANN', 'Year');
INSERT INTO satuan VALUES('SAT005', 'APZ', 'Ounce GB,US (31,10348 g)');
INSERT INTO satuan VALUES('SAT006', 'ARE', 'Are (100m2)');
INSERT INTO satuan VALUES('SAT007', 'ATM', 'Standard atmosphere (101325 Pa)');
INSERT INTO satuan VALUES('SAT008', 'ATT', 'Technical atmosphere (98066,5 Pa)');
INSERT INTO satuan VALUES('SAT009', 'BAR', 'Bar');
INSERT INTO satuan VALUES('SAT010', 'BIL', 'Trillion US / Billion');
INSERT INTO satuan VALUES('SAT011', 'BLD', 'Dry barrel (115,627 dm3)');
INSERT INTO satuan VALUES('SAT012', 'BLL', 'Barrel (petroleum) (458,987 dm3)');
INSERT INTO satuan VALUES('SAT013', 'BUA', 'Bushel (35,2391 dm3)');
INSERT INTO satuan VALUES('SAT014', 'BUI', 'Bushel (36,36874 dm3)');
INSERT INTO satuan VALUES('SAT015', 'CCT', 'Carrying capacity in metric tonnes');
INSERT INTO satuan VALUES('SAT016', 'CDL', 'Candela');
INSERT INTO satuan VALUES('SAT017', 'CEL', 'Degree celcius');
INSERT INTO satuan VALUES('SAT018', 'CEN', 'Hundred');
INSERT INTO satuan VALUES('SAT019', 'CKG', 'Coulomb per kilogram');
INSERT INTO satuan VALUES('SAT020', 'CLT', 'Centilitre');
INSERT INTO satuan VALUES('SAT021', 'CMK', 'Square centimetre');
INSERT INTO satuan VALUES('SAT022', 'CMQ', 'Cubic centimetre');
INSERT INTO satuan VALUES('SAT023', 'CMT', 'Centimetre');
INSERT INTO satuan VALUES('SAT024', 'CNP', 'Hundred packs');
INSERT INTO satuan VALUES('SAT025', 'CNT', 'Cental GB (45,359237 kg)');
INSERT INTO satuan VALUES('SAT026', 'COU', 'Coulomb');
INSERT INTO satuan VALUES('SAT027', 'CTM', 'Metric carat (200 mg = 2.10-4 kg)');
INSERT INTO satuan VALUES('SAT028', 'CWA', 'Hundredweight, US (45,3592 kg)');
INSERT INTO satuan VALUES('SAT029', 'CWI', 'Long/ hundredweight GB (50,802345 kg)');
INSERT INTO satuan VALUES('SAT030', 'DAA', 'Decare');
INSERT INTO satuan VALUES('SAT031', 'DAD', 'Ten day');
INSERT INTO satuan VALUES('SAT032', 'DAY', 'Day');
INSERT INTO satuan VALUES('SAT033', 'DBC', 'Decade (ten years)');
INSERT INTO satuan VALUES('SAT034', 'DMK', 'Square decimetre');
INSERT INTO satuan VALUES('SAT035', 'DMQ', 'Cubic decimetre');
INSERT INTO satuan VALUES('SAT036', 'DMT', 'Decimetre');
INSERT INTO satuan VALUES('SAT037', 'DPR', 'Dozen pairs');
INSERT INTO satuan VALUES('SAT038', 'DPT', 'Displecement tonnege');
INSERT INTO satuan VALUES('SAT039', 'DRA', 'Dram US (3,887935 g)');
INSERT INTO satuan VALUES('SAT040', 'DRI', 'Dram GB (1,771745 g)');
INSERT INTO satuan VALUES('SAT041', 'DRL', 'Dozen rolls');
INSERT INTO satuan VALUES('SAT042', 'DRM', 'Drachm, GB (3,887935 g)');
INSERT INTO satuan VALUES('SAT043', 'DTN', 'Decitonne, Centner, Quintall, metric (100 kg)');
INSERT INTO satuan VALUES('SAT044', 'DWT', 'Pennyweight GB,US (1,555174 g)');
INSERT INTO satuan VALUES('SAT045', 'DZN', 'Dozen');
INSERT INTO satuan VALUES('SAT046', 'DZP', 'Dozen packs');
INSERT INTO satuan VALUES('SAT047', 'FAH', 'degree Fahrenheit');
INSERT INTO satuan VALUES('SAT048', 'FOT', 'Foot (0.3048 m)');
INSERT INTO satuan VALUES('SAT049', 'FTK', 'Square foot');
INSERT INTO satuan VALUES('SAT050', 'FTQ', 'Cubic foot');
INSERT INTO satuan VALUES('SAT051', 'GBQ', 'Gigabecquerel');
INSERT INTO satuan VALUES('SAT052', 'GGR', 'Great gross (12 gross)');
INSERT INTO satuan VALUES('SAT053', 'GIA', 'Gill (11,8294 cm3)');
INSERT INTO satuan VALUES('SAT054', 'GII', 'Gill (0,142065 dm3)');
INSERT INTO satuan VALUES('SAT055', 'GLD', 'Dry gallon (4,404884 dm3)');
INSERT INTO satuan VALUES('SAT056', 'GLI', 'Gallon (4,546092 dm3)');
INSERT INTO satuan VALUES('SAT057', 'GLL', 'Liquid gallon (3,78541 dm3)');
INSERT INTO satuan VALUES('SAT058', 'GRM', 'Gram');
INSERT INTO satuan VALUES('SAT059', 'GRN', 'Grain GB,US (64,798910 mg)');
INSERT INTO satuan VALUES('SAT060', 'GRO', 'Gross');
INSERT INTO satuan VALUES('SAT061', 'GRT', 'Gross (register) ton');
INSERT INTO satuan VALUES('SAT062', 'GWH', 'Gigawatt-hour (1 million KW/h)');
INSERT INTO satuan VALUES('SAT063', 'HAR', 'Hectare');
INSERT INTO satuan VALUES('SAT064', 'HBA', 'Hectobar');
INSERT INTO satuan VALUES('SAT065', 'HGM', 'Hectogram');
INSERT INTO satuan VALUES('SAT066', 'HIU', 'Hundred intenational units');
INSERT INTO satuan VALUES('SAT067', 'HLT', 'Hectolitre');
INSERT INTO satuan VALUES('SAT068', 'HMQ', 'Million cubic metres');
INSERT INTO satuan VALUES('SAT069', 'HMT', 'Hectometre');
INSERT INTO satuan VALUES('SAT070', 'HPA', 'Hectolitre of pure alcohol');
INSERT INTO satuan VALUES('SAT071', 'HTZ', 'Hertz');
INSERT INTO satuan VALUES('SAT072', 'HUR', 'Hour');
INSERT INTO satuan VALUES('SAT073', 'INH', 'Inch (2.54 mm)');
INSERT INTO satuan VALUES('SAT074', 'INK', 'Square inch');
INSERT INTO satuan VALUES('SAT075', 'INQ', 'Cubic inch');
INSERT INTO satuan VALUES('SAT076', 'JOU', 'Joule');
INSERT INTO satuan VALUES('SAT077', 'KBA', 'Kilobar');
INSERT INTO satuan VALUES('SAT078', 'KEL', 'Kelvin');
INSERT INTO satuan VALUES('SAT079', 'KGM', 'Kilogram');
INSERT INTO satuan VALUES('SAT080', 'KJO', 'Kilojoule');
INSERT INTO satuan VALUES('SAT081', 'KMH', 'Kilometre per hour');
INSERT INTO satuan VALUES('SAT082', 'KMK', 'Square kilometre');
INSERT INTO satuan VALUES('SAT083', 'KMQ', 'Kilogram per cubic meter');
INSERT INTO satuan VALUES('SAT084', 'KMT', 'Kilometre');
INSERT INTO satuan VALUES('SAT085', 'KNI', 'Kilogram of nitrogen');
INSERT INTO satuan VALUES('SAT086', 'KNS', 'Kilogram of named substance');
INSERT INTO satuan VALUES('SAT087', 'KNT', 'Knot ( 1 n mile oer hour');
INSERT INTO satuan VALUES('SAT088', 'KPH', 'Kilogram of potassium hydroxide (caustic pota');
INSERT INTO satuan VALUES('SAT089', 'KPO', 'Kilogram of potassium oxide');
INSERT INTO satuan VALUES('SAT090', 'KPP', 'Kilogram of phosphorus pentoxide  (phosphoric');
INSERT INTO satuan VALUES('SAT091', 'KSD', 'Kilogram of substance 90 per cent dry');
INSERT INTO satuan VALUES('SAT092', 'KSH', 'Kilogram of sodium hydyoxide  (caustic soda)');
INSERT INTO satuan VALUES('SAT093', 'KTN', 'Kilotonne');
INSERT INTO satuan VALUES('SAT094', 'KUR', 'Kilogram of uranium');
INSERT INTO satuan VALUES('SAT095', 'KVA', 'Kilovolt - ampere');
INSERT INTO satuan VALUES('SAT096', 'KWH', 'Kilowatt-hour');
INSERT INTO satuan VALUES('SAT097', 'KWT', 'Kilowatt');
INSERT INTO satuan VALUES('SAT098', 'LBR', 'Pound GB,US (0,45359237 kg)');
INSERT INTO satuan VALUES('SAT099', 'LBT', 'Troy pound, US 9373,242 g)');
INSERT INTO satuan VALUES('SAT100', 'LNT', 'Long ton GB, US 2/ (1,0160469 t)');
INSERT INTO satuan VALUES('SAT101', 'LPA', 'Litre of pure alcohol');
INSERT INTO satuan VALUES('SAT102', 'LTR', 'Litre ( 1 dm3 )');
INSERT INTO satuan VALUES('SAT103', 'LUM', 'Lumen');
INSERT INTO satuan VALUES('SAT104', 'MAL', 'Megalitre');
INSERT INTO satuan VALUES('SAT105', 'MAM', 'Megametre');
INSERT INTO satuan VALUES('SAT106', 'MAW', 'Megawatt');
INSERT INTO satuan VALUES('SAT107', 'MGM', 'Milligram');
INSERT INTO satuan VALUES('SAT108', 'MID', 'Thousand');
INSERT INTO satuan VALUES('SAT109', 'MIK', 'Square mile');
INSERT INTO satuan VALUES('SAT110', 'MIN', 'Minute');
INSERT INTO satuan VALUES('SAT111', 'MIO', 'Million');
INSERT INTO satuan VALUES('SAT112', 'MIU', 'Million international units');
INSERT INTO satuan VALUES('SAT113', 'MLD', 'Milliard, Billion US');
INSERT INTO satuan VALUES('SAT114', 'MLT', 'Millilitre');
INSERT INTO satuan VALUES('SAT115', 'MMK', 'Square millimetre');
INSERT INTO satuan VALUES('SAT116', 'MMQ', 'Cubic millimetre');
INSERT INTO satuan VALUES('SAT117', 'MMT', 'Millimetre');
INSERT INTO satuan VALUES('SAT118', 'MON', 'Month');
INSERT INTO satuan VALUES('SAT119', 'MQH', 'cubic metre per hour');
INSERT INTO satuan VALUES('SAT120', 'MSK', 'Metre per second squared');
INSERT INTO satuan VALUES('SAT121', 'MTK', 'Square metre');
INSERT INTO satuan VALUES('SAT122', 'MTQ', 'Cubic metre');
INSERT INTO satuan VALUES('SAT123', 'MTR', 'Metre');
INSERT INTO satuan VALUES('SAT124', 'MVA', 'Megavolt -  ampere (1000 KVA)');
INSERT INTO satuan VALUES('SAT125', 'MWH', 'Megawatt-hour (1000 KW/h)');
INSERT INTO satuan VALUES('SAT126', 'NAR', 'Number of articles');
INSERT INTO satuan VALUES('SAT127', 'NBB', 'Number bobbins');
INSERT INTO satuan VALUES('SAT128', 'NEW', 'Newton');
INSERT INTO satuan VALUES('SAT129', 'NIU', 'Number of international units');
INSERT INTO satuan VALUES('SAT130', 'NMB', 'Number');
INSERT INTO satuan VALUES('SAT131', 'NMI', 'Nautical mile (1852 m)');
INSERT INTO satuan VALUES('SAT132', 'NMP', 'Number of packs');
INSERT INTO satuan VALUES('SAT133', 'NPL', 'Number of parcels');
INSERT INTO satuan VALUES('SAT134', 'NPR', 'number of pairs');
INSERT INTO satuan VALUES('SAT135', 'NPT', 'Number of parts');
INSERT INTO satuan VALUES('SAT136', 'NRL', 'Number of rolls');
INSERT INTO satuan VALUES('SAT137', 'NTT', 'Net (regirter) ton');
INSERT INTO satuan VALUES('SAT138', 'OHM', 'Ohm');
INSERT INTO satuan VALUES('SAT139', 'ONZ', 'Ounce GB,US (28,349523 g)');
INSERT INTO satuan VALUES('SAT140', 'OZA', 'Fluid ounce (29,5735 cm3)');
INSERT INTO satuan VALUES('SAT141', 'OZI', 'Fluid ounce (29,5735 cm3)');
INSERT INTO satuan VALUES('SAT142', 'PAL', 'Pascal');
INSERT INTO satuan VALUES('SAT143', 'PCE', 'Piece');
INSERT INTO satuan VALUES('SAT144', 'PGL', 'Proof gallon');
INSERT INTO satuan VALUES('SAT145', 'PTD', 'Dry pint (0.55061 dm3)');
INSERT INTO satuan VALUES('SAT146', 'PTI', 'Pint (0,568262 dm3)');
INSERT INTO satuan VALUES('SAT147', 'PTL', 'Liquid Pint (0,473176 dm3)');
INSERT INTO satuan VALUES('SAT148', 'QAN', 'Quarter (of a year)');
INSERT INTO satuan VALUES('SAT149', 'QTD', 'Dry quart (1,101221 dm3)');
INSERT INTO satuan VALUES('SAT150', 'QTI', 'Quart (1,136523 dm3)');
INSERT INTO satuan VALUES('SAT151', 'QTL', 'Liquid quart (0,946353 dm3)');
INSERT INTO satuan VALUES('SAT152', 'QTR', 'Quarter GB (12,700586 kg)');
INSERT INTO satuan VALUES('SAT153', 'RPM', 'Revolution per minute');
INSERT INTO satuan VALUES('SAT154', 'RPS', 'Revolution per second');
INSERT INTO satuan VALUES('SAT155', 'SAN', 'Half year (six Months)');
INSERT INTO satuan VALUES('SAT156', 'SCO', 'Score');
INSERT INTO satuan VALUES('SAT157', 'SCR', 'Scruple GP,US (1,295982 g)');
INSERT INTO satuan VALUES('SAT158', 'SEC', 'Second');
INSERT INTO satuan VALUES('SAT159', 'SET', 'Set');
INSERT INTO satuan VALUES('SAT160', 'SHT', 'Shipping ton');
INSERT INTO satuan VALUES('SAT161', 'SIE', 'Siemens');
INSERT INTO satuan VALUES('SAT162', 'SMI', 'Statute mile (1609.344 m)');
INSERT INTO satuan VALUES('SAT163', 'SST', 'Short standard  (7200 matches )');
INSERT INTO satuan VALUES('SAT164', 'STI', 'Stone GB (6,350293 kg)');
INSERT INTO satuan VALUES('SAT165', 'STN', 'Short ton GB, US 2/ (0,90718474 t)');
INSERT INTO satuan VALUES('SAT166', 'TAH', 'Thousand ampere-hour');
INSERT INTO satuan VALUES('SAT167', 'TNE', 'Tonne, Metric ton (1000 kg)');
INSERT INTO satuan VALUES('SAT168', 'TPR', 'Ten pairs');
INSERT INTO satuan VALUES('SAT169', 'TQD', 'Thousand cubic metres per day');
INSERT INTO satuan VALUES('SAT170', 'TRL', 'Trillion Eur');
INSERT INTO satuan VALUES('SAT171', 'TSD', 'Tonne of subtance 90 per cent dry');
INSERT INTO satuan VALUES('SAT172', 'TSH', 'Ton of steam per hour');
INSERT INTO satuan VALUES('SAT173', 'VLT', 'Volt');
INSERT INTO satuan VALUES('SAT174', 'WCD', 'Cord (3,63 m3)');
INSERT INTO satuan VALUES('SAT175', 'WEB', 'Weber');
INSERT INTO satuan VALUES('SAT176', 'WEE', 'Week');
INSERT INTO satuan VALUES('SAT177', 'WHR', 'Watt-hour');
INSERT INTO satuan VALUES('SAT178', 'WSD', 'Standard');
INSERT INTO satuan VALUES('SAT179', 'WTT', 'Watt');
INSERT INTO satuan VALUES('SAT180', 'YDK', 'Square yard');
INSERT INTO satuan VALUES('SAT181', 'YDQ', 'Cubic yard');
INSERT INTO satuan VALUES('SAT182', 'YRD', 'Yard (0.9144 m)');



DROP TABLE IF EXISTS stock_pemasukan;

CREATE TABLE `stock_pemasukan` (
  `id` int(8) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO stock_pemasukan VALUES('1', 'B00002', '5001.00');
INSERT INTO stock_pemasukan VALUES('2', 'B00007', '3000.00');
INSERT INTO stock_pemasukan VALUES('3', 'B00009', '3000.00');
INSERT INTO stock_pemasukan VALUES('4', 'B00002', '2999.00');
INSERT INTO stock_pemasukan VALUES('5', 'B00003', '3202.00');
INSERT INTO stock_pemasukan VALUES('6', 'B00004', '3200.00');
INSERT INTO stock_pemasukan VALUES('7', 'B00005', '3000.00');
INSERT INTO stock_pemasukan VALUES('8', 'B00006', '3000.00');
INSERT INTO stock_pemasukan VALUES('9', 'B00001', '551.00');
INSERT INTO stock_pemasukan VALUES('10', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('11', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('12', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('13', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('14', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('15', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('16', 'B00002', '0.00');
INSERT INTO stock_pemasukan VALUES('17', 'B00002', '1.00');
INSERT INTO stock_pemasukan VALUES('18', 'B00002', '1.00');



DROP TABLE IF EXISTS stock_pengeluaran;

CREATE TABLE `stock_pengeluaran` (
  `id` int(8) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO stock_pengeluaran VALUES('1', 'B00001', '2399.00');
INSERT INTO stock_pengeluaran VALUES('2', 'B00003', '2496.90');
INSERT INTO stock_pengeluaran VALUES('3', 'B00004', '2599.00');
INSERT INTO stock_pengeluaran VALUES('4', 'B00005', '2800.00');
INSERT INTO stock_pengeluaran VALUES('5', 'B00006', '2600.00');
INSERT INTO stock_pengeluaran VALUES('6', 'B00007', '3000.00');
INSERT INTO stock_pengeluaran VALUES('7', 'B00008', '3000.00');
INSERT INTO stock_pengeluaran VALUES('8', 'B00009', '3000.00');
INSERT INTO stock_pengeluaran VALUES('9', 'B00002', '2096.90');
INSERT INTO stock_pengeluaran VALUES('10', 'B00003', '2899.90');
INSERT INTO stock_pengeluaran VALUES('11', 'B00004', '2999.00');
INSERT INTO stock_pengeluaran VALUES('12', 'B00005', '3000.00');
INSERT INTO stock_pengeluaran VALUES('13', 'B00006', '3000.00');
INSERT INTO stock_pengeluaran VALUES('14', 'B00007', '3000.00');
INSERT INTO stock_pengeluaran VALUES('15', 'B00008', '3000.00');
INSERT INTO stock_pengeluaran VALUES('16', 'B00009', '3000.00');
INSERT INTO stock_pengeluaran VALUES('17', 'B00002', '2096.90');
INSERT INTO stock_pengeluaran VALUES('18', 'B00003', '2899.90');
INSERT INTO stock_pengeluaran VALUES('19', 'B00004', '2999.00');
INSERT INTO stock_pengeluaran VALUES('20', 'B00005', '3000.00');
INSERT INTO stock_pengeluaran VALUES('21', 'B00006', '3000.00');
INSERT INTO stock_pengeluaran VALUES('22', 'B00009', '3000.00');
INSERT INTO stock_pengeluaran VALUES('23', 'B00002', '-602.90');
INSERT INTO stock_pengeluaran VALUES('24', 'B00003', '100.00');
INSERT INTO stock_pengeluaran VALUES('25', 'B00004', '999.25');
INSERT INTO stock_pengeluaran VALUES('26', 'B00005', '3000.00');
INSERT INTO stock_pengeluaran VALUES('27', 'B00006', '3000.00');
INSERT INTO stock_pengeluaran VALUES('28', 'B00007', '3000.00');
INSERT INTO stock_pengeluaran VALUES('29', 'B00008', '3000.00');
INSERT INTO stock_pengeluaran VALUES('30', 'B00009', '3000.00');
INSERT INTO stock_pengeluaran VALUES('31', 'B00001', '1.00');
INSERT INTO stock_pengeluaran VALUES('32', 'B00002', '-900.10');
INSERT INTO stock_pengeluaran VALUES('33', 'B00001', '1.00');
INSERT INTO stock_pengeluaran VALUES('34', 'B00001', '1.00');



DROP TABLE IF EXISTS stock_produksi;

CREATE TABLE `stock_produksi` (
  `id` int(8) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO stock_produksi VALUES('1', 'B00004', '3000.00');
INSERT INTO stock_produksi VALUES('2', 'B00002', '1999.00');
INSERT INTO stock_produksi VALUES('4', 'B00005', '3300.00');
INSERT INTO stock_produksi VALUES('5', 'B00006', '3000.00');
INSERT INTO stock_produksi VALUES('6', 'B00007', '3000.00');
INSERT INTO stock_produksi VALUES('7', 'B00008', '3000.00');
INSERT INTO stock_produksi VALUES('8', 'B00001', '5001.00');
INSERT INTO stock_produksi VALUES('10', 'B00003', '3000.00');
INSERT INTO stock_produksi VALUES('11', 'B00004', '3000.00');
INSERT INTO stock_produksi VALUES('12', 'B00005', '3000.00');
INSERT INTO stock_produksi VALUES('13', 'B00006', '3000.00');
INSERT INTO stock_produksi VALUES('14', 'B00007', '3000.00');
INSERT INTO stock_produksi VALUES('15', 'B00009', '3000.00');
INSERT INTO stock_produksi VALUES('16', 'B00004', '3.00');
INSERT INTO stock_produksi VALUES('20', 'B00004', '403.00');
INSERT INTO stock_produksi VALUES('19', 'B00004', '400.00');



DROP TABLE IF EXISTS tbl_stockopname;

CREATE TABLE `tbl_stockopname` (
  `tglstock` date NOT NULL,
  `no_surat` varchar(150) collate latin1_general_ci NOT NULL,
  `tglsurat` date NOT NULL,
  `petugas` varchar(255) collate latin1_general_ci NOT NULL,
  `kode_brg` varchar(100) collate latin1_general_ci NOT NULL,
  `saldo` float(10,2) NOT NULL,
  `stockopname` float(10,2) NOT NULL,
  `selisih` float(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tbl_stockopname VALUES('2013-02-01', '34534', '2013-02-01', '43534', 'B00002', '1300.00', '2500.00', '200.00');
INSERT INTO tbl_stockopname VALUES('2012-12-31', 'rtertert', '2012-12-31', 'ertert', 'B00001', '2000.00', '2000.00', '2200.00');



DROP TABLE IF EXISTS tmp_adjusment;

CREATE TABLE `tmp_adjusment` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `cat` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_bahanbaku;

CREATE TABLE `tmp_bahanbaku` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_barang;

CREATE TABLE `tmp_barang` (
  `id` varchar(4) collate latin1_general_ci NOT NULL,
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `nm_barang` varchar(100) collate latin1_general_ci NOT NULL,
  `type` varchar(100) collate latin1_general_ci NOT NULL,
  `spec` varchar(100) collate latin1_general_ci NOT NULL,
  `stok` float(10,2) NOT NULL,
  `satuan` varchar(100) collate latin1_general_ci NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `kd_kategori` char(3) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_brgjadi;

CREATE TABLE `tmp_brgjadi` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_closing;

CREATE TABLE `tmp_closing` (
  `id` int(4) NOT NULL,
  `tgl_closing` date NOT NULL,
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `stock` float(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_closing VALUES('1', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('2', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('3', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('4', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('5', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('6', '2012-02-26', 'B00001', '400.00');
INSERT INTO tmp_closing VALUES('7', '2012-02-26', 'B00001', '400.00');



DROP TABLE IF EXISTS tmp_daftar_kodebrg;

CREATE TABLE `tmp_daftar_kodebrg` (
  `id` varchar(4) collate latin1_general_ci NOT NULL,
  `kd_barang` char(100) collate latin1_general_ci NOT NULL,
  `nm_barang` varchar(100) collate latin1_general_ci NOT NULL,
  `type` varchar(100) collate latin1_general_ci NOT NULL,
  `spec` varchar(100) collate latin1_general_ci NOT NULL,
  `satuan` varchar(10) collate latin1_general_ci NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `kd_kategori` char(3) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_brgjadi;

CREATE TABLE `tmp_detail_brgjadi` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_incoming;

CREATE TABLE `tmp_detail_incoming` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` varchar(100) collate latin1_general_ci NOT NULL,
  `nilai` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_incoming_outgoing;

CREATE TABLE `tmp_detail_incoming_outgoing` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_outgoing;

CREATE TABLE `tmp_detail_outgoing` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` varchar(100) collate latin1_general_ci NOT NULL,
  `nilai` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_outgoing_incoming;

CREATE TABLE `tmp_detail_outgoing_incoming` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_outgoing_produksi;

CREATE TABLE `tmp_detail_outgoing_produksi` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_produksi;

CREATE TABLE `tmp_detail_produksi` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_produksi_incoming;

CREATE TABLE `tmp_detail_produksi_incoming` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_detail_produksi_outgoing;

CREATE TABLE `tmp_detail_produksi_outgoing` (
  `id` char(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_incoming_outgoing;

CREATE TABLE `tmp_incoming_outgoing` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_incoming_outgoing VALUES('2', 'B00003', '1.00', '100', 'goestoe');
INSERT INTO tmp_incoming_outgoing VALUES('3', 'B00003', '1.00', 'jer', 'goestoe');



DROP TABLE IF EXISTS tmp_incoming_terima;

CREATE TABLE `tmp_incoming_terima` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `user_trt` char(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_incoming_terima VALUES('OUT-0000000001', 'OUTGOING', 'SPB-2013000001/OUTGOING', '2013-03-17', 'Bagian Alat Produksi', 'ewr', 'wer', 'admin');



DROP TABLE IF EXISTS tmp_incoming_terima_detail;

CREATE TABLE `tmp_incoming_terima_detail` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_incoming_terima_detail VALUES('OUT-0000000001', '6', 'OUTGOING', 'B00001', '1.00', 'wre');



DROP TABLE IF EXISTS tmp_konversi;

CREATE TABLE `tmp_konversi` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(200) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_konversi VALUES('3', 'B00002', '1.00', 'try', 'goestoe');



DROP TABLE IF EXISTS tmp_outgoing_incoming;

CREATE TABLE `tmp_outgoing_incoming` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_outgoing_produksi;

CREATE TABLE `tmp_outgoing_produksi` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_outgoing_terima;

CREATE TABLE `tmp_outgoing_terima` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `user_trt` char(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_outgoing_terima VALUES('INC-0000000001', 'INCOMING', 'fdg', '2013-02-18', 'dfg', 'dfg', 'dfg', 'goestoe');
INSERT INTO tmp_outgoing_terima VALUES('PROD-0000000003', 'PRODUKSI', '12', '2013-03-07', 'Bagian Penyimpanan Barang Sisa / Scrap', 'fdf', 'dfgdf', 'goestoe');
INSERT INTO tmp_outgoing_terima VALUES('INC-0000000001', 'INCOMING', 'SPB-2013000001/INCOMING', '2013-03-17', 'Bagian Penyimpanan Bahan Baku / Penolong', 'wer', 'wer', 'admin');



DROP TABLE IF EXISTS tmp_outgoing_terima_detail;

CREATE TABLE `tmp_outgoing_terima_detail` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_outgoing_terima_detail VALUES('INC-0000000001', '1', 'INCOMING', 'B00002', '200.00', 'dfgdfg');
INSERT INTO tmp_outgoing_terima_detail VALUES('PROD-0000000003', '5', 'PRODUKSI', 'B00001', '1.00', '4');
INSERT INTO tmp_outgoing_terima_detail VALUES('INC-0000000001', '6', 'INCOMING', 'B00002', '1.00', 'wer');



DROP TABLE IF EXISTS tmp_pemasukan;

CREATE TABLE `tmp_pemasukan` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` char(4) collate latin1_general_ci NOT NULL,
  `nilai` float(10,2) NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_pemasukan VALUES('31', 'B00002', '1.00', 'USD', '345345.00', 'goestoe');
INSERT INTO tmp_pemasukan VALUES('32', 'B00004', '1.00', 'NAD', '45645.00', 'goestoe');
INSERT INTO tmp_pemasukan VALUES('33', 'B00003', '1.00', 'NAD', '45645.00', 'goestoe');



DROP TABLE IF EXISTS tmp_pengeluaran;

CREATE TABLE `tmp_pengeluaran` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `valuta` char(4) collate latin1_general_ci NOT NULL,
  `nilai` float(10,2) NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_produksi;

CREATE TABLE `tmp_produksi` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_produksi_incoming;

CREATE TABLE `tmp_produksi_incoming` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_produksi_outgoing;

CREATE TABLE `tmp_produksi_outgoing` (
  `id` int(4) NOT NULL auto_increment,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` varchar(100) collate latin1_general_ci NOT NULL,
  `userid` char(8) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_produksi_terima;

CREATE TABLE `tmp_produksi_terima` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `no_spb` char(100) collate latin1_general_ci NOT NULL,
  `tgl_spb` date NOT NULL,
  `dept` char(200) collate latin1_general_ci NOT NULL,
  `name_ppc` char(200) collate latin1_general_ci NOT NULL,
  `catatan` varchar(200) collate latin1_general_ci NOT NULL,
  `user_trt` char(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_produksi_terima VALUES('INC-0000000005', 'INCOMING', '123', '2013-03-07', 'Bagian Penyimpanan Barang Sisa / Scrap', '21', '123', 'goestoe');
INSERT INTO tmp_produksi_terima VALUES('INC-0000000001', 'INCOMING', 'SPB-2013000001/INCOMING', '2013-03-17', 'Bagian Penyimpanan Bahan Baku / Penolong', '345', '345', 'admin');



DROP TABLE IF EXISTS tmp_produksi_terima_detail;

CREATE TABLE `tmp_produksi_terima_detail` (
  `nomor` char(15) collate latin1_general_ci NOT NULL,
  `id` int(10) NOT NULL auto_increment,
  `dari` varchar(255) collate latin1_general_ci NOT NULL,
  `kode` char(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL,
  `ket` char(200) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_produksi_terima_detail VALUES('INC-0000000005', '3', 'INCOMING', 'B00003', '1.00', '54');
INSERT INTO tmp_produksi_terima_detail VALUES('INC-0000000001', '4', 'INCOMING', 'B00002', '1.00', '45');



DROP TABLE IF EXISTS tmp_stock_pemasukan;

CREATE TABLE `tmp_stock_pemasukan` (
  `id` varchar(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_stock_pemasukan VALUES('1', 'B00002', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('2', 'B00003', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('3', 'B00004', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('4', 'B00005', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('5', 'B00006', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('6', 'B00007', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('7', 'B00008', '3000.00');
INSERT INTO tmp_stock_pemasukan VALUES('8', 'B00009', '3000.00');



DROP TABLE IF EXISTS tmp_stock_pengeluaran;

CREATE TABLE `tmp_stock_pengeluaran` (
  `id` varchar(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;




DROP TABLE IF EXISTS tmp_stock_produksi;

CREATE TABLE `tmp_stock_produksi` (
  `id` varchar(4) collate latin1_general_ci NOT NULL,
  `kode` varchar(100) collate latin1_general_ci NOT NULL,
  `jumlah` float(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO tmp_stock_produksi VALUES('1', 'B00002', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('2', 'B00003', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('3', 'B00004', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('4', 'B00005', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('5', 'B00006', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('6', 'B00007', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('7', 'B00008', '3000.00');
INSERT INTO tmp_stock_produksi VALUES('8', 'B00009', '3000.00');



DROP TABLE IF EXISTS user_act;

CREATE TABLE `user_act` (
  `id` int(10) NOT NULL auto_increment,
  `userid` varchar(12) collate latin1_general_ci NOT NULL,
  `aktivitas` varchar(255) collate latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=201 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO user_act VALUES('1', 'goestoe', 'Menyimpan data mata uang dengan data jenis USD nama Dollar Amerika', '2013-02-17', '00:00:00');
INSERT INTO user_act VALUES('2', 'goestoe', 'Menyimpan data mata uang dengan data jenis IDR dan nama Indonesian Rupiah', '2013-02-17', '23:45:24');
INSERT INTO user_act VALUES('3', 'goestoe', 'Menambah data transaksi incoming - outgoing nomor SPB: fdg dan tanggal 18-02-2013', '2013-02-18', '11:11:12');
INSERT INTO user_act VALUES('4', 'goestoe', 'Menambah data user dengan nama Super Admin 2 dan userid super', '2013-02-18', '12:38:05');
INSERT INTO user_act VALUES('5', 'super', 'Mengubah data user dengan nama Super Admin1 dan userid goestoe', '2013-02-18', '12:47:29');
INSERT INTO user_act VALUES('6', 'goestoe', 'Menambah data transaksi produksi-outgoing nomor BPB: 4567 dan tanggal 18-02-2013', '2013-02-18', '18:31:01');
INSERT INTO user_act VALUES('7', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 324 dan tanggal 18-02-2013', '2013-02-18', '23:03:10');
INSERT INTO user_act VALUES('8', 'goestoe', 'Menambah data transaksi incoming-produksi dengan nomor SPB: 1235 dan tanggal 20-02-2013', '2013-02-20', '17:19:52');
INSERT INTO user_act VALUES('9', 'goestoe', 'Mengubah data perusahaan', '2013-02-20', '18:55:57');
INSERT INTO user_act VALUES('10', 'goestoe', 'Menambah data adjustment dengan nomor gf456 tanggal 20-02-2013', '2013-02-20', '18:56:45');
INSERT INTO user_act VALUES('11', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-02-20', '18:57:00');
INSERT INTO user_act VALUES('12', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-02-20', '18:57:06');
INSERT INTO user_act VALUES('13', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-02-20', '19:01:18');
INSERT INTO user_act VALUES('14', 'goestoe', 'Mengubah data barang dengan nama Celana Jeans', '2013-02-20', '19:05:02');
INSERT INTO user_act VALUES('15', 'goestoe', 'Menambah data pemasok/supplier dengan kode S00001 dan nama PT Kolang Kaling', '2013-02-20', '19:11:16');
INSERT INTO user_act VALUES('16', 'goestoe', 'Mengubah data jenis dokpab masuk dengan jenis BC 2.3 dan nama Pemasukan barang dari Luar Daerah Pabean/Luar Negeri', '2013-02-20', '19:12:37');
INSERT INTO user_act VALUES('17', 'goestoe', 'Mengubah data barang dengan nama Baju', '2013-02-20', '19:13:23');
INSERT INTO user_act VALUES('18', 'goestoe', 'Mengubah data barang dengan nama Kaos', '2013-02-20', '19:13:44');
INSERT INTO user_act VALUES('19', 'goestoe', 'Mengubah data barang dengan nama Batu', '2013-02-20', '19:13:57');
INSERT INTO user_act VALUES('20', 'goestoe', 'Mengubah data perusahaan', '2013-02-20', '19:15:19');
INSERT INTO user_act VALUES('21', 'goestoe', 'Mengubah data barang dengan kode  dan nama Kaos Baru', '2013-02-20', '19:17:35');
INSERT INTO user_act VALUES('22', 'goestoe', 'Mengubah data barang dengan kode B00004 dan nama Batu Besar', '2013-02-20', '19:18:45');
INSERT INTO user_act VALUES('23', 'goestoe', 'Menghapus data barang dengan kode: B00004', '2013-02-20', '19:20:14');
INSERT INTO user_act VALUES('24', 'goestoe', 'Menghapus data barang dengan kode: B00003', '2013-02-20', '19:34:34');
INSERT INTO user_act VALUES('25', 'goestoe', 'Mengubah data barang dengan kode B00002 dan nama Celana Jeans', '2013-02-20', '19:34:49');
INSERT INTO user_act VALUES('26', 'goestoe', 'Mengubah data barang dengan kode B00002 dan nama Celana Jeans', '2013-02-20', '19:34:57');
INSERT INTO user_act VALUES('27', 'goestoe', 'Mengubah data barang dengan kode B00002 dan nama Celana Jeans', '2013-02-20', '19:35:04');
INSERT INTO user_act VALUES('28', 'goestoe', 'Mengubah data tujuan pengiriman dengan kode:CAT-0007 dan nama Pengembalian Pinjaman', '2013-02-20', '19:38:24');
INSERT INTO user_act VALUES('29', 'goestoe', 'Menambah data pemasok/supplier dengan kode S00001 dan nama PT Kolang Kaling', '2013-02-20', '19:42:00');
INSERT INTO user_act VALUES('30', 'goestoe', 'Mengubah data pemasok/supplier dengan kode: S00001 dan nama PT Kolang Kaling', '2013-02-20', '19:43:56');
INSERT INTO user_act VALUES('31', 'goestoe', 'Menghapus data pemasok/supplier dengan kode: S00001', '2013-02-20', '19:44:10');
INSERT INTO user_act VALUES('32', 'goestoe', 'Mengubah data satuan barang dengan jenis Mtr dan nama Meter Panjang Pendek', '2013-02-20', '19:45:24');
INSERT INTO user_act VALUES('33', 'goestoe', 'Menghapus data satuan barang dengan kode: SAT001', '2013-02-20', '19:45:42');
INSERT INTO user_act VALUES('34', 'goestoe', 'Menambah data PENERIMA dengan kode P00001 dan nama PT Berlian Tahta', '2013-02-20', '19:46:20');
INSERT INTO user_act VALUES('35', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-02-20', '19:46:46');
INSERT INTO user_act VALUES('36', 'goestoe', 'Mengubah data perusahaan', '2013-02-20', '19:47:03');
INSERT INTO user_act VALUES('37', 'goestoe', 'Mengubah data mata uang dengan data jenis USD dan nama Dollar Amerika Serikat', '2013-02-20', '19:47:31');
INSERT INTO user_act VALUES('38', 'goestoe', 'Menghapus data mata uang dengan data kode:CUR003', '2013-02-20', '19:47:43');
INSERT INTO user_act VALUES('39', 'goestoe', 'Menerima barang PRODUKSI dengan nomor LPB: erwrwer dan tanggal 20-02-2013', '2013-02-20', '19:49:23');
INSERT INTO user_act VALUES('40', 'goestoe', 'Menambah data transaksi incoming-produksi dengan nomor SPB: 78978 dan tanggal 20-02-2013', '2013-02-20', '20:00:56');
INSERT INTO user_act VALUES('41', 'goestoe', 'Menerima barang PRODUKSI dengan nomor LPB: 879 dan tanggal 20-02-2013', '2013-02-20', '20:01:10');
INSERT INTO user_act VALUES('42', 'goestoe', 'Menambah data satuan barang dengan jenis PCS dan nama Pieces', '2013-02-20', '20:10:19');
INSERT INTO user_act VALUES('43', 'goestoe', 'Mengubah data barang dengan kode B00002 dan nama Celana Jeans', '2013-02-20', '20:10:31');
INSERT INTO user_act VALUES('44', 'goestoe', 'Menambah data pemasok/supplier dengan kode S00001 dan nama WER', '2013-02-22', '16:51:56');
INSERT INTO user_act VALUES('45', 'goestoe', 'Menambah data pemasok/supplier dengan kode S00002 dan nama PT Kolang Kaling', '2013-02-22', '16:54:54');
INSERT INTO user_act VALUES('46', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: try dan tanggal 22-02-2013', '2013-02-22', '17:00:06');
INSERT INTO user_act VALUES('47', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 123456 dan tanggal 22-02-2013', '2013-02-22', '17:20:35');
INSERT INTO user_act VALUES('48', 'goestoe', 'Menambah data transaksi pengeluaran barang nomor surat jalan: 1234 dan tanggal 22-02-2013', '2013-02-22', '18:06:39');
INSERT INTO user_act VALUES('49', 'goestoe', 'Menghapus data barang dengan kode: B00001', '2013-02-26', '10:02:55');
INSERT INTO user_act VALUES('50', 'goestoe', 'Menghapus data barang dengan kode: B00002', '2013-02-26', '10:02:57');
INSERT INTO user_act VALUES('51', 'goestoe', 'Menghapus data barang dengan kode: B00008', '2013-02-26', '14:53:37');
INSERT INTO user_act VALUES('52', 'goestoe', 'Menghapus data barang dengan kode: B00007', '2013-02-26', '14:53:39');
INSERT INTO user_act VALUES('53', 'goestoe', 'Menghapus data barang dengan kode: B00006', '2013-02-26', '14:53:41');
INSERT INTO user_act VALUES('54', 'goestoe', 'Menghapus data barang dengan kode: B00005', '2013-02-26', '14:53:43');
INSERT INTO user_act VALUES('55', 'goestoe', 'Menghapus data barang dengan kode: B00004', '2013-02-26', '14:53:45');
INSERT INTO user_act VALUES('56', 'goestoe', 'Menghapus data barang dengan kode: B00003', '2013-02-26', '14:53:47');
INSERT INTO user_act VALUES('57', 'goestoe', 'Mengubah data user dengan nama Admin1 dan userid admin', '2013-02-27', '07:30:44');
INSERT INTO user_act VALUES('58', 'goestoe', 'Mengubah data barang dengan kode B00001 dan nama Baju', '2013-02-27', '12:49:10');
INSERT INTO user_act VALUES('59', 'goestoe', 'Mengubah Password', '2013-02-28', '08:37:38');
INSERT INTO user_act VALUES('60', 'goestoe', 'Mengubah Password', '2013-02-28', '08:38:26');
INSERT INTO user_act VALUES('61', 'goestoe', 'Mengubah Password', '2013-02-28', '08:41:16');
INSERT INTO user_act VALUES('62', 'goestoe', 'Mengubah data user dengan nama Operator Pemasukan dan userid masuk', '2013-02-28', '08:43:18');
INSERT INTO user_act VALUES('63', 'masuk', 'Mengubah Password', '2013-02-28', '08:43:50');
INSERT INTO user_act VALUES('64', 'goestoe', 'Mengubah Password', '2013-02-28', '09:05:38');
INSERT INTO user_act VALUES('65', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Pemusnahan', '2013-03-01', '08:57:47');
INSERT INTO user_act VALUES('66', 'goestoe', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP 133 dan tanggal 02-03-2013', '2013-03-02', '09:10:33');
INSERT INTO user_act VALUES('67', 'goestoe', 'Menghapus data barang dengan kode: B00001', '2013-03-02', '09:12:55');
INSERT INTO user_act VALUES('68', 'goestoe', 'Menghapus data barang dengan kode: B00008', '2013-03-02', '09:13:09');
INSERT INTO user_act VALUES('69', 'goestoe', 'Menghapus data barang dengan kode: B00007', '2013-03-02', '09:13:13');
INSERT INTO user_act VALUES('70', 'goestoe', 'Menghapus data barang dengan kode: B00006', '2013-03-02', '09:13:17');
INSERT INTO user_act VALUES('71', 'goestoe', 'Menghapus data barang dengan kode: B00005', '2013-03-02', '09:13:21');
INSERT INTO user_act VALUES('72', 'goestoe', 'Menghapus data barang dengan kode: B00004', '2013-03-02', '09:13:24');
INSERT INTO user_act VALUES('73', 'goestoe', 'Menghapus data barang dengan kode: B00003', '2013-03-02', '09:13:26');
INSERT INTO user_act VALUES('74', 'goestoe', 'Menghapus data barang dengan kode: B00002', '2013-03-02', '09:13:28');
INSERT INTO user_act VALUES('75', 'goestoe', 'Menambah data barang dengan kode B00001 dan nama Sepatu', '2013-03-02', '09:14:08');
INSERT INTO user_act VALUES('76', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 4353 dan tanggal 02-03-2013', '2013-03-02', '09:16:16');
INSERT INTO user_act VALUES('77', 'goestoe', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP 234 dan tanggal 02-03-2013', '2013-03-02', '09:17:09');
INSERT INTO user_act VALUES('78', 'goestoe', 'Mengubah data perusahaan', '2013-03-02', '21:32:53');
INSERT INTO user_act VALUES('79', 'admin', 'Mengubah data kategori barang dengan nama Jig', '2013-03-02', '22:11:15');
INSERT INTO user_act VALUES('80', 'admin', 'Mengubah data kategori barang dengan nama Moulding', '2013-03-02', '22:11:27');
INSERT INTO user_act VALUES('81', 'admin', 'Menghapus data kategori barang dengan kode:K03', '2013-03-02', '22:11:31');
INSERT INTO user_act VALUES('82', 'admin', 'Menghapus data kategori barang dengan kode:K04', '2013-03-02', '22:11:33');
INSERT INTO user_act VALUES('83', 'admin', 'Menghapus data user dengan kode:8', '2013-03-02', '22:12:00');
INSERT INTO user_act VALUES('84', 'admin', 'Menghapus data user dengan kode:9', '2013-03-02', '22:12:03');
INSERT INTO user_act VALUES('85', 'admin', 'Menghapus data user dengan kode:10', '2013-03-02', '22:12:06');
INSERT INTO user_act VALUES('86', 'admin', 'Menghapus data user dengan kode:12', '2013-03-02', '22:12:08');
INSERT INTO user_act VALUES('87', 'admin', 'Menghapus data user dengan kode:4', '2013-03-02', '22:12:14');
INSERT INTO user_act VALUES('88', 'admin', 'Menghapus data user dengan kode:3', '2013-03-02', '22:12:17');
INSERT INTO user_act VALUES('89', 'admin', 'Menghapus data user dengan kode:6', '2013-03-02', '22:12:20');
INSERT INTO user_act VALUES('90', 'admin', 'Mengubah data user dengan nama Gerald dan userid tasya', '2013-03-02', '22:12:36');
INSERT INTO user_act VALUES('91', 'admin', 'Mengubah data user dengan nama Bayu dan userid bayu', '2013-03-02', '22:12:58');
INSERT INTO user_act VALUES('92', 'admin', 'Mengubah data user dengan nama Tasya dan userid tasya', '2013-03-02', '22:13:10');
INSERT INTO user_act VALUES('93', 'admin', 'Menambah data kategori barang dengan nama Tooling', '2013-03-02', '22:59:57');
INSERT INTO user_act VALUES('94', 'admin', 'Menghapus data user dengan kode:5', '2013-03-04', '07:59:21');
INSERT INTO user_act VALUES('95', 'admin', 'Menghapus data user dengan kode:7', '2013-03-04', '07:59:23');
INSERT INTO user_act VALUES('96', 'admin', 'Menambah data user dengan nama Agustu Atihuta dan userid goestoe', '2013-03-04', '07:59:39');
INSERT INTO user_act VALUES('97', 'admin', 'Menghapus data user dengan kode:1', '2013-03-04', '07:59:44');
INSERT INTO user_act VALUES('98', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 23234 dan tanggal 04-03-2013', '2013-03-04', '08:53:39');
INSERT INTO user_act VALUES('99', 'goestoe', 'Mengubah data kategori barang dengan nama Bahan Baku/Penolong', '2013-03-04', '09:12:45');
INSERT INTO user_act VALUES('100', 'goestoe', 'Mengubah data kategori barang dengan nama Barang Jadi', '2013-03-04', '09:12:53');
INSERT INTO user_act VALUES('101', 'goestoe', 'Mengubah data kategori barang dengan nama Barang Modal dan Peralatan Perkantoran', '2013-03-04', '09:13:10');
INSERT INTO user_act VALUES('102', 'goestoe', 'Menambah data kategori barang dengan nama Barang Sisa / Scrap', '2013-03-04', '09:13:16');
INSERT INTO user_act VALUES('103', 'goestoe', 'Menambah data transaksi produksi-incoming nomor SPB: 123456 dan tanggal 04-03-2013', '2013-03-04', '12:02:45');
INSERT INTO user_act VALUES('104', 'goestoe', 'Menerima barang INCOMING dengan nomor LPB: 12345 dan tanggal 04-03-2013', '2013-03-04', '12:06:33');
INSERT INTO user_act VALUES('105', 'goestoe', 'Menambah data transaksi incoming-produksi dengan nomor SPB: 123 dan tanggal 04-03-2013', '2013-03-04', '14:13:20');
INSERT INTO user_act VALUES('106', 'goestoe', 'Menerima barang PRODUKSI dengan nomor LPB: 1234 dan tanggal 04-03-2013', '2013-03-04', '14:13:59');
INSERT INTO user_act VALUES('107', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor SPB: 123 dan tanggal 04-03-2013', '2013-03-04', '14:57:41');
INSERT INTO user_act VALUES('108', 'goestoe', 'Menerima barang OUTGOING dengan nomor LPB: 123 dan tanggal 04-03-2013', '2013-03-04', '14:57:54');
INSERT INTO user_act VALUES('109', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor SPB: 234 dan tanggal 04-03-2013', '2013-03-04', '16:42:23');
INSERT INTO user_act VALUES('110', 'goestoe', 'Menambah data transaksi outgoing-incoming nomor SPB: 122 dan tanggal 04-03-2013', '2013-03-04', '18:23:15');
INSERT INTO user_act VALUES('111', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Penyimpanan Bahan', '2013-03-07', '08:01:14');
INSERT INTO user_act VALUES('112', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Alat Produksi', '2013-03-07', '08:01:34');
INSERT INTO user_act VALUES('113', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Pra Produksi', '2013-03-07', '08:02:13');
INSERT INTO user_act VALUES('114', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Produksi', '2013-03-07', '08:02:31');
INSERT INTO user_act VALUES('115', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Kontrol Kualitas', '2013-03-07', '08:02:45');
INSERT INTO user_act VALUES('116', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Pasca Produksi', '2013-03-07', '08:02:58');
INSERT INTO user_act VALUES('117', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Penyimpanan Barang Jadi', '2013-03-07', '08:03:19');
INSERT INTO user_act VALUES('118', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Penyimpanan Barang Sisa / Scrap', '2013-03-07', '08:03:36');
INSERT INTO user_act VALUES('119', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Penjualan', '2013-03-07', '08:03:49');
INSERT INTO user_act VALUES('120', 'goestoe', 'Mengubah data tujuan pengiriman dengan kode:DEP-0001 dan nama Bagian Penyimpanan Bahan Baku / Penolong', '2013-03-07', '08:05:06');
INSERT INTO user_act VALUES('121', 'goestoe', 'Menambah data tujuan pengiriman dengan nama Bagian Personalia', '2013-03-07', '08:05:20');
INSERT INTO user_act VALUES('122', 'goestoe', 'Menghapus data tujuan pengiriman dengan kode:DEP-0010', '2013-03-07', '08:05:23');
INSERT INTO user_act VALUES('123', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor SPB: 12 dan tanggal 07-03-2013', '2013-03-07', '08:16:38');
INSERT INTO user_act VALUES('124', 'goestoe', 'Menambah data transaksi incoming-produksi dengan nomor SPB: 123 dan tanggal 07-03-2013', '2013-03-07', '08:33:59');
INSERT INTO user_act VALUES('125', 'goestoe', 'Menerima barang INCOMING dengan nomor LPB: 123 dan tanggal 07-03-2013', '2013-03-07', '10:41:36');
INSERT INTO user_act VALUES('126', 'goestoe', 'Menambah data user dengan nama Bayu Hendra dan userid bayu', '2013-03-10', '00:58:05');
INSERT INTO user_act VALUES('127', 'goestoe', 'Menambah data user dengan nama Administrator dan userid admin', '2013-03-10', '00:58:20');
INSERT INTO user_act VALUES('128', 'goestoe', 'Menambah data pengguna dengan nama Agustu Atihuta dan penggunaid goestoe', '2013-03-12', '10:43:13');
INSERT INTO user_act VALUES('129', 'goestoe', 'Mengubah data pengguna dengan nama Agustu Atihuta dan penggunaid goestoe', '2013-03-12', '10:43:25');
INSERT INTO user_act VALUES('130', 'goestoe', 'Mengubah data pengguna dengan nama Agustu Atihuta dan penggunaid goestoe', '2013-03-12', '10:43:39');
INSERT INTO user_act VALUES('131', 'goestoe', 'Menghapus data pengguna dengan kode:1', '2013-03-12', '10:43:42');
INSERT INTO user_act VALUES('132', 'goestoe', 'Menambah data pengguna dengan nama Agustu Atihuta dan penggunaid goestoe', '2013-03-12', '10:43:55');
INSERT INTO user_act VALUES('133', 'goestoe', 'Menambah data pengguna dengan nama Bayu Hendra Wianto dan penggunaid bayu', '2013-03-12', '12:34:28');
INSERT INTO user_act VALUES('134', 'goestoe', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP ewr dan tanggal 14-03-2013', '2013-03-14', '21:27:57');
INSERT INTO user_act VALUES('135', 'goestoe', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP 345 dan tanggal 15-03-2013', '2013-03-15', '00:06:16');
INSERT INTO user_act VALUES('136', 'goestoe', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP 324 dan tanggal 15-03-2013', '2013-03-15', '00:08:24');
INSERT INTO user_act VALUES('137', 'goestoe', 'Mengubah data perusahaan', '2013-03-15', '16:15:45');
INSERT INTO user_act VALUES('138', 'goestoe', 'Mengubah data perusahaan', '2013-03-17', '17:16:32');
INSERT INTO user_act VALUES('139', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-00000001 dan tanggal 17-03-2013', '2013-03-17', '19:12:20');
INSERT INTO user_act VALUES('140', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-00000001 dan tanggal 17-03-2013', '2013-03-17', '19:16:56');
INSERT INTO user_act VALUES('141', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 201303170001 dan tanggal 17-03-2013', '2013-03-17', '19:32:29');
INSERT INTO user_act VALUES('142', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:09:33');
INSERT INTO user_act VALUES('143', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:09:44');
INSERT INTO user_act VALUES('144', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:11:20');
INSERT INTO user_act VALUES('145', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:11:30');
INSERT INTO user_act VALUES('146', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:11:40');
INSERT INTO user_act VALUES('147', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:11:51');
INSERT INTO user_act VALUES('148', 'admin', 'Mengubah data perusahaan', '2013-03-17', '20:11:59');
INSERT INTO user_act VALUES('149', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-000001/EPSON/2013 dan tanggal 17-03-2013', '2013-03-17', '20:27:11');
INSERT INTO user_act VALUES('150', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-000001/EPSON/20130317 dan tanggal 17-03-2013', '2013-03-17', '20:29:11');
INSERT INTO user_act VALUES('151', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-0000012013/EPSON dan tanggal 17-03-2013', '2013-03-17', '20:36:20');
INSERT INTO user_act VALUES('152', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000001 dan tanggal 17-03-2013', '2013-03-17', '20:41:10');
INSERT INTO user_act VALUES('153', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: 2013000001 dan tanggal 17-03-2013', '2013-03-17', '20:42:03');
INSERT INTO user_act VALUES('154', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000001 dan tanggal 17-03-2013', '2013-03-17', '20:44:03');
INSERT INTO user_act VALUES('155', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000001/EPSON dan tanggal 17-03-2013', '2013-03-17', '20:52:31');
INSERT INTO user_act VALUES('156', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000002/EPSON dan tanggal 17-03-2013', '2013-03-17', '20:54:34');
INSERT INTO user_act VALUES('157', 'admin', 'Menambah data transaksi pengeluaran barang nomor surat jalan: SJ-2013000001/EPSON dan tanggal 17-03-2013', '2013-03-17', '21:03:26');
INSERT INTO user_act VALUES('158', 'admin', 'Menambah data transaksi incoming - outgoing nomor SPB: SPB-2013000001/INCOMING dan tanggal 17-03-2013', '2013-03-17', '21:07:40');
INSERT INTO user_act VALUES('159', 'admin', 'Menambah data transaksi incoming-produksi dengan nomor SPB: SPB-2013000001/INCOMING dan tanggal 17-03-2013', '2013-03-17', '21:11:08');
INSERT INTO user_act VALUES('160', 'admin', 'Menambah data transaksi produksi-incoming nomor SPB: SPB-2013000001/PRODUKSI dan tanggal 17-03-2013', '2013-03-17', '21:14:36');
INSERT INTO user_act VALUES('161', 'admin', 'Menambah data transaksi pemasukan barang dengan nomor SPB: SPB-2013000001/PRODUKSI dan tanggal 17-03-2013', '2013-03-17', '21:16:56');
INSERT INTO user_act VALUES('162', 'admin', 'Menambah data Barang Jadi hasil produksi dengan nomor BHP LP-2013000001/PRODUKSI dan tanggal 17-03-2013', '2013-03-17', '21:19:48');
INSERT INTO user_act VALUES('163', 'admin', 'Menambah data transaksi outgoing-incoming nomor SPB: SPB-2013000001/OUTGOING dan tanggal 17-03-2013', '2013-03-17', '21:23:19');
INSERT INTO user_act VALUES('164', 'admin', 'Menambah data transaksi outgoing-produksi nomor SPB: SPB-2013000001/OUTGOING dan tanggal 17-03-2013', '2013-03-17', '21:24:40');
INSERT INTO user_act VALUES('165', 'admin', 'Menerima barang INCOMING dengan nomor LPB: LPB-2013000001/INCOMING dan tanggal 17-03-2013', '2013-03-17', '21:29:18');
INSERT INTO user_act VALUES('166', 'admin', 'Menerima barang PRODUKSI dengan nomor LPB: LPB-2013000001/PRODUKSI dan tanggal 17-03-2013', '2013-03-17', '21:31:12');
INSERT INTO user_act VALUES('167', 'admin', 'Menerima barang OUTGOING dengan nomor LPB: LPB-2013000001/OUTGOING dan tanggal 17-03-2013', '2013-03-17', '21:34:11');
INSERT INTO user_act VALUES('168', 'admin', 'Menerima barang OUTGOING dengan nomor LPB: LPB-2013000002/OUTGOING dan tanggal 17-03-2013', '2013-03-17', '21:34:16');
INSERT INTO user_act VALUES('169', 'admin', 'Menambah data adjustment dengan nomor ADJ-2013000001 tanggal 17-03-2013', '2013-03-17', '22:07:12');
INSERT INTO user_act VALUES('170', 'goestoe', 'Mengubah data perusahaan', '2013-03-18', '08:23:09');
INSERT INTO user_act VALUES('171', 'goestoe', 'Menambah data user dengan nama Exim dan userid exim', '2013-03-18', '08:26:27');
INSERT INTO user_act VALUES('172', 'goestoe', 'Mengubah data barang dengan kode B00001 dan nama Sepatu', '2013-03-22', '07:35:49');
INSERT INTO user_act VALUES('173', 'goestoe', 'Mengubah data barang dengan kode B00002 dan nama Celana Jeans', '2013-03-22', '07:36:04');
INSERT INTO user_act VALUES('174', 'goestoe', 'Mengubah data barang dengan kode B00003 dan nama Kaos Oblong', '2013-03-22', '07:36:55');
INSERT INTO user_act VALUES('175', 'goestoe', 'Mengubah data barang dengan kode B00003 dan nama Kaos Oblong', '2013-03-22', '07:37:41');
INSERT INTO user_act VALUES('176', 'goestoe', 'Mengubah data barang dengan kode B00004 dan nama Kemeja', '2013-03-22', '07:37:50');
INSERT INTO user_act VALUES('177', 'goestoe', 'Mengubah data barang dengan kode B00001 dan nama Sepatu Roda', '2013-03-22', '07:46:28');
INSERT INTO user_act VALUES('178', 'goestoe', 'Menambah data barang dengan kode K00002 dan nama Sabun', '2013-03-22', '07:49:48');
INSERT INTO user_act VALUES('179', 'goestoe', 'Menghapus data barang dengan kode: B00002', '2013-03-22', '07:50:22');
INSERT INTO user_act VALUES('180', 'goestoe', 'Menambah data barang dengan kode K00003 dan nama Kemeja', '2013-03-22', '07:52:40');
INSERT INTO user_act VALUES('181', 'goestoe', 'Menambah data transaksi pengeluaran barang nomor surat jalan: SJ-2013000002/DEMO dan tanggal 23-03-2013', '2013-03-23', '17:04:00');
INSERT INTO user_act VALUES('182', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000003/DEMO dan tanggal 23-03-2013', '2013-03-23', '17:35:41');
INSERT INTO user_act VALUES('183', 'goestoe', 'Menambah data pemasok/supplier dengan kode S0000003 dan nama PT Indonesia Epson Industry', '2013-03-23', '18:35:43');
INSERT INTO user_act VALUES('184', 'goestoe', 'Mengubah data pemasok/supplier dengan kode: S0000003 dan nama PT Indonesia Epson Industry', '2013-03-23', '18:35:55');
INSERT INTO user_act VALUES('185', 'goestoe', 'Menghapus data pemasok/supplier dengan kode: S0000003', '2013-03-23', '18:36:03');
INSERT INTO user_act VALUES('186', 'goestoe', 'Mengubah data pemasok/supplier dengan kode: S00002 dan nama PT Kolang Kaling', '2013-03-23', '18:36:21');
INSERT INTO user_act VALUES('187', 'goestoe', 'Menambah data PENERIMA dengan kode P0000002 dan nama PT Bersatu Kita Teguh', '2013-03-23', '18:37:33');
INSERT INTO user_act VALUES('188', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Bersatu Kita Teguh', '2013-03-23', '18:37:48');
INSERT INTO user_act VALUES('189', 'goestoe', 'Menghapus data PENERIMA dengan kode:P0000002', '2013-03-23', '18:37:52');
INSERT INTO user_act VALUES('190', 'goestoe', 'Menambah data transaksi pengeluaran barang nomor surat jalan: SJ-2013000003/DEMO dan tanggal 23-03-2013', '2013-03-23', '18:38:25');
INSERT INTO user_act VALUES('191', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-03-24', '14:41:36');
INSERT INTO user_act VALUES('192', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-03-24', '14:58:42');
INSERT INTO user_act VALUES('193', 'goestoe', 'Menambah data PENERIMA dengan kode P0000002 dan nama PT Berlian Tahta Sejahtera', '2013-03-24', '15:00:09');
INSERT INTO user_act VALUES('194', 'goestoe', 'Menghapus data PENERIMA dengan kode:P0000002', '2013-03-24', '15:00:48');
INSERT INTO user_act VALUES('195', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-03-24', '15:01:00');
INSERT INTO user_act VALUES('196', 'goestoe', 'Mengubah data PENERIMA dengan nama PT Berlian Tahta', '2013-03-24', '15:01:13');
INSERT INTO user_act VALUES('197', 'goestoe', 'Mengubah data pemasok/supplier dengan kode: S00001 dan nama PT LG Electronics Indonesia', '2013-03-24', '15:19:29');
INSERT INTO user_act VALUES('198', 'goestoe', 'Mengubah data pemasok/supplier dengan kode: S00002 dan nama PT Kolang Kaling', '2013-03-24', '15:19:44');
INSERT INTO user_act VALUES('199', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000004/DEMO dan tanggal 24-03-2013', '2013-03-24', '16:24:14');
INSERT INTO user_act VALUES('200', 'goestoe', 'Menambah data transaksi pemasukan barang dengan nomor BPB: BPB-2013000005/DEMO dan tanggal 24-03-2013', '2013-03-24', '22:42:25');



DROP TABLE IF EXISTS user_login;

CREATE TABLE `user_login` (
  `id` int(4) NOT NULL auto_increment,
  `userid` char(20) collate latin1_general_ci NOT NULL,
  `password` varchar(200) collate latin1_general_ci NOT NULL,
  `nm_user` varchar(100) collate latin1_general_ci NOT NULL,
  `level` enum('BeaCukai','Pemasukan','Produksi','Pengeluaran','Exim','Highest','Admin','SuperAdmin') collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO user_login VALUES('13', 'goestoe', 'a23911453577f4ad228cc0bb4698eb37', 'Agustu Atihuta', 'SuperAdmin');
INSERT INTO user_login VALUES('14', 'bayu', 'b0a9d75110b8ec5138271f78c8f899be', 'Bayu Hendra', 'SuperAdmin');
INSERT INTO user_login VALUES('15', 'admin', '400fb4f0c52e7290305e00ab9e3df759', 'Administrator', 'Admin');
INSERT INTO user_login VALUES('16', 'exim', 'b0a9d75110b8ec5138271f78c8f899be', 'Exim', 'Exim');



